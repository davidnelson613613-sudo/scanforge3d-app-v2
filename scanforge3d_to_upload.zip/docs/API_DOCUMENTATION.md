# ScanForge3D REST API Documentation

**Version:** 1.0.0  
**Base URL:** `https://api.scanforge3d.com/api/v1`  
**Protocol:** HTTPS only  
**Authentication:** Bearer JWT (OAuth2)

---

## Overview

The ScanForge3D API is a RESTful service that powers the mobile 3D scanning platform. It handles user authentication, scan job lifecycle management, 3D reconstruction orchestration, AI-powered object classification, subscription billing, marketplace publishing, and in-app APK build requests.

All requests and responses use JSON (`Content-Type: application/json`). Timestamps are ISO 8601 UTC strings. UUIDs are used for all resource identifiers.

---

## Authentication

All protected endpoints require a valid JWT access token in the `Authorization` header:

```
Authorization: Bearer <access_token>
```

Access tokens expire after **60 minutes**. Use the refresh token endpoint to obtain a new access token without requiring the user to log in again.

### Subscription Tiers

| Tier | Scans/Month | Rate Limit | Priority Processing | Watermark |
|------|-------------|------------|---------------------|-----------|
| `free` | 3 | 30 req/min | No | Yes |
| `pro` | Unlimited | 120 req/min | No | No |
| `enterprise` | Unlimited | 500 req/min | Yes | No |

---

## Error Responses

All errors follow a consistent format:

```json
{
  "detail": "Human-readable error message."
}
```

| HTTP Status | Meaning |
|-------------|---------|
| `400` | Bad Request — invalid parameters |
| `401` | Unauthorized — missing or invalid token |
| `403` | Forbidden — insufficient permissions |
| `404` | Not Found — resource does not exist |
| `409` | Conflict — resource already exists |
| `422` | Unprocessable Entity — validation error |
| `429` | Too Many Requests — rate limit exceeded |
| `500` | Internal Server Error |

---

## Endpoints

---

### Authentication

#### `POST /auth/register`

Registers a new user account. Automatically creates a free-tier subscription.

**Rate Limit:** 10 requests/minute per IP

**Request Body:**

```json
{
  "email": "user@example.com",
  "password": "securepassword123",
  "display_name": "Jane Doe"
}
```

| Field | Type | Required | Constraints |
|-------|------|----------|-------------|
| `email` | string | Yes | Valid email format |
| `password` | string | Yes | 8–128 characters |
| `display_name` | string | Yes | 2–100 characters |

**Response `201 Created`:**

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 3600,
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "email": "user@example.com",
    "display_name": "Jane Doe",
    "subscription_tier": "free",
    "scans_remaining": 3
  }
}
```

---

#### `POST /auth/login`

Authenticates an existing user and returns JWT tokens.

**Rate Limit:** 10 requests/minute per IP

**Request Body:**

```json
{
  "email": "user@example.com",
  "password": "securepassword123"
}
```

**Response `200 OK`:** Same structure as `/auth/register`.

---

#### `POST /auth/refresh`

Exchanges a valid refresh token for a new access token. Implements refresh token rotation — the old token is revoked immediately.

**Request Body:**

```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response `200 OK`:** Same structure as `/auth/register`.

---

#### `POST /auth/logout`

Revokes the current access token by adding it to the blacklist. Requires a valid Bearer token.

**Response `204 No Content`**

---

### Users

#### `GET /users/me`

Returns the authenticated user's profile.

**Response `200 OK`:**

```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "email": "user@example.com",
  "display_name": "Jane Doe",
  "avatar_url": "https://cdn.scanforge3d.com/avatars/user.jpg",
  "is_verified": true,
  "created_at": "2026-01-15T10:30:00Z"
}
```

---

#### `PATCH /users/me`

Updates the user's profile fields.

**Request Body:**

```json
{
  "display_name": "Jane Smith",
  "avatar_url": "https://example.com/avatar.jpg"
}
```

**Response `200 OK`:**

```json
{
  "message": "Profile updated successfully."
}
```

---

#### `DELETE /users/me`

Permanently deletes the user account and all associated data. This action is irreversible.

**Response `204 No Content`**

---

### Scan Jobs

#### `POST /scans/jobs`

Creates a new scan job session. Enforces subscription scan limits before creation.

**Request Body:**

```json
{
  "client_session_id": "ar-session-abc123",
  "started_at": "2026-03-03T12:00:00Z",
  "scan_metadata": {
    "device_model": "Samsung Galaxy S24",
    "os_version": "Android 14",
    "ar_framework": "ARCore 1.40"
  }
}
```

**Response `201 Created`:**

```json
{
  "job_id": "7f3c2a1b-4e5d-6f7a-8b9c-0d1e2f3a4b5c",
  "status": "pending",
  "frames_s3_prefix": "frames/user-id/job-id"
}
```

**Error `429 Too Many Requests`** (free tier limit reached):

```json
{
  "detail": "Free tier limit of 3 scans/month reached. Upgrade to Pro for unlimited scans."
}
```

---

#### `POST /scans/upload-url`

Generates a pre-signed S3 URL for direct frame batch upload from the mobile device. The client uploads directly to S3, bypassing the API server for performance.

**Request Body:**

```json
{
  "job_id": "7f3c2a1b-4e5d-6f7a-8b9c-0d1e2f3a4b5c",
  "batch_index": 0,
  "frame_count": 30
}
```

**Response `200 OK`:**

```json
{
  "upload_url": "https://scanforge-frames.s3.amazonaws.com/frames/...",
  "expires_at": "2026-03-03T12:15:00Z",
  "batch_id": "a1b2c3d4-...",
  "s3_key": "frames/user-id/job-id/batch_0000_a1b2c3d4.zip"
}
```

> **Note:** Upload URLs expire after 15 minutes. The client must upload a ZIP archive of JPEG frames to this URL using an HTTP `PUT` request with `Content-Type: application/zip`.

---

#### `POST /scans/jobs/{job_id}/reconstruct`

Triggers the 3D reconstruction pipeline after all frames have been uploaded. Enterprise users receive priority queue placement.

**Path Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `job_id` | UUID | The scan job identifier |

**Response `200 OK`:**

```json
{
  "job_id": "7f3c2a1b-...",
  "status": "queued",
  "priority": "normal"
}
```

---

#### `GET /scans/jobs/{job_id}/status`

Polls the current status and results of a scan job. Completed job results are cached for 1 hour.

**Response `200 OK`:**

```json
{
  "job_id": "7f3c2a1b-...",
  "status": "completed",
  "confidence_score": 87.4,
  "processing_progress": 100.0,
  "mesh_url": "https://scanforge-meshes.s3.amazonaws.com/meshes/...",
  "thumbnail_url": "https://cdn.scanforge3d.com/thumbnails/job-id/thumbnail.jpg",
  "object_class": "chair",
  "material_type": "wood",
  "estimated_volume_cm3": 245.7,
  "estimated_weight_grams": 3200.0,
  "error_message": null,
  "created_at": "2026-03-03T12:00:00Z",
  "completed_at": "2026-03-03T12:04:32Z"
}
```

**Job Status Values:**

| Status | Description |
|--------|-------------|
| `pending` | Job created, awaiting frame uploads |
| `uploading` | Frames being uploaded |
| `queued` | In reconstruction queue |
| `processing` | Reconstruction pipeline running |
| `completed` | Mesh generated successfully |
| `failed` | Reconstruction failed (see `error_message`) |

---

#### `GET /scans/`

Returns a paginated list of the user's scan jobs.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `page` | integer | 1 | Page number |
| `page_size` | integer | 20 | Results per page (max 100) |
| `status_filter` | string | — | Filter by job status |

**Response `200 OK`:**

```json
{
  "scans": [
    {
      "job_id": "7f3c2a1b-...",
      "status": "completed",
      "confidence_score": 87.4,
      "object_class": "chair",
      "thumbnail_url": "https://cdn.scanforge3d.com/thumbnails/...",
      "created_at": "2026-03-03T12:00:00Z"
    }
  ],
  "total": 42,
  "page": 1,
  "page_size": 20
}
```

---

#### `POST /scans/export`

Requests a 3D model export in the specified format. Free tier exports include a watermark. Processing is asynchronous.

**Request Body:**

```json
{
  "job_id": "7f3c2a1b-...",
  "format": "glb",
  "resolution": "high"
}
```

| Field | Type | Options |
|-------|------|---------|
| `format` | string | `obj`, `fbx`, `glb`, `usdz`, `stl` |
| `resolution` | string | `low`, `medium`, `high`, `ultra` |

**Response `200 OK`:**

```json
{
  "export_id": "e1f2g3h4-...",
  "status": "pending",
  "format": "glb",
  "watermarked": false,
  "message": "Export queued. Check status at /exports/{export_id}"
}
```

---

#### `POST /scans/compare`

Generates a before/after comparison report between two completed scan jobs.

**Request Body:**

```json
{
  "job_id_before": "7f3c2a1b-...",
  "job_id_after": "8a4d3b2c-..."
}
```

**Response `200 OK`:**

```json
{
  "job_id_before": "7f3c2a1b-...",
  "job_id_after": "8a4d3b2c-...",
  "volume_change_cm3": -12.3,
  "surface_area_change_cm2": 0.0,
  "confidence_delta": 5.2,
  "comparison_image_url": null,
  "summary": "Volume decreased by 12.3 cm³. Confidence improved by 5.2 points."
}
```

---

#### `DELETE /scans/jobs/{job_id}`

Permanently deletes a scan job and all associated frames and exports.

**Response `204 No Content`**

---

### AI Services

#### `POST /ai/classify`

Classifies a scanned object using AI vision. Returns object category, material type, volume/weight estimates, and marketplace tags.

**Request Body:**

```json
{
  "job_id": "7f3c2a1b-...",
  "thumbnail_base64": "<base64-encoded JPEG>",
  "mesh_metadata": {
    "volume_cm3": 245.7,
    "triangle_count": 45000
  }
}
```

**Response `200 OK`:**

```json
{
  "object_class": "chair",
  "subcategory": "office_chair",
  "confidence": 0.94,
  "material_type": "plastic",
  "tags": ["furniture", "chair", "office", "seating", "3d-scan"],
  "estimated_volume_cm3": 245.7,
  "estimated_weight_grams": 4200.0
}
```

---

#### `POST /ai/remove-background`

Removes the background from an image using AI segmentation (U2Net). Returns a PNG with alpha transparency.

**Request Body:**

```json
{
  "image_base64": "<base64-encoded image>",
  "return_format": "png"
}
```

**Response `200 OK`:**

```json
{
  "result_base64": "<base64-encoded PNG with alpha>",
  "processing_time_ms": 342
}
```

---

#### `POST /ai/separate-objects`

Separates multiple objects in a single scan into individual meshes using instance segmentation.

**Request Body:**

```json
{
  "job_id": "7f3c2a1b-..."
}
```

**Response `200 OK`:**

```json
{
  "job_id": "7f3c2a1b-...",
  "status": "queued",
  "message": "Multi-object separation queued. Results will be available via job status."
}
```

---

### Subscriptions

#### `GET /subscriptions/status`

Returns the current user's subscription tier and scan quota.

**Response `200 OK`:**

```json
{
  "tier": "pro",
  "scans_used": 14,
  "scans_limit": -1,
  "scans_remaining": -1,
  "is_priority": false,
  "renewal_date": "2026-04-03T00:00:00Z"
}
```

> **Note:** `scans_limit` and `scans_remaining` of `-1` indicate unlimited.

---

#### `POST /subscriptions/create-checkout`

Creates a Stripe checkout session for subscription upgrade.

**Request Body:**

```json
{
  "tier": "pro"
}
```

**Response `200 OK`:**

```json
{
  "checkout_url": "https://checkout.stripe.com/pay/cs_live_..."
}
```

---

#### `POST /subscriptions/webhook`

Stripe webhook endpoint for subscription lifecycle events. Must be configured in the Stripe dashboard with the webhook secret.

**Handled Events:**
- `customer.subscription.created` — Upgrades user to paid tier
- `customer.subscription.deleted` — Downgrades to free tier
- `invoice.payment_succeeded` — Resets monthly scan count

---

### Marketplace

#### `POST /marketplace/publish`

Publishes a completed scan to an external 3D marketplace.

**Request Body:**

```json
{
  "job_id": "7f3c2a1b-...",
  "target": "sketchfab",
  "metadata": {
    "title": "Vintage Wooden Chair",
    "description": "High-quality photogrammetry scan of a vintage chair.",
    "tags": ["furniture", "vintage", "wood", "chair"]
  }
}
```

| `target` | Platform |
|----------|----------|
| `sketchfab` | Sketchfab.com |
| `cgtrader` | CGTrader.com |
| `turbosquid` | TurboSquid.com |
| `fab` | Fab.com (Epic Games) |

**Response `200 OK`:**

```json
{
  "listing_id": "l1m2n3o4-...",
  "marketplace_url": "https://sketchfab.com/models/l1m2n3o4",
  "status": "pending"
}
```

---

#### `GET /marketplace/listings`

Returns all marketplace listings for the current user.

**Response `200 OK`:**

```json
{
  "listings": [
    {
      "listing_id": "l1m2n3o4-...",
      "platform": "sketchfab",
      "title": "Vintage Wooden Chair",
      "status": "published",
      "listing_url": "https://sketchfab.com/models/l1m2n3o4",
      "created_at": "2026-03-03T14:00:00Z"
    }
  ]
}
```

---

### App Builds

#### `POST /builds/apk`

Triggers the CI/CD pipeline to build a signed Android APK. The build is queued and the download URL is available via the status endpoint.

**Request Body:**

```json
{
  "package_name": "com.scanforge.scanforge3d",
  "version_name": "1.2.0",
  "version_code": 12,
  "build_type": "release"
}
```

**Response `200 OK`:**

```json
{
  "build_id": "b1c2d3e4-...",
  "status": "queued",
  "estimated_minutes": 10,
  "webhook_url": "https://api.scanforge3d.com/api/v1/builds/b1c2d3e4/status"
}
```

---

#### `GET /builds/{build_id}/status`

Returns the status of a requested APK build.

**Response `200 OK`:**

```json
{
  "build_id": "b1c2d3e4-...",
  "status": "completed",
  "download_url": "https://cdn.scanforge3d.com/builds/b1c2d3e4/scanforge3d.apk",
  "version_name": "1.2.0",
  "version_code": 12,
  "file_size_bytes": 45000000,
  "signed": true,
  "expires_at": "2026-04-03T00:00:00Z"
}
```

---

## Reconstruction Server API (Internal)

The reconstruction server runs on port `8001` and is not exposed publicly. It is accessed only by the backend API and Celery workers.

#### `POST /reconstruct`

Runs the full photogrammetry pipeline for a scan job.

#### `POST /export`

Converts a completed mesh to an export format.

#### `GET /stream/{job_id}/mesh`

Streams the mesh file in 512KB chunks for large file support with lazy texture loading.

#### `GET /health`

Returns server health, active job count, and available disk space.

---

## Rate Limiting

Rate limits are enforced per IP address using a sliding window algorithm. When a limit is exceeded, the API returns `429 Too Many Requests` with a `Retry-After` header.

| Endpoint Group | Free | Pro | Enterprise |
|----------------|------|-----|------------|
| Auth endpoints | 10/min | 10/min | 10/min |
| General API | 30/min | 120/min | 500/min |
| Upload URLs | 30/min | 120/min | 500/min |

---

## Webhooks

The API sends webhook notifications to registered URLs for asynchronous events:

| Event | Trigger |
|-------|---------|
| `scan.completed` | Reconstruction finished successfully |
| `scan.failed` | Reconstruction failed after all retries |
| `export.ready` | Export file available for download |
| `subscription.upgraded` | User upgraded subscription tier |

Webhook payloads are signed with HMAC-SHA256 using your webhook secret. Verify the `X-ScanForge-Signature` header before processing.

---

## SDKs and Client Libraries

The Unity C# SDK (`ApiClient.cs`) is included in the Unity project and handles all API communication with automatic token refresh, retry logic, and signed URL uploads.

For server-to-server integrations, use API keys generated via the dashboard. Pass the key in the `X-API-Key` header instead of a Bearer token.
