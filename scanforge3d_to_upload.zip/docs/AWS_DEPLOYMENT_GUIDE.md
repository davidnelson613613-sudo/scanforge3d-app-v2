# ScanForge3D — AWS Deployment Guide

**Target Environment:** AWS (us-east-1 recommended)  
**Architecture:** ECS Fargate + RDS PostgreSQL + ElastiCache Redis + S3 + CloudFront  
**Estimated Monthly Cost:** ~$180–$350/month (production, moderate traffic)

---

## Architecture Overview

```
Internet
    │
    ▼
[Route 53] ──► [CloudFront CDN] ──► [S3 (static assets, exports)]
    │
    ▼
[Application Load Balancer]
    │
    ├──► [ECS Fargate: API Service] ──► [RDS PostgreSQL 16]
    │                                ──► [ElastiCache Redis 7]
    │                                ──► [S3 (frames, meshes)]
    │
    ├──► [ECS Fargate: Reconstruction Service] (CPU-optimized)
    │
    └──► [ECS Fargate: Celery Workers]
```

---

## Prerequisites

Before deploying, ensure you have:

1. AWS CLI v2 installed and configured (`aws configure`)
2. Terraform v1.7+ installed (optional, for IaC)
3. Docker installed locally
4. A registered domain name
5. An AWS account with Administrator access
6. A Unity license (for CI/CD builds)
7. A Google Play Developer account

---

## Step 1: AWS Account Setup

### 1.1 Create IAM Roles

Create the following IAM roles:

**ECS Task Execution Role** (`scanforge-ecs-execution-role`):
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "secretsmanager:GetSecretValue",
        "ssm:GetParameters"
      ],
      "Resource": "*"
    }
  ]
}
```

**ECS Task Role** (`scanforge-ecs-task-role`):
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject",
        "s3:GetObjectAcl",
        "s3:PutObjectAcl"
      ],
      "Resource": [
        "arn:aws:s3:::scanforge-frames/*",
        "arn:aws:s3:::scanforge-meshes/*",
        "arn:aws:s3:::scanforge-exports/*"
      ]
    },
    {
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": [
        "arn:aws:s3:::scanforge-frames",
        "arn:aws:s3:::scanforge-meshes",
        "arn:aws:s3:::scanforge-exports"
      ]
    }
  ]
}
```

**GitHub Actions Deploy Role** (`scanforge-github-deploy-role`):
Configure OIDC trust with GitHub Actions and grant ECR push and ECS deploy permissions.

---

## Step 2: Networking (VPC)

### 2.1 Create VPC

```bash
# Create VPC
aws ec2 create-vpc \
  --cidr-block 10.0.0.0/16 \
  --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=scanforge-vpc}]'

# Create public subnets (for ALB)
aws ec2 create-subnet --vpc-id <vpc-id> --cidr-block 10.0.1.0/24 --availability-zone us-east-1a
aws ec2 create-subnet --vpc-id <vpc-id> --cidr-block 10.0.2.0/24 --availability-zone us-east-1b

# Create private subnets (for ECS, RDS, Redis)
aws ec2 create-subnet --vpc-id <vpc-id> --cidr-block 10.0.10.0/24 --availability-zone us-east-1a
aws ec2 create-subnet --vpc-id <vpc-id> --cidr-block 10.0.11.0/24 --availability-zone us-east-1b

# Create Internet Gateway
aws ec2 create-internet-gateway
aws ec2 attach-internet-gateway --vpc-id <vpc-id> --internet-gateway-id <igw-id>

# Create NAT Gateway (for private subnet outbound)
aws ec2 allocate-address --domain vpc
aws ec2 create-nat-gateway --subnet-id <public-subnet-id> --allocation-id <eip-id>
```

### 2.2 Security Groups

Create the following security groups:

| Security Group | Inbound Rules | Purpose |
|----------------|---------------|---------|
| `scanforge-alb-sg` | 80, 443 from 0.0.0.0/0 | Application Load Balancer |
| `scanforge-api-sg` | 8000 from ALB SG only | API containers |
| `scanforge-rds-sg` | 5432 from API SG only | PostgreSQL |
| `scanforge-redis-sg` | 6379 from API SG only | Redis |
| `scanforge-reconstruction-sg` | 8001 from API SG only | Reconstruction server |

---

## Step 3: S3 Buckets

### 3.1 Create Buckets

```bash
# Frame uploads (private)
aws s3api create-bucket \
  --bucket scanforge-frames \
  --region us-east-1

# Mesh storage (private)
aws s3api create-bucket \
  --bucket scanforge-meshes \
  --region us-east-1

# Exports and APK builds (private, with presigned URLs)
aws s3api create-bucket \
  --bucket scanforge-exports \
  --region us-east-1
```

### 3.2 Configure Bucket Policies

Block all public access on all buckets:

```bash
aws s3api put-public-access-block \
  --bucket scanforge-frames \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
```

### 3.3 Configure CORS for Frame Uploads

Apply to `scanforge-frames` bucket to allow direct mobile uploads:

```json
[
  {
    "AllowedHeaders": ["*"],
    "AllowedMethods": ["PUT", "GET"],
    "AllowedOrigins": ["*"],
    "ExposeHeaders": ["ETag"],
    "MaxAgeSeconds": 3000
  }
]
```

### 3.4 Lifecycle Policies

```json
{
  "Rules": [
    {
      "Id": "expire-raw-frames",
      "Status": "Enabled",
      "Filter": {"Prefix": "frames/"},
      "Expiration": {"Days": 30}
    },
    {
      "Id": "expire-exports",
      "Status": "Enabled",
      "Filter": {"Prefix": "exports/"},
      "Expiration": {"Days": 7}
    }
  ]
}
```

---

## Step 4: ECR Repositories

```bash
# Create ECR repositories
aws ecr create-repository --repository-name scanforge3d-api --region us-east-1
aws ecr create-repository --repository-name scanforge3d-reconstruction --region us-east-1

# Set lifecycle policy (keep last 10 images)
aws ecr put-lifecycle-policy \
  --repository-name scanforge3d-api \
  --lifecycle-policy-text '{
    "rules": [{
      "rulePriority": 1,
      "selection": {
        "tagStatus": "untagged",
        "countType": "imageCountMoreThan",
        "countNumber": 10
      },
      "action": {"type": "expire"}
    }]
  }'
```

---

## Step 5: RDS PostgreSQL

```bash
# Create DB subnet group
aws rds create-db-subnet-group \
  --db-subnet-group-name scanforge-db-subnet \
  --db-subnet-group-description "ScanForge DB Subnet Group" \
  --subnet-ids <private-subnet-1-id> <private-subnet-2-id>

# Create PostgreSQL instance
aws rds create-db-instance \
  --db-instance-identifier scanforge-postgres \
  --db-instance-class db.t3.medium \
  --engine postgres \
  --engine-version 16.1 \
  --master-username scanforge \
  --master-user-password <STRONG_PASSWORD> \
  --db-name scanforge3d \
  --db-subnet-group-name scanforge-db-subnet \
  --vpc-security-group-ids <rds-sg-id> \
  --backup-retention-period 7 \
  --multi-az \
  --storage-type gp3 \
  --allocated-storage 100 \
  --storage-encrypted \
  --deletion-protection \
  --no-publicly-accessible
```

**Recommended instance sizes:**

| Traffic Level | Instance Class | Monthly Cost |
|---------------|----------------|--------------|
| Development | db.t3.micro | ~$15/month |
| Production (low) | db.t3.medium | ~$60/month |
| Production (high) | db.r6g.large | ~$180/month |

---

## Step 6: ElastiCache Redis

```bash
# Create subnet group
aws elasticache create-cache-subnet-group \
  --cache-subnet-group-name scanforge-redis-subnet \
  --cache-subnet-group-description "ScanForge Redis Subnet" \
  --subnet-ids <private-subnet-1-id> <private-subnet-2-id>

# Create Redis cluster
aws elasticache create-replication-group \
  --replication-group-id scanforge-redis \
  --description "ScanForge Redis cluster" \
  --cache-node-type cache.t3.medium \
  --engine redis \
  --engine-version 7.0 \
  --num-cache-clusters 2 \
  --cache-subnet-group-name scanforge-redis-subnet \
  --security-group-ids <redis-sg-id> \
  --at-rest-encryption-enabled \
  --transit-encryption-enabled \
  --auth-token <STRONG_REDIS_PASSWORD>
```

---

## Step 7: ECS Clusters and Services

### 7.1 Create ECS Cluster

```bash
aws ecs create-cluster \
  --cluster-name scanforge-production \
  --capacity-providers FARGATE FARGATE_SPOT \
  --default-capacity-provider-strategy \
    capacityProvider=FARGATE,weight=1,base=2 \
    capacityProvider=FARGATE_SPOT,weight=3
```

### 7.2 Store Secrets in AWS Secrets Manager

```bash
# Store all sensitive environment variables
aws secretsmanager create-secret \
  --name scanforge/production/env \
  --secret-string '{
    "DATABASE_URL": "postgresql+asyncpg://scanforge:PASSWORD@rds-endpoint:5432/scanforge3d",
    "REDIS_URL": "rediss://:PASSWORD@redis-endpoint:6379/0",
    "SECRET_KEY": "your-secret-key",
    "JWT_SECRET_KEY": "your-jwt-secret",
    "AWS_ACCESS_KEY_ID": "...",
    "AWS_SECRET_ACCESS_KEY": "...",
    "STRIPE_SECRET_KEY": "sk_live_...",
    "OPENAI_API_KEY": "sk-..."
  }'
```

### 7.3 Register ECS Task Definitions

Create task definitions for each service:

**API Service** (`scanforge-api-production`):
- CPU: 1024 (1 vCPU)
- Memory: 2048 MB
- Image: `<account>.dkr.ecr.us-east-1.amazonaws.com/scanforge3d-api:latest`
- Port: 8000

**Reconstruction Service** (`scanforge-reconstruction-production`):
- CPU: 4096 (4 vCPU)
- Memory: 16384 MB (16 GB)
- Image: `<account>.dkr.ecr.us-east-1.amazonaws.com/scanforge3d-reconstruction:latest`
- Port: 8001

**Worker Service** (`scanforge-worker-production`):
- CPU: 2048 (2 vCPU)
- Memory: 4096 MB
- Same image as API, different command: `celery -A app.workers.tasks.celery_app worker`

### 7.4 Create ECS Services

```bash
# API Service (2 tasks minimum, auto-scaling up to 10)
aws ecs create-service \
  --cluster scanforge-production \
  --service-name scanforge-api-service \
  --task-definition scanforge-api-production \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={
    subnets=[<private-subnet-1>,<private-subnet-2>],
    securityGroups=[<api-sg-id>],
    assignPublicIp=DISABLED
  }" \
  --load-balancers "targetGroupArn=<tg-arn>,containerName=scanforge-api,containerPort=8000" \
  --deployment-configuration "deploymentCircuitBreaker={enable=true,rollback=true}"
```

---

## Step 8: Application Load Balancer

```bash
# Create ALB
aws elbv2 create-load-balancer \
  --name scanforge-alb \
  --subnets <public-subnet-1> <public-subnet-2> \
  --security-groups <alb-sg-id> \
  --scheme internet-facing \
  --type application

# Create target group
aws elbv2 create-target-group \
  --name scanforge-api-tg \
  --protocol HTTP \
  --port 8000 \
  --vpc-id <vpc-id> \
  --target-type ip \
  --health-check-path /health \
  --health-check-interval-seconds 30 \
  --healthy-threshold-count 2 \
  --unhealthy-threshold-count 3

# Create HTTPS listener (requires ACM certificate)
aws elbv2 create-listener \
  --load-balancer-arn <alb-arn> \
  --protocol HTTPS \
  --port 443 \
  --certificates CertificateArn=<acm-cert-arn> \
  --default-actions Type=forward,TargetGroupArn=<tg-arn>
```

---

## Step 9: CloudFront CDN

Configure CloudFront for:
- Serving exported 3D models and APK downloads from S3
- Caching API responses for public endpoints
- Reducing latency for global users

```bash
aws cloudfront create-distribution \
  --distribution-config '{
    "Origins": {
      "Items": [{
        "Id": "scanforge-exports-s3",
        "DomainName": "scanforge-exports.s3.amazonaws.com",
        "S3OriginConfig": {"OriginAccessIdentity": ""}
      }]
    },
    "DefaultCacheBehavior": {
      "TargetOriginId": "scanforge-exports-s3",
      "ViewerProtocolPolicy": "redirect-to-https",
      "CachePolicyId": "658327ea-f89d-4fab-a63d-7e88639e58f6"
    },
    "Enabled": true,
    "PriceClass": "PriceClass_100"
  }'
```

---

## Step 10: Auto-Scaling

### API Service Auto-Scaling

```bash
# Register scalable target
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/scanforge-production/scanforge-api-service \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 \
  --max-capacity 10

# Scale on CPU utilization
aws application-autoscaling put-scaling-policy \
  --service-namespace ecs \
  --resource-id service/scanforge-production/scanforge-api-service \
  --scalable-dimension ecs:service:DesiredCount \
  --policy-name scanforge-api-cpu-scaling \
  --policy-type TargetTrackingScaling \
  --target-tracking-scaling-policy-configuration '{
    "TargetValue": 70.0,
    "PredefinedMetricSpecification": {
      "PredefinedMetricType": "ECSServiceAverageCPUUtilization"
    },
    "ScaleInCooldown": 300,
    "ScaleOutCooldown": 60
  }'
```

### Reconstruction Worker Scaling (Job Queue Based)

Scale reconstruction workers based on the Celery queue depth using a custom CloudWatch metric:

```bash
# Create custom metric alarm
aws cloudwatch put-metric-alarm \
  --alarm-name scanforge-reconstruction-queue-depth \
  --metric-name CeleryQueueDepth \
  --namespace ScanForge/Celery \
  --statistic Average \
  --period 60 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold \
  --alarm-actions <scale-out-policy-arn>
```

---

## Step 11: Route 53 DNS

```bash
# Create hosted zone
aws route53 create-hosted-zone \
  --name scanforge3d.com \
  --caller-reference $(date +%s)

# Create A record for API
aws route53 change-resource-record-sets \
  --hosted-zone-id <zone-id> \
  --change-batch '{
    "Changes": [{
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "api.scanforge3d.com",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "<alb-hosted-zone-id>",
          "DNSName": "<alb-dns-name>",
          "EvaluateTargetHealth": true
        }
      }
    }]
  }'
```

---

## Step 12: Monitoring and Alerting

### CloudWatch Dashboards

Create a CloudWatch dashboard with:
- ECS CPU and Memory utilization
- RDS connections and query latency
- Redis memory usage and hit rate
- ALB request count and 5xx error rate
- S3 storage usage

### CloudWatch Alarms

| Alarm | Metric | Threshold | Action |
|-------|--------|-----------|--------|
| High API Error Rate | ALB 5xx errors | >1% | SNS → Email/Slack |
| High CPU | ECS CPU | >85% | Auto-scale |
| DB Connections | RDS connections | >80% max | Alert |
| Redis Memory | ElastiCache memory | >80% | Alert |
| Low Disk (Reconstruction) | EFS storage | >90% | Alert |

---

## Step 13: GitHub Actions Secrets

Configure the following secrets in your GitHub repository settings:

| Secret Name | Description |
|-------------|-------------|
| `AWS_ACCOUNT_ID` | AWS account ID |
| `AWS_REGION` | AWS region (e.g., `us-east-1`) |
| `AWS_DEPLOY_ROLE_ARN` | ARN of the GitHub OIDC deploy role |
| `UNITY_LICENSE` | Unity license file content |
| `UNITY_EMAIL` | Unity account email |
| `UNITY_PASSWORD` | Unity account password |
| `ANDROID_KEYSTORE_BASE64` | Base64-encoded Android keystore |
| `ANDROID_KEYSTORE_PASS` | Keystore password |
| `ANDROID_KEY_ALIAS` | Key alias name |
| `ANDROID_KEY_ALIAS_PASS` | Key alias password |
| `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` | Google Play API service account JSON |
| `S3_BUCKET_EXPORTS` | Exports S3 bucket name |
| `CI_NOTIFICATION_TOKEN` | Token for backend build notifications |
| `SLACK_WEBHOOK_URL` | Slack webhook for deployment notifications |

---

## Step 14: Initial Deployment

```bash
# 1. Build and push Docker images
cd backend
docker build -t scanforge3d-api:latest .
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account>.dkr.ecr.us-east-1.amazonaws.com
docker tag scanforge3d-api:latest <account>.dkr.ecr.us-east-1.amazonaws.com/scanforge3d-api:latest
docker push <account>.dkr.ecr.us-east-1.amazonaws.com/scanforge3d-api:latest

# 2. Run database migrations
# Connect to the RDS instance via a bastion host or ECS exec
aws ecs execute-command \
  --cluster scanforge-production \
  --task <task-id> \
  --container scanforge-api \
  --interactive \
  --command "alembic upgrade head"

# 3. Verify deployment
curl https://api.scanforge3d.com/health
# Expected: {"status": "healthy", "version": "1.0.0", "timestamp": "..."}
```

---

## Cost Estimation

| Service | Configuration | Monthly Cost |
|---------|---------------|--------------|
| ECS Fargate (API, 2 tasks) | 1 vCPU, 2GB each | ~$60 |
| ECS Fargate (Reconstruction, 1 task) | 4 vCPU, 16GB | ~$120 |
| ECS Fargate (Worker, 1 task) | 2 vCPU, 4GB | ~$40 |
| RDS PostgreSQL | db.t3.medium, Multi-AZ | ~$80 |
| ElastiCache Redis | cache.t3.medium, 2 nodes | ~$50 |
| S3 Storage | 100GB + requests | ~$5 |
| CloudFront | 1TB transfer | ~$15 |
| ALB | Standard | ~$20 |
| **Total (estimated)** | | **~$390/month** |

> Costs can be reduced by ~30% using FARGATE_SPOT for non-critical workers and Reserved Instances for RDS.

---

## Troubleshooting

**ECS tasks failing to start:**
Check CloudWatch logs at `/ecs/scanforge-api`. Common causes: missing secrets, wrong image tag, insufficient memory.

**Database connection errors:**
Verify security group rules allow traffic from ECS task security group to RDS security group on port 5432.

**Reconstruction jobs timing out:**
Increase ECS task CPU/memory limits. The reconstruction service requires at least 4 vCPU and 8GB RAM for complex scans.

**S3 upload failures from mobile:**
Verify CORS configuration on the `scanforge-frames` bucket and that pre-signed URLs are generated with the correct region.
