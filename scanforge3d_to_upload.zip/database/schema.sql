-- ============================================================
-- ScanForge3D Database Schema
-- PostgreSQL 16
-- ============================================================
-- Tables:
--   users                  - User accounts
--   subscriptions          - Subscription tiers and limits
--   scan_jobs              - 3D scan job records
--   frame_batches          - Uploaded frame batch tracking
--   exports                - Generated export files
--   api_keys               - API key authentication
--   refresh_tokens         - JWT refresh token store
--   marketplace_listings   - External marketplace publish records
--   audit_log              - Security and change audit trail
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- For text search

-- ─── ENUMS ────────────────────────────────────────────────────────────────────

CREATE TYPE subscription_tier_enum AS ENUM ('free', 'pro', 'enterprise');

CREATE TYPE scan_job_status_enum AS ENUM (
    'pending',
    'uploading',
    'queued',
    'processing',
    'completed',
    'failed'
);

CREATE TYPE batch_status_enum AS ENUM ('pending', 'uploading', 'completed', 'failed');

CREATE TYPE export_format_enum AS ENUM ('obj', 'fbx', 'glb', 'usdz', 'stl');

CREATE TYPE export_quality_enum AS ENUM ('low', 'medium', 'high', 'ultra');

CREATE TYPE export_status_enum AS ENUM ('pending', 'processing', 'completed', 'failed');

-- ─── USERS ────────────────────────────────────────────────────────────────────

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email           VARCHAR(255) NOT NULL UNIQUE,
    display_name    VARCHAR(100) NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    is_verified     BOOLEAN NOT NULL DEFAULT FALSE,
    is_admin        BOOLEAN NOT NULL DEFAULT FALSE,
    avatar_url      VARCHAR(500),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_login_at   TIMESTAMPTZ
);

CREATE INDEX ix_users_email ON users (email);
CREATE INDEX ix_users_created_at ON users (created_at DESC);

-- Auto-update updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── SUBSCRIPTIONS ────────────────────────────────────────────────────────────

CREATE TABLE subscriptions (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                 UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    tier                    subscription_tier_enum NOT NULL DEFAULT 'free',
    stripe_customer_id      VARCHAR(255) UNIQUE,
    stripe_subscription_id  VARCHAR(255) UNIQUE,
    is_active               BOOLEAN NOT NULL DEFAULT TRUE,
    is_priority             BOOLEAN NOT NULL DEFAULT FALSE,
    scans_used_this_month   INTEGER NOT NULL DEFAULT 0 CHECK (scans_used_this_month >= 0),
    scans_limit             INTEGER NOT NULL DEFAULT 3,  -- -1 = unlimited
    current_period_start    TIMESTAMPTZ,
    current_period_end      TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_subscriptions_user_id ON subscriptions (user_id);
CREATE INDEX ix_subscriptions_stripe_customer ON subscriptions (stripe_customer_id);
CREATE INDEX ix_subscriptions_tier ON subscriptions (tier);

CREATE TRIGGER trigger_subscriptions_updated_at
    BEFORE UPDATE ON subscriptions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── SCAN JOBS ────────────────────────────────────────────────────────────────

CREATE TABLE scan_jobs (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                 UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    client_session_id       VARCHAR(255),
    status                  scan_job_status_enum NOT NULL DEFAULT 'pending',

    -- Frame data
    total_frames            INTEGER NOT NULL DEFAULT 0 CHECK (total_frames >= 0),
    frames_s3_prefix        VARCHAR(500),

    -- Reconstruction results
    mesh_s3_key             VARCHAR(500),
    mesh_url                VARCHAR(1000),
    thumbnail_url           VARCHAR(1000),
    confidence_score        FLOAT CHECK (confidence_score >= 0 AND confidence_score <= 100),
    processing_progress     FLOAT NOT NULL DEFAULT 0.0 CHECK (processing_progress >= 0 AND processing_progress <= 100),

    -- AI Classification
    object_class            VARCHAR(100),
    object_subcategory      VARCHAR(100),
    material_type           VARCHAR(100),
    estimated_volume_cm3    FLOAT CHECK (estimated_volume_cm3 >= 0),
    estimated_weight_grams  FLOAT CHECK (estimated_weight_grams >= 0),
    classification_confidence FLOAT CHECK (classification_confidence >= 0 AND classification_confidence <= 1),
    ai_tags                 JSONB,

    -- Error handling
    error_message           TEXT,
    retry_count             INTEGER NOT NULL DEFAULT 0 CHECK (retry_count >= 0),

    -- Metadata
    scan_metadata           JSONB,
    started_at              TIMESTAMPTZ,
    completed_at            TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_scan_jobs_user_id ON scan_jobs (user_id);
CREATE INDEX ix_scan_jobs_status ON scan_jobs (status);
CREATE INDEX ix_scan_jobs_user_status ON scan_jobs (user_id, status);
CREATE INDEX ix_scan_jobs_created_at ON scan_jobs (created_at DESC);
CREATE INDEX ix_scan_jobs_ai_tags ON scan_jobs USING GIN (ai_tags);

CREATE TRIGGER trigger_scan_jobs_updated_at
    BEFORE UPDATE ON scan_jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ─── FRAME BATCHES ────────────────────────────────────────────────────────────

CREATE TABLE frame_batches (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_job_id     UUID NOT NULL REFERENCES scan_jobs(id) ON DELETE CASCADE,
    batch_index     INTEGER NOT NULL CHECK (batch_index >= 0),
    s3_key          VARCHAR(500) NOT NULL,
    frame_count     INTEGER NOT NULL CHECK (frame_count > 0),
    file_size_bytes BIGINT CHECK (file_size_bytes >= 0),
    upload_status   batch_status_enum NOT NULL DEFAULT 'pending',
    uploaded_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (scan_job_id, batch_index)
);

CREATE INDEX ix_frame_batches_scan_job_id ON frame_batches (scan_job_id);

-- ─── EXPORTS ──────────────────────────────────────────────────────────────────

CREATE TABLE exports (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_job_id     UUID NOT NULL REFERENCES scan_jobs(id) ON DELETE CASCADE,
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    format          export_format_enum NOT NULL,
    quality         export_quality_enum NOT NULL DEFAULT 'medium',
    s3_key          VARCHAR(500),
    download_url    VARCHAR(1000),
    file_size_bytes BIGINT CHECK (file_size_bytes >= 0),
    is_watermarked  BOOLEAN NOT NULL DEFAULT TRUE,
    status          export_status_enum NOT NULL DEFAULT 'pending',
    expires_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_exports_scan_job_id ON exports (scan_job_id);
CREATE INDEX ix_exports_user_id ON exports (user_id);
CREATE INDEX ix_exports_status ON exports (status);

-- ─── API KEYS ─────────────────────────────────────────────────────────────────

CREATE TABLE api_keys (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name            VARCHAR(100) NOT NULL,
    key_hash        VARCHAR(64) NOT NULL UNIQUE,
    key_prefix      VARCHAR(10) NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    last_used_at    TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_api_keys_user_id ON api_keys (user_id);
CREATE INDEX ix_api_keys_key_hash ON api_keys (key_hash);

-- ─── REFRESH TOKENS ───────────────────────────────────────────────────────────

CREATE TABLE refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  VARCHAR(64) NOT NULL UNIQUE,
    is_revoked  BOOLEAN NOT NULL DEFAULT FALSE,
    expires_at  TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at  TIMESTAMPTZ
);

CREATE INDEX ix_refresh_tokens_user_id ON refresh_tokens (user_id);
CREATE INDEX ix_refresh_tokens_token_hash ON refresh_tokens (token_hash);
CREATE INDEX ix_refresh_tokens_active ON refresh_tokens (user_id, is_revoked)
    WHERE is_revoked = FALSE;

-- ─── MARKETPLACE LISTINGS ─────────────────────────────────────────────────────

CREATE TABLE marketplace_listings (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_job_id         UUID NOT NULL REFERENCES scan_jobs(id) ON DELETE CASCADE,
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    platform            VARCHAR(50) NOT NULL,
    external_listing_id VARCHAR(255),
    listing_url         VARCHAR(1000),
    title               VARCHAR(255) NOT NULL,
    description         TEXT,
    tags                JSONB,
    status              VARCHAR(50) NOT NULL DEFAULT 'pending',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_marketplace_listings_user_id ON marketplace_listings (user_id);
CREATE INDEX ix_marketplace_listings_platform ON marketplace_listings (platform);

-- ─── AUDIT LOG ────────────────────────────────────────────────────────────────

CREATE TABLE audit_log (
    id          BIGSERIAL PRIMARY KEY,
    user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
    action      VARCHAR(100) NOT NULL,
    resource    VARCHAR(100) NOT NULL,
    resource_id VARCHAR(255),
    ip_address  INET,
    user_agent  TEXT,
    details     JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ix_audit_log_user_id ON audit_log (user_id);
CREATE INDEX ix_audit_log_action ON audit_log (action);
CREATE INDEX ix_audit_log_created_at ON audit_log (created_at DESC);

-- Partition audit_log by month for performance (optional, for high-volume deployments)
-- CREATE TABLE audit_log_2026_03 PARTITION OF audit_log
--     FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');

-- ─── VIEWS ────────────────────────────────────────────────────────────────────

-- User dashboard summary view
CREATE OR REPLACE VIEW user_scan_summary AS
SELECT
    u.id AS user_id,
    u.email,
    u.display_name,
    s.tier AS subscription_tier,
    s.scans_used_this_month,
    s.scans_limit,
    COUNT(j.id) AS total_scans,
    COUNT(j.id) FILTER (WHERE j.status = 'completed') AS completed_scans,
    COUNT(j.id) FILTER (WHERE j.status = 'failed') AS failed_scans,
    AVG(j.confidence_score) FILTER (WHERE j.status = 'completed') AS avg_confidence,
    MAX(j.created_at) AS last_scan_at
FROM users u
LEFT JOIN subscriptions s ON s.user_id = u.id
LEFT JOIN scan_jobs j ON j.user_id = u.id
GROUP BY u.id, u.email, u.display_name, s.tier, s.scans_used_this_month, s.scans_limit;

-- ─── INITIAL DATA ─────────────────────────────────────────────────────────────

-- Create admin user (password: change_immediately)
INSERT INTO users (email, display_name, password_hash, is_active, is_verified, is_admin)
VALUES (
    'admin@scanforge3d.com',
    'ScanForge Admin',
    '$2b$12$placeholder_hash_change_immediately',
    TRUE,
    TRUE,
    TRUE
) ON CONFLICT DO NOTHING;

-- ─── MAINTENANCE ──────────────────────────────────────────────────────────────

-- Cleanup expired refresh tokens (run periodically via pg_cron or cron job)
-- DELETE FROM refresh_tokens WHERE expires_at < NOW() - INTERVAL '7 days';

-- Cleanup expired exports
-- DELETE FROM exports WHERE expires_at < NOW();

COMMENT ON TABLE users IS 'User accounts for the ScanForge3D platform';
COMMENT ON TABLE subscriptions IS 'Subscription tiers: free (3 scans/mo), pro (unlimited), enterprise (priority)';
COMMENT ON TABLE scan_jobs IS 'Individual 3D scan reconstruction jobs';
COMMENT ON TABLE frame_batches IS 'Batched frame uploads for memory-efficient mobile capture';
COMMENT ON TABLE exports IS '3D model exports in various formats (OBJ, FBX, GLB, USDZ, STL)';
COMMENT ON TABLE marketplace_listings IS 'Published listings on external 3D marketplaces';
COMMENT ON TABLE audit_log IS 'Security and compliance audit trail';
