# ScanForge3D — Production-Ready 3D Scanning Mobile App

A complete, production-grade 3D scanning platform for Android. Photogrammetry-based object scanning with AI classification, marketplace publishing, and in-app APK/Google Play deployment.

---

## Project Structure

```
scanforge3d/
├── unity-project/                  # Unity Android App (C#)
│   ├── Assets/
│   │   ├── Scripts/
│   │   │   ├── Scanning/           # ScanManager, LightingAnalyzer, BackgroundRemover
│   │   │   ├── AI/                 # AIClassifier (classification, material, volume, weight)
│   │   │   ├── UI/                 # ScanHUD, PublishingUI
│   │   │   ├── Networking/         # ApiClient (JWT, signed URLs, streaming)
│   │   │   ├── Publishing/         # PublishingManager (APK, Google Play, Marketplace)
│   │   │   └── Utils/              # AuthManager, AppConfig, LazyTextureLoader
│   │   └── Editor/
│   │       └── BuildScripts/       # BuildAndroid.cs (CI/CD automated builds)
│   ├── Packages/manifest.json
│   └── ProjectSettings/
│
├── backend/                        # FastAPI Backend (Python)
│   ├── app/
│   │   ├── api/v1/endpoints/       # auth, scans, ai, builds, marketplace, subscriptions, users
│   │   ├── core/                   # config, database, security, redis_client
│   │   ├── models/                 # SQLAlchemy models
│   │   ├── services/               # virus_scanner
│   │   └── workers/                # Celery tasks (reconstruction, export, virus scan)
│   ├── alembic/                    # Database migrations
│   ├── Dockerfile
│   └── requirements.txt
│
├── reconstruction-server/          # Photogrammetry Microservice (Python)
│   ├── src/main.py                 # COLMAP + OpenMVS pipeline
│   ├── Dockerfile
│   └── requirements.txt
│
├── database/
│   └── schema.sql                  # Full PostgreSQL schema (9 tables, 24 indexes)
│
├── nginx/conf.d/                   # Nginx reverse proxy config
│
├── .github/workflows/              # CI/CD Pipelines
│   ├── backend-ci-cd.yml           # Test → Security → Build → Deploy (staging + prod)
│   ├── unity-android-build.yml     # Unity build → Sign → S3 → Google Play
│   └── reconstruction-ci-cd.yml   # Reconstruction server CI/CD
│
└── docs/
    ├── API_DOCUMENTATION.md        # Complete REST API reference
    ├── AWS_DEPLOYMENT_GUIDE.md     # Step-by-step AWS deployment (ECS, RDS, Redis, S3)
    └── ui-mock/index.html          # Interactive dark UI prototype
```

---

## Quick Start

### 1. Backend (Local Development)

```bash
cd backend

# Create virtual environment
python3 -m venv venv && source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy environment file
cp ../.env.example .env
# Edit .env with your database URL, Redis URL, AWS keys, etc.

# Run database migrations
alembic upgrade head

# Start the API server
uvicorn app.main:app --reload --port 8000

# Start Celery worker (separate terminal)
celery -A app.workers.tasks.celery_app worker -Q reconstruction,exports,security,notifications -c 4
```

API available at: http://localhost:8000  
Swagger docs: http://localhost:8000/docs

### 2. Full Stack with Docker

```bash
# Copy and configure environment
cp .env.example .env
# Edit .env with your secrets

# Start all services
docker-compose up -d

# Run migrations
docker-compose exec api alembic upgrade head

# Check health
curl http://localhost/health
```

Services started:
- **API**: http://localhost:8000
- **Reconstruction**: http://localhost:8001
- **Flower** (Celery monitor): http://localhost:5555
- **Grafana** (metrics): http://localhost:3000
- **Prometheus**: http://localhost:9090

### 3. Unity Project

1. Open `unity-project/` in Unity 2022.3 LTS or later
2. Install required packages from `Packages/manifest.json`
3. Configure `AppConfig` ScriptableObject with your API base URL
4. Build for Android: **File → Build Settings → Android → Build**

---

## Key Features

### Advanced Features
| Feature | Implementation |
|---------|----------------|
| AI Object Classification | `AIClassifier.cs` + `/api/v1/ai/classify` (OpenAI GPT-4 Vision) |
| Material Type Detection | Material density table + server-side inference |
| Volume & Weight Estimation | Divergence theorem on mesh geometry |
| Marketplace Export | Sketchfab, CGTrader, TurboSquid, Fab via `/api/v1/marketplace/publish` |
| Background Removal | `BackgroundRemover.cs` + `/api/v1/ai/remove-background` |
| Multi-Object Separation | `/api/v1/ai/separate-objects` |
| Scan Comparison (Before/After) | `GenerateScanComparison()` + `/api/v1/scans/compare` |

### Publishing System
| Target | How |
|--------|-----|
| Google Play | GitHub Actions `r0adkll/upload-google-play` → Internal → Alpha → Production |
| APK Download | Signed APK built by CI/CD, uploaded to S3, pre-signed URL returned |
| In-App Trigger | `PublishingManager.cs` → `POST /api/v1/builds/apk` → GitHub Actions dispatch |
| Marketplace | `PublishingManager.PublishToMarketplace()` → `/api/v1/marketplace/publish` |

### Subscription Tiers
| Tier | Scans/Month | Exports | Priority | Watermark |
|------|-------------|---------|----------|-----------|
| Free | 3 | Standard (watermarked) | Normal | Yes |
| Pro | Unlimited | All formats, 4K | Normal | No |
| Enterprise | Unlimited | All formats, 4K | Priority queue | No |

---

## API Overview

Base URL: `https://api.scanforge3d.com/api/v1`

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/register` | Create account |
| POST | `/auth/login` | Get JWT tokens |
| POST | `/scans/` | Create scan job |
| POST | `/scans/upload-url` | Get signed S3 upload URL |
| POST | `/scans/{id}/reconstruct` | Start 3D reconstruction |
| GET | `/scans/{id}/status` | Poll reconstruction status |
| POST | `/scans/export` | Export model (OBJ/FBX/GLB/USDZ/STL) |
| POST | `/scans/compare` | Compare two scans (before/after) |
| POST | `/ai/classify` | AI object classification |
| POST | `/ai/remove-background` | Remove background from scan |
| POST | `/marketplace/publish` | Publish to 3D marketplace |
| POST | `/builds/apk` | Request signed APK build |
| GET | `/builds/{id}/status` | Check build status |
| POST | `/builds/notify` | CI/CD build completion webhook |

Full documentation: `docs/API_DOCUMENTATION.md`

---

## AWS Deployment

See `docs/AWS_DEPLOYMENT_GUIDE.md` for the complete step-by-step guide covering:

- VPC, subnets, and security groups
- ECS Fargate services (API, Workers, Reconstruction)
- RDS PostgreSQL (Multi-AZ)
- ElastiCache Redis cluster
- S3 buckets with lifecycle policies
- CloudFront CDN
- Application Load Balancer
- Auto-scaling policies
- Route 53 DNS
- CloudWatch monitoring and alarms
- GitHub Actions secrets configuration

Estimated cost: **~$390/month** (production, moderate traffic)

---

## CI/CD Pipeline

Three GitHub Actions workflows:

1. **`backend-ci-cd.yml`**: Lint → Type check → Test (pytest, 70% coverage) → Security scan (Trivy) → Docker build → Deploy staging → Deploy production (Blue/Green)

2. **`unity-android-build.yml`**: Unity tests → Build Android AAB/APK → Sign with keystore → Upload to S3 → Publish to Google Play Internal → Promote to Alpha

3. **`reconstruction-ci-cd.yml`**: Build reconstruction Docker image → Push to ECR → Deploy to ECS

---

## Security

- JWT access tokens (15 min expiry) + refresh tokens (30 days)
- Bcrypt password hashing
- Pre-signed S3 upload URLs (15 min expiry)
- ClamAV virus scanning on all uploads
- File type validation (MIME + extension)
- Rate limiting per IP (slowapi)
- Security headers (HSTS, CSP, X-Frame-Options)
- Encrypted RDS storage (AWS KMS)
- Redis TLS in transit

---

## License

MIT License — See LICENSE file for details.
