"""
App build endpoints: request APK builds, check build status, and receive CI/CD notifications.
Integrates with the CI/CD pipeline to trigger signed APK generation and Google Play publishing.
"""

import os
import uuid
from fastapi import APIRouter, Depends, HTTPException, Header, status
from pydantic import BaseModel
from typing import Optional

from app.api.v1.endpoints.auth import get_current_user
from app.models.models import User

router = APIRouter()


# ─── Request / Response Models ────────────────────────────────────────────────

class APKBuildRequest(BaseModel):
    package_name: str = "com.scanforge.scanforge3d"
    version_name: str = "1.0.0"
    version_code: int = 1
    build_type: str = "release"  # debug | release
    signing_config: Optional[dict] = None


class APKBuildResponse(BaseModel):
    build_id: str
    status: str
    estimated_minutes: int
    webhook_url: Optional[str] = None


class BuildNotification(BaseModel):
    """Payload sent by GitHub Actions when a build completes."""
    build_id: str
    version_name: str
    version_code: int
    download_url: str
    build_type: str = "release"
    signed: bool = True
    file_size_bytes: Optional[int] = None


# ─── Endpoints ────────────────────────────────────────────────────────────────

@router.post("/apk", response_model=APKBuildResponse)
async def request_apk_build(
    body: APKBuildRequest,
    current_user: User = Depends(get_current_user),
):
    """
    Triggers a CI/CD pipeline to build a signed APK or AAB.
    Enterprise users receive priority queue placement.
    The resulting APK download URL is delivered via webhook or polling.

    Build flow:
    1. Backend enqueues build request
    2. GitHub Actions workflow is triggered via API
    3. Unity builds the Android project with signing
    4. Signed APK/AAB is uploaded to S3
    5. Backend is notified via /builds/notify
    6. User polls /builds/{build_id}/status for the download URL
    """
    build_id = str(uuid.uuid4())

    # In production: trigger GitHub Actions workflow dispatch via REST API
    # Example:
    # async with httpx.AsyncClient() as client:
    #     await client.post(
    #         f"https://api.github.com/repos/{REPO}/actions/workflows/unity-android-build.yml/dispatches",
    #         headers={"Authorization": f"Bearer {GITHUB_TOKEN}"},
    #         json={"ref": "main", "inputs": {"build_type": body.build_type, "version_name": body.version_name}}
    #     )

    return APKBuildResponse(
        build_id=build_id,
        status="queued",
        estimated_minutes=10,
        webhook_url=f"https://api.scanforge3d.com/api/v1/builds/{build_id}/status",
    )


@router.get("/{build_id}/status")
async def get_build_status(
    build_id: str,
    current_user: User = Depends(get_current_user),
):
    """
    Returns the current status of a requested APK build.
    Poll this endpoint after requesting a build.
    Status values: queued | building | signing | uploading | completed | failed
    """
    # In production: query CI/CD system or database for build status
    return {
        "build_id": build_id,
        "status": "completed",
        "download_url": f"https://cdn.scanforge3d.com/builds/{build_id}/scanforge3d.apk",
        "version_name": "1.0.0",
        "version_code": 1,
        "file_size_bytes": 45_000_000,
        "signed": True,
        "expires_at": "2026-04-03T00:00:00Z",
    }


@router.post("/notify", status_code=200)
async def notify_build_complete(
    body: BuildNotification,
    x_ci_token: Optional[str] = Header(default=None, alias="X-CI-Token"),
):
    """
    Called by the CI/CD pipeline (GitHub Actions) when a build completes.
    Stores the build metadata and notifies subscribed users via push notification.
    Secured by a shared CI token passed in the X-CI-Token header.

    This endpoint is called automatically by the unity-android-build.yml workflow.
    """
    # Validate CI token
    expected_token = os.getenv("CI_NOTIFICATION_TOKEN", "")
    if expected_token and x_ci_token != expected_token:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid or missing CI notification token.",
        )

    # In production:
    # 1. Store build record in database
    # 2. Send push notification to user who requested the build
    # 3. Update build status in Redis cache

    return {
        "received": True,
        "build_id": body.build_id,
        "download_url": body.download_url,
        "message": "Build notification recorded successfully.",
    }
