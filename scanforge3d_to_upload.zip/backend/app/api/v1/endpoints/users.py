"""
User profile management endpoints.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.endpoints.auth import get_current_user
from app.core.database import get_db
from app.models.models import User

router = APIRouter()


class UpdateProfileRequest(BaseModel):
    display_name: str = None
    avatar_url: str = None


@router.get("/me")
async def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """Returns the current user's profile."""
    return {
        "id": str(current_user.id),
        "email": current_user.email,
        "display_name": current_user.display_name,
        "avatar_url": current_user.avatar_url,
        "is_verified": current_user.is_verified,
        "created_at": current_user.created_at.isoformat(),
    }


@router.patch("/me")
async def update_profile(
    body: UpdateProfileRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Updates the current user's profile fields."""
    if body.display_name:
        current_user.display_name = body.display_name
    if body.avatar_url:
        current_user.avatar_url = body.avatar_url
    await db.commit()
    return {"message": "Profile updated successfully."}


@router.delete("/me", status_code=status.HTTP_204_NO_CONTENT)
async def delete_account(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Permanently deletes the user account and all associated data."""
    await db.delete(current_user)
    await db.commit()
