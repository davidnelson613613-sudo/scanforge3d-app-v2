"""
Authentication endpoints: register, login, refresh token, logout.
Implements JWT-based auth with refresh token rotation and rate limiting.
"""

import hashlib
from datetime import datetime, timezone, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError
from pydantic import BaseModel, EmailStr, Field
from slowapi import Limiter
from slowapi.util import get_remote_address
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import (
    create_access_token, create_refresh_token,
    decode_token, hash_password, verify_password,
)
from app.core.redis_client import blacklist_token, is_token_blacklisted
from app.core.config import settings
from app.models.models import User, Subscription, RefreshToken

router = APIRouter()
limiter = Limiter(key_func=get_remote_address)
security = HTTPBearer()


# ─── Request/Response Schemas ─────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    display_name: str = Field(min_length=2, max_length=100)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: dict


# ─── Dependency: Get Current User ─────────────────────────────────────────────
async def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(security)],
    db: AsyncSession = Depends(get_db),
) -> User:
    """Validates JWT and returns the authenticated user."""
    token = credentials.credentials
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired authentication token.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = decode_token(token)
        user_id: str = payload.get("user_id")
        jti: str = payload.get("jti")

        if user_id is None:
            raise credentials_exception

        # Check token blacklist
        if jti and await is_token_blacklisted(jti):
            raise credentials_exception

    except JWTError:
        raise credentials_exception

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if user is None or not user.is_active:
        raise credentials_exception

    return user


# ─── Endpoints ────────────────────────────────────────────────────────────────
@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
@limiter.limit(settings.RATE_LIMIT_AUTH)
async def register(
    request: Request,
    body: RegisterRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Registers a new user account.
    Creates a free-tier subscription automatically.
    """
    # Check if email already exists
    result = await db.execute(select(User).where(User.email == body.email))
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An account with this email already exists.",
        )

    # Create user
    user = User(
        email=body.email,
        display_name=body.display_name,
        password_hash=hash_password(body.password),
    )
    db.add(user)
    await db.flush()  # Get the user ID before creating subscription

    # Create free subscription
    subscription = Subscription(
        user_id=user.id,
        tier="free",
        scans_limit=settings.FREE_SCANS_PER_MONTH,
    )
    db.add(subscription)
    await db.commit()
    await db.refresh(user)

    return _create_token_response(user)


@router.post("/login", response_model=TokenResponse)
@limiter.limit(settings.RATE_LIMIT_AUTH)
async def login(
    request: Request,
    body: LoginRequest,
    db: AsyncSession = Depends(get_db),
):
    """Authenticates a user and returns JWT access and refresh tokens."""
    result = await db.execute(select(User).where(User.email == body.email))
    user = result.scalar_one_or_none()

    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is deactivated. Please contact support.",
        )

    # Update last login
    user.last_login_at = datetime.now(timezone.utc)
    await db.commit()

    return _create_token_response(user)


@router.post("/refresh", response_model=TokenResponse)
@limiter.limit("20/minute")
async def refresh_token(
    request: Request,
    body: RefreshRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Exchanges a valid refresh token for a new access token.
    Implements refresh token rotation for security.
    """
    token_hash = hashlib.sha256(body.refresh_token.encode()).hexdigest()

    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == token_hash,
            RefreshToken.is_revoked == False,
        )
    )
    stored_token = result.scalar_one_or_none()

    if not stored_token or stored_token.expires_at < datetime.now(timezone.utc):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token.",
        )

    # Revoke old refresh token (rotation)
    stored_token.is_revoked = True
    stored_token.revoked_at = datetime.now(timezone.utc)

    # Get user
    result = await db.execute(select(User).where(User.id == stored_token.user_id))
    user = result.scalar_one_or_none()

    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found.")

    await db.commit()
    return _create_token_response(user)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(security)],
    db: AsyncSession = Depends(get_db),
):
    """Revokes the current access token by adding it to the blacklist."""
    try:
        payload = decode_token(credentials.credentials)
        jti = payload.get("jti")
        exp = payload.get("exp", 0)

        if jti:
            remaining_ttl = max(0, int(exp - datetime.now(timezone.utc).timestamp()))
            await blacklist_token(jti, remaining_ttl)
    except JWTError:
        pass  # Token already invalid, no action needed


# ─── Helpers ──────────────────────────────────────────────────────────────────
def _create_token_response(user: User) -> dict:
    """Creates the standard token response payload."""
    tier = user.subscription.tier if user.subscription else "free"
    access_token = create_access_token(
        subject=user.email,
        user_id=str(user.id),
        subscription_tier=tier,
    )
    refresh_token_value = create_refresh_token(
        subject=user.email,
        user_id=str(user.id),
    )

    return {
        "access_token": access_token,
        "refresh_token": refresh_token_value,
        "token_type": "bearer",
        "expires_in": settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        "user": {
            "id": str(user.id),
            "email": user.email,
            "display_name": user.display_name,
            "subscription_tier": tier,
            "scans_remaining": (
                user.subscription.scans_limit - user.subscription.scans_used_this_month
                if user.subscription and user.subscription.scans_limit != -1
                else -1
            ),
        },
    }
