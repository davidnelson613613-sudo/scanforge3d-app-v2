"""
Scan job endpoints: create job, upload frames, trigger reconstruction,
poll status, list scans, compare scans, and export.
"""

import uuid
from datetime import datetime, timezone
from typing import Annotated, List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from pydantic import BaseModel
from slowapi import Limiter
from slowapi.util import get_remote_address
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.endpoints.auth import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.core.redis_client import (
    enqueue_reconstruction_job,
    increment_user_scan_count,
    get_user_scan_count,
    cache_set,
    cache_get,
)
from app.core.security import (
    generate_signed_upload_url,
    generate_signed_download_url,
    validate_file_type,
    validate_file_size,
)
from app.models.models import ScanJob, FrameBatch, User, Subscription, Export
from app.services.virus_scanner import scan_file_for_viruses

router = APIRouter()
limiter = Limiter(key_func=get_remote_address)


# ─── Request/Response Schemas ─────────────────────────────────────────────────
class CreateJobRequest(BaseModel):
    client_session_id: Optional[str] = None
    started_at: Optional[str] = None
    scan_metadata: Optional[dict] = None


class CreateJobResponse(BaseModel):
    job_id: str
    status: str
    frames_s3_prefix: str


class SignedUploadUrlRequest(BaseModel):
    job_id: str
    batch_index: int
    frame_count: int = 1


class SignedUploadUrlResponse(BaseModel):
    upload_url: str
    expires_at: str
    batch_id: str
    s3_key: str


class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    confidence_score: Optional[float] = None
    processing_progress: float = 0.0
    mesh_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    object_class: Optional[str] = None
    material_type: Optional[str] = None
    estimated_volume_cm3: Optional[float] = None
    estimated_weight_grams: Optional[float] = None
    error_message: Optional[str] = None
    created_at: str
    completed_at: Optional[str] = None


class ExportRequest(BaseModel):
    job_id: str
    format: str  # obj, fbx, glb, usdz, stl
    resolution: str = "medium"


class CompareRequest(BaseModel):
    job_id_before: str
    job_id_after: str


# ─── Endpoints ────────────────────────────────────────────────────────────────
@router.post("/jobs", response_model=CreateJobResponse, status_code=status.HTTP_201_CREATED)
@limiter.limit(settings.RATE_LIMIT_FREE)
async def create_scan_job(
    request: Request,
    body: CreateJobRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Creates a new scan job. Enforces subscription scan limits.
    Free tier: 3 scans/month. Pro: unlimited. Enterprise: priority.
    """
    # Check subscription limits
    subscription = await _get_subscription(current_user.id, db)
    await _enforce_scan_limit(current_user, subscription)

    job_id = str(uuid.uuid4())
    frames_prefix = f"frames/{current_user.id}/{job_id}"

    job = ScanJob(
        id=job_id,
        user_id=current_user.id,
        client_session_id=body.client_session_id,
        status="pending",
        frames_s3_prefix=frames_prefix,
        scan_metadata=body.scan_metadata,
        started_at=datetime.now(timezone.utc),
    )
    db.add(job)

    # Increment scan count for rate limiting
    month_key = datetime.now(timezone.utc).strftime("%Y-%m")
    await increment_user_scan_count(str(current_user.id), month_key)

    await db.commit()

    return CreateJobResponse(
        job_id=job_id,
        status="pending",
        frames_s3_prefix=frames_prefix,
    )


@router.post("/upload-url", response_model=SignedUploadUrlResponse)
async def get_upload_url(
    body: SignedUploadUrlRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Returns a pre-signed S3 URL for direct frame batch upload.
    Signed URLs expire after 15 minutes for security.
    """
    job = await _get_job_or_404(body.job_id, current_user.id, db)

    if job.status not in ("pending", "uploading"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot upload to job in status '{job.status}'.",
        )

    batch_id = str(uuid.uuid4())
    s3_key = f"{job.frames_s3_prefix}/batch_{body.batch_index:04d}_{batch_id}.zip"

    # Generate signed upload URL
    upload_url = generate_signed_upload_url(
        bucket=settings.S3_BUCKET_FRAMES,
        key=s3_key,
        content_type="application/zip",
        expiry=settings.S3_UPLOAD_URL_EXPIRY,
    )

    # Record the batch
    batch = FrameBatch(
        scan_job_id=job.id,
        batch_index=body.batch_index,
        s3_key=s3_key,
        frame_count=body.frame_count,
        upload_status="pending",
    )
    db.add(batch)

    # Update job status to uploading
    if job.status == "pending":
        job.status = "uploading"

    await db.commit()

    from datetime import timedelta
    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=settings.S3_UPLOAD_URL_EXPIRY)).isoformat()

    return SignedUploadUrlResponse(
        upload_url=upload_url,
        expires_at=expires_at,
        batch_id=batch_id,
        s3_key=s3_key,
    )


@router.post("/jobs/{job_id}/reconstruct")
async def trigger_reconstruction(
    job_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Triggers the 3D reconstruction pipeline for a completed upload.
    Enqueues the job with priority based on subscription tier.
    """
    job = await _get_job_or_404(job_id, current_user.id, db)

    if job.status not in ("uploading", "pending"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Job cannot be reconstructed from status '{job.status}'.",
        )

    subscription = await _get_subscription(current_user.id, db)
    is_priority = subscription.is_priority if subscription else False

    # Enqueue reconstruction job
    job_data = {
        "job_id": job_id,
        "user_id": str(current_user.id),
        "frames_s3_prefix": job.frames_s3_prefix,
        "priority": "high" if is_priority else "normal",
        "retry_count": job.retry_count,
    }
    await enqueue_reconstruction_job(job_data)

    job.status = "queued"
    await db.commit()

    return {"job_id": job_id, "status": "queued", "priority": job_data["priority"]}


@router.get("/jobs/{job_id}/status", response_model=JobStatusResponse)
async def get_job_status(
    job_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Returns the current status and results of a scan job."""
    # Try cache first
    cache_key = f"job_status:{job_id}"
    cached = await cache_get(cache_key)
    if cached and cached.get("status") == "completed":
        return cached

    job = await _get_job_or_404(job_id, current_user.id, db)

    # Generate signed download URL for mesh if completed
    mesh_url = None
    if job.mesh_s3_key and job.status == "completed":
        mesh_url = generate_signed_download_url(
            bucket=settings.S3_BUCKET_MESHES,
            key=job.mesh_s3_key,
        )

    response = JobStatusResponse(
        job_id=str(job.id),
        status=job.status,
        confidence_score=job.confidence_score,
        processing_progress=job.processing_progress,
        mesh_url=mesh_url,
        thumbnail_url=job.thumbnail_url,
        object_class=job.object_class,
        material_type=job.material_type,
        estimated_volume_cm3=job.estimated_volume_cm3,
        estimated_weight_grams=job.estimated_weight_grams,
        error_message=job.error_message,
        created_at=job.created_at.isoformat(),
        completed_at=job.completed_at.isoformat() if job.completed_at else None,
    )

    # Cache completed jobs for 1 hour
    if job.status == "completed":
        await cache_set(cache_key, response.model_dump(), ttl=3600)

    return response


@router.get("/", response_model=dict)
async def list_user_scans(
    request: Request,
    page: int = 1,
    page_size: int = 20,
    status_filter: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Returns a paginated list of the user's scan jobs."""
    page_size = min(page_size, 100)
    offset = (page - 1) * page_size

    query = select(ScanJob).where(ScanJob.user_id == current_user.id)
    if status_filter:
        query = query.where(ScanJob.status == status_filter)

    query = query.order_by(ScanJob.created_at.desc()).offset(offset).limit(page_size)
    result = await db.execute(query)
    jobs = result.scalars().all()

    count_result = await db.execute(
        select(func.count(ScanJob.id)).where(ScanJob.user_id == current_user.id)
    )
    total = count_result.scalar()

    return {
        "scans": [
            {
                "job_id": str(j.id),
                "status": j.status,
                "confidence_score": j.confidence_score,
                "object_class": j.object_class,
                "thumbnail_url": j.thumbnail_url,
                "created_at": j.created_at.isoformat(),
            }
            for j in jobs
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("/export", response_model=dict)
async def export_scan(
    body: ExportRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Exports a completed scan in the requested format.
    Free tier exports include a watermark. Pro/Enterprise: watermark-free.
    """
    job = await _get_job_or_404(body.job_id, current_user.id, db)

    if job.status != "completed":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only completed scans can be exported.",
        )

    subscription = await _get_subscription(current_user.id, db)
    is_pro = subscription and subscription.tier in ("pro", "enterprise")
    is_watermarked = not is_pro

    # Create export record
    export_id = str(uuid.uuid4())
    export = Export(
        id=export_id,
        scan_job_id=job.id,
        user_id=current_user.id,
        format=body.format.lower(),
        quality=body.resolution,
        is_watermarked=is_watermarked,
        status="pending",
    )
    db.add(export)
    await db.commit()

    # Enqueue export task (Celery)
    from app.workers.tasks import process_export
    process_export.delay(export_id, str(job.id), body.format, body.resolution, is_watermarked)

    return {
        "export_id": export_id,
        "status": "pending",
        "format": body.format,
        "watermarked": is_watermarked,
        "message": "Export queued. Check status at /exports/{export_id}",
    }


@router.post("/compare", response_model=dict)
async def compare_scans(
    body: CompareRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Generates a before/after comparison report between two scan jobs.
    Returns volume change, surface area change, and a comparison image.
    """
    job_before = await _get_job_or_404(body.job_id_before, current_user.id, db)
    job_after = await _get_job_or_404(body.job_id_after, current_user.id, db)

    if job_before.status != "completed" or job_after.status != "completed":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Both scans must be completed before comparison.",
        )

    volume_change = (
        (job_after.estimated_volume_cm3 or 0) - (job_before.estimated_volume_cm3 or 0)
    )
    confidence_delta = (
        (job_after.confidence_score or 0) - (job_before.confidence_score or 0)
    )

    return {
        "job_id_before": body.job_id_before,
        "job_id_after": body.job_id_after,
        "volume_change_cm3": round(volume_change, 2),
        "surface_area_change_cm2": 0.0,  # Computed by reconstruction server
        "confidence_delta": round(confidence_delta, 2),
        "comparison_image_url": None,  # Generated asynchronously
        "summary": (
            f"Volume {'increased' if volume_change > 0 else 'decreased'} by "
            f"{abs(volume_change):.1f} cm³. "
            f"Confidence {'improved' if confidence_delta > 0 else 'decreased'} by "
            f"{abs(confidence_delta):.1f} points."
        ),
    }


@router.delete("/jobs/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_scan_job(
    job_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Deletes a scan job and all associated data (frames, exports)."""
    job = await _get_job_or_404(job_id, current_user.id, db)
    await db.delete(job)
    await db.commit()


# ─── Helpers ──────────────────────────────────────────────────────────────────
async def _get_job_or_404(job_id: str, user_id, db: AsyncSession) -> ScanJob:
    result = await db.execute(
        select(ScanJob).where(ScanJob.id == job_id, ScanJob.user_id == user_id)
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Scan job not found.")
    return job


async def _get_subscription(user_id, db: AsyncSession) -> Optional[Subscription]:
    result = await db.execute(select(Subscription).where(Subscription.user_id == user_id))
    return result.scalar_one_or_none()


async def _enforce_scan_limit(user: User, subscription: Optional[Subscription]):
    if subscription is None or subscription.tier == "free":
        limit = settings.FREE_SCANS_PER_MONTH
        month_key = datetime.now(timezone.utc).strftime("%Y-%m")
        used = await get_user_scan_count(str(user.id), month_key)
        if used >= limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=(
                    f"Free tier limit of {limit} scans/month reached. "
                    "Upgrade to Pro for unlimited scans."
                ),
            )
