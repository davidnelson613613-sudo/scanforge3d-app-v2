"""
Subscription management endpoints: status, upgrade, Stripe webhooks.
"""

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.endpoints.auth import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.models.models import User, Subscription

router = APIRouter()


@router.get("/status")
async def get_subscription_status(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Returns the current user's subscription tier and scan quota."""
    result = await db.execute(
        select(Subscription).where(Subscription.user_id == current_user.id)
    )
    sub = result.scalar_one_or_none()

    if not sub:
        return {
            "tier": "free",
            "scans_used": 0,
            "scans_limit": settings.FREE_SCANS_PER_MONTH,
            "scans_remaining": settings.FREE_SCANS_PER_MONTH,
            "is_priority": False,
            "renewal_date": None,
        }

    scans_remaining = (
        sub.scans_limit - sub.scans_used_this_month
        if sub.scans_limit != -1 else -1
    )

    return {
        "tier": sub.tier,
        "scans_used": sub.scans_used_this_month,
        "scans_limit": sub.scans_limit,
        "scans_remaining": scans_remaining,
        "is_priority": sub.is_priority,
        "renewal_date": sub.current_period_end.isoformat() if sub.current_period_end else None,
    }


@router.post("/create-checkout")
async def create_checkout_session(
    body: dict,
    current_user: User = Depends(get_current_user),
):
    """Creates a Stripe checkout session for subscription upgrade."""
    tier = body.get("tier", "pro")

    if not settings.STRIPE_SECRET_KEY:
        raise HTTPException(status_code=503, detail="Payment service not configured.")

    import stripe
    stripe.api_key = settings.STRIPE_SECRET_KEY

    price_id = (
        settings.STRIPE_PRO_PRICE_ID if tier == "pro"
        else settings.STRIPE_ENTERPRISE_PRICE_ID
    )

    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{"price": price_id, "quantity": 1}],
        mode="subscription",
        success_url="https://app.scanforge3d.com/subscription/success",
        cancel_url="https://app.scanforge3d.com/subscription/cancel",
        metadata={"user_id": str(current_user.id)},
    )

    return {"checkout_url": session.url}


@router.post("/webhook")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    """Handles Stripe webhook events for subscription lifecycle management."""
    import stripe
    stripe.api_key = settings.STRIPE_SECRET_KEY

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
        )
    except (ValueError, stripe.error.SignatureVerificationError):
        raise HTTPException(status_code=400, detail="Invalid webhook signature.")

    event_type = event["type"]

    if event_type == "customer.subscription.created":
        await _handle_subscription_created(event["data"]["object"], db)
    elif event_type == "customer.subscription.deleted":
        await _handle_subscription_cancelled(event["data"]["object"], db)
    elif event_type == "invoice.payment_succeeded":
        await _handle_payment_succeeded(event["data"]["object"], db)

    return {"status": "ok"}


async def _handle_subscription_created(subscription_data: dict, db: AsyncSession):
    user_id = subscription_data.get("metadata", {}).get("user_id")
    if not user_id:
        return

    result = await db.execute(select(Subscription).where(Subscription.user_id == user_id))
    sub = result.scalar_one_or_none()

    if sub:
        sub.tier = "pro"
        sub.stripe_subscription_id = subscription_data["id"]
        sub.scans_limit = -1
        sub.is_active = True
        await db.commit()


async def _handle_subscription_cancelled(subscription_data: dict, db: AsyncSession):
    stripe_sub_id = subscription_data["id"]
    result = await db.execute(
        select(Subscription).where(Subscription.stripe_subscription_id == stripe_sub_id)
    )
    sub = result.scalar_one_or_none()
    if sub:
        sub.tier = "free"
        sub.scans_limit = settings.FREE_SCANS_PER_MONTH
        sub.is_priority = False
        await db.commit()


async def _handle_payment_succeeded(invoice_data: dict, db: AsyncSession):
    # Reset monthly scan count on successful renewal
    stripe_sub_id = invoice_data.get("subscription")
    if not stripe_sub_id:
        return

    result = await db.execute(
        select(Subscription).where(Subscription.stripe_subscription_id == stripe_sub_id)
    )
    sub = result.scalar_one_or_none()
    if sub:
        sub.scans_used_this_month = 0
        await db.commit()
