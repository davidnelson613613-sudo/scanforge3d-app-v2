"""
AI service endpoints: object classification, material detection,
background removal, and volume/weight estimation.
"""

import base64
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from app.api.v1.endpoints.auth import get_current_user
from app.core.config import settings
from app.models.models import User

router = APIRouter()


# ─── Request/Response Schemas ─────────────────────────────────────────────────
class ClassificationRequest(BaseModel):
    job_id: str
    thumbnail_base64: str
    mesh_metadata: Optional[dict] = None


class ClassificationResponse(BaseModel):
    object_class: str
    subcategory: Optional[str] = None
    confidence: float
    material_type: str
    tags: list[str]
    estimated_volume_cm3: Optional[float] = None
    estimated_weight_grams: Optional[float] = None


class BackgroundRemovalRequest(BaseModel):
    image_base64: str
    return_format: str = "png"


class BackgroundRemovalResponse(BaseModel):
    result_base64: str
    processing_time_ms: int


# ─── Endpoints ────────────────────────────────────────────────────────────────
@router.post("/classify", response_model=ClassificationResponse)
async def classify_object(
    body: ClassificationRequest,
    current_user: User = Depends(get_current_user),
):
    """
    Classifies a scanned object using AI vision.
    Detects object category, material type, and generates marketplace tags.
    Uses GPT-4 Vision or a custom fine-tuned model.
    """
    try:
        # Decode thumbnail
        image_bytes = base64.b64decode(body.thumbnail_base64)

        # In production: call OpenAI Vision API or custom model
        # For now, returns a structured mock response
        result = await _run_classification(image_bytes, body.mesh_metadata)
        return result

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Classification failed: {str(e)}",
        )


@router.post("/remove-background", response_model=BackgroundRemovalResponse)
async def remove_background(
    body: BackgroundRemovalRequest,
    current_user: User = Depends(get_current_user),
):
    """
    Removes the background from an image using AI segmentation (rembg/U2Net).
    Returns a PNG with alpha channel transparency.
    """
    import time
    start = time.time()

    try:
        image_bytes = base64.b64decode(body.image_base64)

        # In production: use rembg library or call AI service
        # from rembg import remove
        # result_bytes = remove(image_bytes)
        result_bytes = image_bytes  # Placeholder

        elapsed_ms = int((time.time() - start) * 1000)
        return BackgroundRemovalResponse(
            result_base64=base64.b64encode(result_bytes).decode(),
            processing_time_ms=elapsed_ms,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Background removal failed: {str(e)}",
        )


@router.post("/separate-objects")
async def separate_objects(
    body: dict,
    current_user: User = Depends(get_current_user),
):
    """
    Separates multiple objects in a single scan into individual meshes.
    Uses instance segmentation on the point cloud.
    """
    job_id = body.get("job_id")
    if not job_id:
        raise HTTPException(status_code=400, detail="job_id is required.")

    # Enqueue multi-object separation task
    return {
        "job_id": job_id,
        "status": "queued",
        "message": "Multi-object separation queued. Results will be available via job status.",
    }


# ─── Internal Helpers ─────────────────────────────────────────────────────────
async def _run_classification(image_bytes: bytes, mesh_metadata: Optional[dict]) -> ClassificationResponse:
    """
    Runs AI classification on the provided image.
    In production, this calls the OpenAI Vision API or a custom model endpoint.
    """
    if settings.OPENAI_API_KEY:
        return await _classify_with_openai(image_bytes, mesh_metadata)

    # Fallback: rule-based classification
    return ClassificationResponse(
        object_class="object",
        subcategory="general",
        confidence=0.75,
        material_type="plastic",
        tags=["3d-scan", "object", "photogrammetry"],
        estimated_volume_cm3=mesh_metadata.get("volume_cm3") if mesh_metadata else None,
        estimated_weight_grams=None,
    )


async def _classify_with_openai(image_bytes: bytes, mesh_metadata: Optional[dict]) -> ClassificationResponse:
    """Classifies an object using OpenAI GPT-4 Vision."""
    import openai
    import json

    client = openai.AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
    image_b64 = base64.b64encode(image_bytes).decode()

    prompt = (
        "You are a 3D object classifier for a scanning app. "
        "Analyze this image and return a JSON object with: "
        "object_class (string), subcategory (string), confidence (0-1 float), "
        "material_type (one of: plastic, metal, wood, ceramic, fabric, glass, rubber, stone, paper, foam), "
        "tags (array of strings). "
        "Be concise and accurate."
    )

    response = await client.chat.completions.create(
        model="gpt-4-vision-preview",
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_b64}"}},
                ],
            }
        ],
        max_tokens=300,
    )

    content = response.choices[0].message.content
    data = json.loads(content)

    return ClassificationResponse(
        object_class=data.get("object_class", "object"),
        subcategory=data.get("subcategory"),
        confidence=float(data.get("confidence", 0.8)),
        material_type=data.get("material_type", "plastic"),
        tags=data.get("tags", []),
    )
