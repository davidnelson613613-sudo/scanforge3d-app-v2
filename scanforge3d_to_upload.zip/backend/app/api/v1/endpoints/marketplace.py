"""
Marketplace publishing endpoints: publish scan, list listings.
"""

import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.v1.endpoints.auth import get_current_user
from app.core.database import get_db
from app.models.models import User, ScanJob, MarketplaceListing

router = APIRouter()


class PublishRequest(BaseModel):
    job_id: str
    metadata: dict
    target: str = "sketchfab"  # sketchfab, cgtrader, turbosquid, fab


@router.post("/publish")
async def publish_to_marketplace(
    body: PublishRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Publishes a completed scan to an external marketplace."""
    result = await db.execute(
        select(ScanJob).where(ScanJob.id == body.job_id, ScanJob.user_id == current_user.id)
    )
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Scan job not found.")
    if job.status != "completed":
        raise HTTPException(status_code=400, detail="Only completed scans can be published.")

    listing_id = str(uuid.uuid4())
    listing = MarketplaceListing(
        id=listing_id,
        scan_job_id=job.id,
        user_id=current_user.id,
        platform=body.target,
        title=body.metadata.get("title", f"3D Scan - {job.object_class or 'Object'}"),
        description=body.metadata.get("description"),
        tags=body.metadata.get("tags", []),
        status="pending",
    )
    db.add(listing)
    await db.commit()

    # In production: call platform-specific API (Sketchfab API, etc.)
    return {
        "listing_id": listing_id,
        "marketplace_url": f"https://{body.target}.com/models/{listing_id}",
        "status": "pending",
    }


@router.get("/listings")
async def get_user_listings(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Returns all marketplace listings for the current user."""
    result = await db.execute(
        select(MarketplaceListing).where(MarketplaceListing.user_id == current_user.id)
    )
    listings = result.scalars().all()
    return {
        "listings": [
            {
                "listing_id": str(l.id),
                "platform": l.platform,
                "title": l.title,
                "status": l.status,
                "listing_url": l.listing_url,
                "created_at": l.created_at.isoformat(),
            }
            for l in listings
        ]
    }
