"""
API v1 router — aggregates all endpoint modules.
"""

from fastapi import APIRouter

from app.api.v1.endpoints import auth, scans, ai, subscriptions, marketplace, builds, users

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(scans.router, prefix="/scans", tags=["Scan Jobs"])
api_router.include_router(ai.router, prefix="/ai", tags=["AI Services"])
api_router.include_router(subscriptions.router, prefix="/subscriptions", tags=["Subscriptions"])
api_router.include_router(marketplace.router, prefix="/marketplace", tags=["Marketplace"])
api_router.include_router(builds.router, prefix="/builds", tags=["App Builds"])
