"""
Virus scanning service using ClamAV.
Validates uploaded files before processing.
"""

import logging
import io
from app.core.config import settings

logger = logging.getLogger("scanforge.virus_scanner")


async def scan_file_for_viruses(file_bytes: bytes, filename: str) -> tuple[bool, str]:
    """
    Scans file bytes for viruses using ClamAV.
    Returns (is_clean, message).
    """
    if not settings.ENABLE_VIRUS_SCAN:
        return True, "Virus scanning disabled."

    try:
        import clamd
        cd = clamd.ClamdNetworkSocket(
            host=settings.CLAMAV_HOST,
            port=settings.CLAMAV_PORT,
        )
        result = cd.instream(io.BytesIO(file_bytes))
        status = result.get("stream", ("OK", ""))[0]

        if status == "OK":
            logger.info(f"Virus scan passed: {filename}")
            return True, "File is clean."
        else:
            logger.warning(f"Virus detected in {filename}: {status}")
            return False, f"Malicious content detected: {status}"

    except Exception as e:
        logger.error(f"Virus scan error for {filename}: {e}")
        # Fail open in case ClamAV is unavailable (log and continue)
        return True, f"Scan service unavailable: {e}"
