"""
SQLAlchemy ORM models for the ScanForge3D database.
All models use UUID primary keys and include audit timestamps.
"""

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float, ForeignKey,
    Integer, String, Text, JSON, BigInteger, Index
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


def utcnow():
    return datetime.now(timezone.utc)


# ─── Users ────────────────────────────────────────────────────────────────────
class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    display_name = Column(String(100), nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    avatar_url = Column(String(500), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)
    last_login_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    subscription = relationship("Subscription", back_populates="user", uselist=False)
    scan_jobs = relationship("ScanJob", back_populates="user", cascade="all, delete-orphan")
    api_keys = relationship("APIKey", back_populates="user", cascade="all, delete-orphan")
    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<User id={self.id} email={self.email}>"


# ─── Subscriptions ────────────────────────────────────────────────────────────
class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)
    tier = Column(
        Enum("free", "pro", "enterprise", name="subscription_tier_enum"),
        default="free",
        nullable=False,
    )
    stripe_customer_id = Column(String(255), nullable=True, index=True)
    stripe_subscription_id = Column(String(255), nullable=True, index=True)
    is_active = Column(Boolean, default=True, nullable=False)
    is_priority = Column(Boolean, default=False, nullable=False)  # Enterprise priority processing
    scans_used_this_month = Column(Integer, default=0, nullable=False)
    scans_limit = Column(Integer, default=3, nullable=False)  # -1 = unlimited
    current_period_start = Column(DateTime(timezone=True), nullable=True)
    current_period_end = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)

    # Relationships
    user = relationship("User", back_populates="subscription")

    def __repr__(self):
        return f"<Subscription user_id={self.user_id} tier={self.tier}>"


# ─── Scan Jobs ────────────────────────────────────────────────────────────────
class ScanJob(Base):
    __tablename__ = "scan_jobs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    client_session_id = Column(String(255), nullable=True)
    status = Column(
        Enum("pending", "uploading", "queued", "processing", "completed", "failed",
             name="scan_job_status_enum"),
        default="pending",
        nullable=False,
        index=True,
    )

    # Frame data
    total_frames = Column(Integer, default=0, nullable=False)
    frames_s3_prefix = Column(String(500), nullable=True)  # S3 key prefix for frames

    # Reconstruction results
    mesh_s3_key = Column(String(500), nullable=True)
    mesh_url = Column(String(1000), nullable=True)
    thumbnail_url = Column(String(1000), nullable=True)
    confidence_score = Column(Float, nullable=True)
    processing_progress = Column(Float, default=0.0, nullable=False)

    # AI Classification
    object_class = Column(String(100), nullable=True)
    object_subcategory = Column(String(100), nullable=True)
    material_type = Column(String(100), nullable=True)
    estimated_volume_cm3 = Column(Float, nullable=True)
    estimated_weight_grams = Column(Float, nullable=True)
    classification_confidence = Column(Float, nullable=True)
    ai_tags = Column(JSON, nullable=True)

    # Error handling
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0, nullable=False)

    # Metadata
    scan_metadata = Column(JSON, nullable=True)  # Device info, AR session data
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)

    # Relationships
    user = relationship("User", back_populates="scan_jobs")
    exports = relationship("Export", back_populates="scan_job", cascade="all, delete-orphan")
    frame_batches = relationship("FrameBatch", back_populates="scan_job", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_scan_jobs_user_status", "user_id", "status"),
        Index("ix_scan_jobs_created_at", "created_at"),
    )

    def __repr__(self):
        return f"<ScanJob id={self.id} status={self.status}>"


# ─── Frame Batches ────────────────────────────────────────────────────────────
class FrameBatch(Base):
    __tablename__ = "frame_batches"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scan_job_id = Column(UUID(as_uuid=True), ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    batch_index = Column(Integer, nullable=False)
    s3_key = Column(String(500), nullable=False)
    frame_count = Column(Integer, nullable=False)
    file_size_bytes = Column(BigInteger, nullable=True)
    upload_status = Column(
        Enum("pending", "uploading", "completed", "failed", name="batch_status_enum"),
        default="pending",
        nullable=False,
    )
    uploaded_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)

    # Relationships
    scan_job = relationship("ScanJob", back_populates="frame_batches")

    def __repr__(self):
        return f"<FrameBatch job={self.scan_job_id} batch={self.batch_index}>"


# ─── Exports ─────────────────────────────────────────────────────────────────
class Export(Base):
    __tablename__ = "exports"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scan_job_id = Column(UUID(as_uuid=True), ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    format = Column(
        Enum("obj", "fbx", "glb", "usdz", "stl", name="export_format_enum"),
        nullable=False,
    )
    quality = Column(
        Enum("low", "medium", "high", "ultra", name="export_quality_enum"),
        default="medium",
        nullable=False,
    )
    s3_key = Column(String(500), nullable=True)
    download_url = Column(String(1000), nullable=True)
    file_size_bytes = Column(BigInteger, nullable=True)
    is_watermarked = Column(Boolean, default=True, nullable=False)
    status = Column(
        Enum("pending", "processing", "completed", "failed", name="export_status_enum"),
        default="pending",
        nullable=False,
    )
    expires_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)

    # Relationships
    scan_job = relationship("ScanJob", back_populates="exports")

    def __repr__(self):
        return f"<Export id={self.id} format={self.format}>"


# ─── API Keys ─────────────────────────────────────────────────────────────────
class APIKey(Base):
    __tablename__ = "api_keys"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    key_hash = Column(String(64), unique=True, nullable=False, index=True)
    key_prefix = Column(String(10), nullable=False)  # First 8 chars for display
    is_active = Column(Boolean, default=True, nullable=False)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)

    # Relationships
    user = relationship("User", back_populates="api_keys")

    def __repr__(self):
        return f"<APIKey id={self.id} prefix={self.key_prefix}>"


# ─── Refresh Tokens ───────────────────────────────────────────────────────────
class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = Column(String(64), unique=True, nullable=False, index=True)
    is_revoked = Column(Boolean, default=False, nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)
    revoked_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    user = relationship("User", back_populates="refresh_tokens")

    def __repr__(self):
        return f"<RefreshToken user_id={self.user_id} revoked={self.is_revoked}>"


# ─── Marketplace Listings ─────────────────────────────────────────────────────
class MarketplaceListing(Base):
    __tablename__ = "marketplace_listings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scan_job_id = Column(UUID(as_uuid=True), ForeignKey("scan_jobs.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    platform = Column(String(50), nullable=False)  # sketchfab, cgtrader, etc.
    external_listing_id = Column(String(255), nullable=True)
    listing_url = Column(String(1000), nullable=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    tags = Column(JSON, nullable=True)
    status = Column(String(50), default="pending", nullable=False)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)

    def __repr__(self):
        return f"<MarketplaceListing id={self.id} platform={self.platform}>"
