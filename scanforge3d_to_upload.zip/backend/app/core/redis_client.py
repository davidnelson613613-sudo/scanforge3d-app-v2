"""
Redis client for caching, job queuing, token blacklisting, and rate limiting.
"""

import json
import logging
from typing import Any, Optional

import redis.asyncio as aioredis

from app.core.config import settings

logger = logging.getLogger("scanforge.redis")

# ─── Global Redis Clients ─────────────────────────────────────────────────────
_redis_cache: Optional[aioredis.Redis] = None
_redis_queue: Optional[aioredis.Redis] = None


async def init_redis():
    """Initializes Redis connection pools on application startup."""
    global _redis_cache, _redis_queue

    _redis_cache = aioredis.from_url(
        settings.REDIS_URL,
        encoding="utf-8",
        decode_responses=True,
        max_connections=50,
    )
    _redis_queue = aioredis.from_url(
        f"{settings.REDIS_URL.rsplit('/', 1)[0]}/{settings.REDIS_JOB_QUEUE_DB}",
        encoding="utf-8",
        decode_responses=True,
        max_connections=20,
    )

    await _redis_cache.ping()
    await _redis_queue.ping()
    logger.info("Redis connections established.")


async def close_redis():
    """Closes Redis connections on application shutdown."""
    if _redis_cache:
        await _redis_cache.close()
    if _redis_queue:
        await _redis_queue.close()
    logger.info("Redis connections closed.")


def get_cache() -> aioredis.Redis:
    """Returns the cache Redis client."""
    if _redis_cache is None:
        raise RuntimeError("Redis cache not initialized. Call init_redis() first.")
    return _redis_cache


def get_queue() -> aioredis.Redis:
    """Returns the job queue Redis client."""
    if _redis_queue is None:
        raise RuntimeError("Redis queue not initialized. Call init_redis() first.")
    return _redis_queue


# ─── Cache Helpers ────────────────────────────────────────────────────────────
async def cache_set(key: str, value: Any, ttl: int = None) -> None:
    """Stores a value in the cache with optional TTL."""
    redis = get_cache()
    serialized = json.dumps(value) if not isinstance(value, str) else value
    if ttl:
        await redis.setex(key, ttl, serialized)
    else:
        await redis.set(key, serialized)


async def cache_get(key: str) -> Optional[Any]:
    """Retrieves a value from the cache."""
    redis = get_cache()
    value = await redis.get(key)
    if value is None:
        return None
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return value


async def cache_delete(key: str) -> None:
    """Removes a key from the cache."""
    await get_cache().delete(key)


# ─── Token Blacklist ──────────────────────────────────────────────────────────
async def blacklist_token(jti: str, expiry_seconds: int) -> None:
    """Adds a JWT ID to the blacklist (used for logout/revocation)."""
    await get_cache().setex(f"blacklist:{jti}", expiry_seconds, "1")


async def is_token_blacklisted(jti: str) -> bool:
    """Returns True if the token has been revoked."""
    return await get_cache().exists(f"blacklist:{jti}") > 0


# ─── Job Queue ────────────────────────────────────────────────────────────────
async def enqueue_reconstruction_job(job_data: dict) -> None:
    """Pushes a reconstruction job to the Redis queue."""
    redis = get_queue()
    await redis.lpush(settings.RECONSTRUCTION_QUEUE_NAME, json.dumps(job_data))
    logger.info(f"Enqueued reconstruction job: {job_data.get('job_id')}")


async def get_job_queue_length() -> int:
    """Returns the current length of the reconstruction job queue."""
    return await get_queue().llen(settings.RECONSTRUCTION_QUEUE_NAME)


# ─── Scan Rate Limiting ───────────────────────────────────────────────────────
async def increment_user_scan_count(user_id: str, month_key: str) -> int:
    """Increments and returns the user's scan count for the current month."""
    redis = get_cache()
    key = f"scan_count:{user_id}:{month_key}"
    count = await redis.incr(key)
    if count == 1:
        # Set expiry to 35 days to cover the full month
        await redis.expire(key, 35 * 24 * 3600)
    return count


async def get_user_scan_count(user_id: str, month_key: str) -> int:
    """Returns the user's scan count for the given month."""
    redis = get_cache()
    key = f"scan_count:{user_id}:{month_key}"
    count = await redis.get(key)
    return int(count) if count else 0
