"""
Security utilities: JWT token creation/validation, password hashing,
signed URL generation, and file type validation.
"""

import hashlib
import hmac
import secrets
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

import boto3
from botocore.exceptions import ClientError
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

# ─── Password Hashing ─────────────────────────────────────────────────────────
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """Hashes a plain-text password using bcrypt."""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain-text password against a bcrypt hash."""
    return pwd_context.verify(plain_password, hashed_password)


# ─── JWT Tokens ───────────────────────────────────────────────────────────────
def create_access_token(
    subject: str,
    user_id: str,
    subscription_tier: str = "free",
    expires_delta: Optional[timedelta] = None,
) -> str:
    """Creates a signed JWT access token."""
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    payload = {
        "sub": subject,
        "user_id": user_id,
        "tier": subscription_tier,
        "type": "access",
        "iat": datetime.now(timezone.utc),
        "exp": expire,
        "jti": secrets.token_hex(16),  # JWT ID for revocation
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_refresh_token(subject: str, user_id: str) -> str:
    """Creates a long-lived refresh token."""
    expire = datetime.now(timezone.utc) + timedelta(days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS)
    payload = {
        "sub": subject,
        "user_id": user_id,
        "type": "refresh",
        "iat": datetime.now(timezone.utc),
        "exp": expire,
        "jti": secrets.token_hex(16),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_token(token: str) -> dict:
    """Decodes and validates a JWT token. Raises JWTError on failure."""
    return jwt.decode(
        token,
        settings.JWT_SECRET_KEY,
        algorithms=[settings.JWT_ALGORITHM],
    )


# ─── S3 Signed URLs ───────────────────────────────────────────────────────────
def generate_signed_upload_url(
    bucket: str,
    key: str,
    content_type: str = "multipart/form-data",
    expiry: int = None,
) -> str:
    """
    Generates a pre-signed S3 URL for direct client-to-S3 uploads.
    Bypasses the API server for large file uploads.
    """
    s3_client = boto3.client(
        "s3",
        region_name=settings.AWS_REGION,
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    )

    expiry = expiry or settings.S3_UPLOAD_URL_EXPIRY

    try:
        url = s3_client.generate_presigned_url(
            "put_object",
            Params={
                "Bucket": bucket,
                "Key": key,
                "ContentType": content_type,
                "ServerSideEncryption": "AES256",  # Encrypted storage
            },
            ExpiresIn=expiry,
        )
        return url
    except ClientError as e:
        raise RuntimeError(f"Failed to generate signed URL: {e}")


def generate_signed_download_url(bucket: str, key: str, expiry: int = None) -> str:
    """Generates a pre-signed S3 URL for secure file downloads."""
    s3_client = boto3.client(
        "s3",
        region_name=settings.AWS_REGION,
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    )

    expiry = expiry or settings.S3_SIGNED_URL_EXPIRY

    try:
        return s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": key},
            ExpiresIn=expiry,
        )
    except ClientError as e:
        raise RuntimeError(f"Failed to generate download URL: {e}")


# ─── File Validation ─────────────────────────────────────────────────────────
ALLOWED_MAGIC_BYTES = {
    b"\xff\xd8\xff": "image/jpeg",
    b"\x89PNG": "image/png",
    b"RIFF": "image/webp",
    b"glTF": "model/gltf-binary",
}


def validate_file_type(file_bytes: bytes, allowed_types: list[str]) -> tuple[bool, str]:
    """
    Validates a file's actual type by checking magic bytes (not just extension).
    Returns (is_valid, detected_type).
    """
    for magic, mime_type in ALLOWED_MAGIC_BYTES.items():
        if file_bytes[:len(magic)] == magic:
            return mime_type in allowed_types, mime_type
    return False, "unknown"


def validate_file_size(file_bytes: bytes, max_size_mb: int) -> bool:
    """Returns True if file size is within the allowed limit."""
    return len(file_bytes) <= max_size_mb * 1024 * 1024


# ─── API Key Generation ───────────────────────────────────────────────────────
def generate_api_key() -> str:
    """Generates a cryptographically secure API key."""
    return f"sf_{secrets.token_urlsafe(32)}"


def hash_api_key(api_key: str) -> str:
    """Hashes an API key for secure storage."""
    return hashlib.sha256(api_key.encode()).hexdigest()
