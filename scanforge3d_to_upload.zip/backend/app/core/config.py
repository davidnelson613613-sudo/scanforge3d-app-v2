"""
Application configuration using Pydantic Settings.
All values can be overridden via environment variables or a .env file.
"""

from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    # ─── Application ──────────────────────────────────────────────────────────
    APP_NAME: str = "ScanForge3D"
    ENVIRONMENT: str = "production"  # development | staging | production
    DEBUG: bool = False
    SECRET_KEY: str = "CHANGE_THIS_IN_PRODUCTION_USE_256_BIT_RANDOM_KEY"
    API_VERSION: str = "v1"

    # ─── Database ─────────────────────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://scanforge:password@localhost:5432/scanforge3d"
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 40
    DATABASE_POOL_TIMEOUT: int = 30

    # ─── Redis ────────────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_JOB_QUEUE_DB: int = 1
    REDIS_CACHE_TTL: int = 3600  # 1 hour

    # ─── JWT Authentication ───────────────────────────────────────────────────
    JWT_SECRET_KEY: str = "CHANGE_THIS_JWT_SECRET_IN_PRODUCTION"
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # ─── AWS S3 Storage ───────────────────────────────────────────────────────
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "us-east-1"
    S3_BUCKET_FRAMES: str = "scanforge-frames"
    S3_BUCKET_MESHES: str = "scanforge-meshes"
    S3_BUCKET_EXPORTS: str = "scanforge-exports"
    S3_SIGNED_URL_EXPIRY: int = 3600  # seconds
    S3_UPLOAD_URL_EXPIRY: int = 900   # 15 minutes for upload URLs

    # ─── CORS ─────────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = [
        "https://scanforge3d.com",
        "https://app.scanforge3d.com",
        "https://admin.scanforge3d.com",
        "http://localhost:3000",
        "http://localhost:8080",
    ]

    # ─── Rate Limiting ────────────────────────────────────────────────────────
    RATE_LIMIT_FREE: str = "30/minute"
    RATE_LIMIT_PRO: str = "120/minute"
    RATE_LIMIT_ENTERPRISE: str = "500/minute"
    RATE_LIMIT_AUTH: str = "10/minute"

    # ─── Subscription Limits ──────────────────────────────────────────────────
    FREE_SCANS_PER_MONTH: int = 3
    PRO_SCANS_PER_MONTH: int = -1       # -1 = unlimited
    ENTERPRISE_SCANS_PER_MONTH: int = -1

    # ─── Reconstruction Worker ────────────────────────────────────────────────
    RECONSTRUCTION_WORKER_URL: str = "http://reconstruction-server:8001"
    RECONSTRUCTION_TIMEOUT: int = 300   # 5 minutes
    MAX_RECONSTRUCTION_RETRIES: int = 3
    RECONSTRUCTION_QUEUE_NAME: str = "reconstruction_jobs"

    # ─── AI Services ─────────────────────────────────────────────────────────
    AI_SERVICE_URL: str = "http://ai-service:8002"
    OPENAI_API_KEY: Optional[str] = None
    AI_CLASSIFICATION_MODEL: str = "gpt-4-vision-preview"

    # ─── File Validation ─────────────────────────────────────────────────────
    ALLOWED_IMAGE_TYPES: List[str] = ["image/jpeg", "image/png", "image/webp"]
    ALLOWED_MESH_TYPES: List[str] = [
        "model/gltf-binary",
        "application/octet-stream",
        "model/obj",
    ]
    MAX_FRAME_SIZE_MB: int = 10
    MAX_BATCH_SIZE_MB: int = 200
    MAX_FRAMES_PER_BATCH: int = 30

    # ─── Virus Scanning ───────────────────────────────────────────────────────
    ENABLE_VIRUS_SCAN: bool = True
    CLAMAV_HOST: str = "clamav"
    CLAMAV_PORT: int = 3310

    # ─── Celery Task Queue ────────────────────────────────────────────────────
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"
    CELERY_TASK_SERIALIZER: str = "json"
    CELERY_RESULT_SERIALIZER: str = "json"
    CELERY_ACCEPT_CONTENT: List[str] = ["json"]
    CELERY_TIMEZONE: str = "UTC"

    # ─── Email ────────────────────────────────────────────────────────────────
    SMTP_HOST: str = "smtp.sendgrid.net"
    SMTP_PORT: int = 587
    SMTP_USER: str = "apikey"
    SMTP_PASSWORD: str = ""
    FROM_EMAIL: str = "noreply@scanforge3d.com"

    # ─── Monitoring ───────────────────────────────────────────────────────────
    SENTRY_DSN: Optional[str] = None
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090

    # ─── Stripe Payments ─────────────────────────────────────────────────────
    STRIPE_SECRET_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    STRIPE_PRO_PRICE_ID: str = ""
    STRIPE_ENTERPRISE_PRICE_ID: str = ""


settings = Settings()
