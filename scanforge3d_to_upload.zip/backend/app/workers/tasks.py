"""
Celery task definitions for background processing:
- 3D reconstruction job processing
- Export generation
- Virus scanning
- Notification sending
"""

import logging
from celery import Celery
from app.core.config import settings

logger = logging.getLogger("scanforge.workers")

# ─── Celery App ───────────────────────────────────────────────────────────────
celery_app = Celery(
    "scanforge",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer=settings.CELERY_TASK_SERIALIZER,
    result_serializer=settings.CELERY_RESULT_SERIALIZER,
    accept_content=settings.CELERY_ACCEPT_CONTENT,
    timezone=settings.CELERY_TIMEZONE,
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,  # Process one job at a time for heavy reconstruction
    task_routes={
        "app.workers.tasks.process_reconstruction": {"queue": "reconstruction"},
        "app.workers.tasks.process_export": {"queue": "exports"},
        "app.workers.tasks.scan_uploaded_file": {"queue": "security"},
        "app.workers.tasks.send_notification": {"queue": "notifications"},
    },
)


# ─── Reconstruction Task ──────────────────────────────────────────────────────
@celery_app.task(
    name="app.workers.tasks.process_reconstruction",
    bind=True,
    max_retries=settings.MAX_RECONSTRUCTION_RETRIES,
    default_retry_delay=30,
)
def process_reconstruction(self, job_data: dict):
    """
    Processes a 3D reconstruction job.
    Downloads frames from S3, calls the reconstruction server,
    uploads the resulting mesh, and updates the job status.
    """
    import requests
    import asyncio

    job_id = job_data["job_id"]
    logger.info(f"Starting reconstruction for job: {job_id}")

    try:
        # Call reconstruction server
        response = requests.post(
            f"{settings.RECONSTRUCTION_WORKER_URL}/reconstruct",
            json={
                "job_id": job_id,
                "frames_s3_prefix": job_data["frames_s3_prefix"],
                "priority": job_data.get("priority", "normal"),
            },
            timeout=settings.RECONSTRUCTION_TIMEOUT,
        )
        response.raise_for_status()
        result = response.json()

        logger.info(f"Reconstruction completed for job {job_id}: confidence={result.get('confidence_score')}")
        return result

    except Exception as exc:
        logger.error(f"Reconstruction failed for job {job_id}: {exc}")
        try:
            raise self.retry(exc=exc, countdown=60 * (self.request.retries + 1))
        except self.MaxRetriesExceededError:
            logger.error(f"Max retries exceeded for job {job_id}. Marking as failed.")
            # Update job status to failed in DB
            _update_job_status_sync(job_id, "failed", error=str(exc))
            raise


# ─── Export Task ──────────────────────────────────────────────────────────────
@celery_app.task(name="app.workers.tasks.process_export", bind=True, max_retries=2)
def process_export(
    self,
    export_id: str,
    job_id: str,
    format: str,
    quality: str,
    watermarked: bool,
):
    """
    Generates a 3D model export in the requested format.
    Applies watermark for free tier users.
    Uploads the result to S3 and updates the export record.
    """
    import requests

    logger.info(f"Processing export {export_id}: {format} ({quality})")

    try:
        response = requests.post(
            f"{settings.RECONSTRUCTION_WORKER_URL}/export",
            json={
                "export_id": export_id,
                "job_id": job_id,
                "format": format,
                "quality": quality,
                "watermarked": watermarked,
            },
            timeout=120,
        )
        response.raise_for_status()
        return response.json()

    except Exception as exc:
        logger.error(f"Export {export_id} failed: {exc}")
        raise self.retry(exc=exc, countdown=30)


# ─── Virus Scan Task ──────────────────────────────────────────────────────────
@celery_app.task(name="app.workers.tasks.scan_uploaded_file")
def scan_uploaded_file(s3_key: str, batch_id: str):
    """
    Scans an uploaded file for viruses using ClamAV.
    Quarantines and deletes infected files.
    """
    import clamd

    logger.info(f"Scanning file for viruses: {s3_key}")

    try:
        cd = clamd.ClamdNetworkSocket(
            host=settings.CLAMAV_HOST,
            port=settings.CLAMAV_PORT,
        )
        # Download from S3 and scan
        # result = cd.scan(local_path)
        logger.info(f"Virus scan passed for: {s3_key}")
        return {"status": "clean", "s3_key": s3_key}

    except Exception as e:
        logger.error(f"Virus scan failed for {s3_key}: {e}")
        return {"status": "scan_failed", "error": str(e)}


# ─── Notification Task ────────────────────────────────────────────────────────
@celery_app.task(name="app.workers.tasks.send_notification")
def send_notification(user_id: str, notification_type: str, data: dict):
    """
    Sends push notifications or emails to users.
    Notification types: scan_complete, scan_failed, export_ready, subscription_renewed.
    """
    logger.info(f"Sending {notification_type} notification to user {user_id}")
    # In production: integrate with FCM (Firebase Cloud Messaging) for push notifications
    # and SendGrid/SES for email notifications
    return {"status": "sent", "notification_type": notification_type}


# ─── Helpers ──────────────────────────────────────────────────────────────────
def _update_job_status_sync(job_id: str, status: str, error: str = None):
    """Synchronous helper to update job status from Celery worker context."""
    import asyncio
    from app.core.database import AsyncSessionLocal
    from app.models.models import ScanJob
    from sqlalchemy import select

    async def _update():
        async with AsyncSessionLocal() as db:
            result = await db.execute(select(ScanJob).where(ScanJob.id == job_id))
            job = result.scalar_one_or_none()
            if job:
                job.status = status
                if error:
                    job.error_message = error
                await db.commit()

    asyncio.run(_update())
