"""Initial database schema

Revision ID: 0001_initial_schema
Revises: 
Create Date: 2026-03-03 00:00:00.000000

Creates all core tables:
- users
- subscriptions
- scan_jobs
- frame_batches
- exports
- api_keys
- refresh_tokens
- marketplace_listings
- audit_log
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '0001_initial_schema'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Enable UUID extension
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')

    # Create enums
    op.execute("CREATE TYPE subscription_tier_enum AS ENUM ('free', 'pro', 'enterprise')")
    op.execute("""
        CREATE TYPE scan_job_status_enum AS ENUM (
            'pending', 'uploading', 'queued', 'processing', 'completed', 'failed'
        )
    """)
    op.execute("CREATE TYPE batch_status_enum AS ENUM ('pending', 'uploading', 'completed', 'failed')")
    op.execute("CREATE TYPE export_format_enum AS ENUM ('obj', 'fbx', 'glb', 'usdz', 'stl')")
    op.execute("CREATE TYPE export_quality_enum AS ENUM ('low', 'medium', 'high', 'ultra')")
    op.execute("CREATE TYPE export_status_enum AS ENUM ('pending', 'processing', 'completed', 'failed')")

    # Users table
    op.create_table('users',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('display_name', sa.String(100), nullable=False),
        sa.Column('password_hash', sa.String(255), nullable=False),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('is_verified', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('is_admin', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('avatar_url', sa.String(500), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('last_login_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('email'),
    )
    op.create_index('ix_users_email', 'users', ['email'])
    op.create_index('ix_users_created_at', 'users', [sa.text('created_at DESC')])

    # Subscriptions table
    op.create_table('subscriptions',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('tier', sa.Enum('free', 'pro', 'enterprise', name='subscription_tier_enum'), server_default='free', nullable=False),
        sa.Column('stripe_customer_id', sa.String(255), nullable=True),
        sa.Column('stripe_subscription_id', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('is_priority', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('scans_used_this_month', sa.Integer(), server_default='0', nullable=False),
        sa.Column('scans_limit', sa.Integer(), server_default='3', nullable=False),
        sa.Column('current_period_start', sa.DateTime(timezone=True), nullable=True),
        sa.Column('current_period_end', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id'),
    )

    # Scan jobs table
    op.create_table('scan_jobs',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('client_session_id', sa.String(255), nullable=True),
        sa.Column('status', sa.Enum('pending', 'uploading', 'queued', 'processing', 'completed', 'failed', name='scan_job_status_enum'), server_default='pending', nullable=False),
        sa.Column('total_frames', sa.Integer(), server_default='0', nullable=False),
        sa.Column('frames_s3_prefix', sa.String(500), nullable=True),
        sa.Column('mesh_s3_key', sa.String(500), nullable=True),
        sa.Column('mesh_url', sa.String(1000), nullable=True),
        sa.Column('thumbnail_url', sa.String(1000), nullable=True),
        sa.Column('confidence_score', sa.Float(), nullable=True),
        sa.Column('processing_progress', sa.Float(), server_default='0.0', nullable=False),
        sa.Column('object_class', sa.String(100), nullable=True),
        sa.Column('object_subcategory', sa.String(100), nullable=True),
        sa.Column('material_type', sa.String(100), nullable=True),
        sa.Column('estimated_volume_cm3', sa.Float(), nullable=True),
        sa.Column('estimated_weight_grams', sa.Float(), nullable=True),
        sa.Column('classification_confidence', sa.Float(), nullable=True),
        sa.Column('ai_tags', postgresql.JSONB(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('retry_count', sa.Integer(), server_default='0', nullable=False),
        sa.Column('scan_metadata', postgresql.JSONB(), nullable=True),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_scan_jobs_user_id', 'scan_jobs', ['user_id'])
    op.create_index('ix_scan_jobs_status', 'scan_jobs', ['status'])
    op.create_index('ix_scan_jobs_user_status', 'scan_jobs', ['user_id', 'status'])

    # Frame batches
    op.create_table('frame_batches',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('scan_job_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('batch_index', sa.Integer(), nullable=False),
        sa.Column('s3_key', sa.String(500), nullable=False),
        sa.Column('frame_count', sa.Integer(), nullable=False),
        sa.Column('file_size_bytes', sa.BigInteger(), nullable=True),
        sa.Column('upload_status', sa.Enum('pending', 'uploading', 'completed', 'failed', name='batch_status_enum'), server_default='pending', nullable=False),
        sa.Column('uploaded_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['scan_job_id'], ['scan_jobs.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('scan_job_id', 'batch_index'),
    )

    # Exports
    op.create_table('exports',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('scan_job_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('format', sa.Enum('obj', 'fbx', 'glb', 'usdz', 'stl', name='export_format_enum'), nullable=False),
        sa.Column('quality', sa.Enum('low', 'medium', 'high', 'ultra', name='export_quality_enum'), server_default='medium', nullable=False),
        sa.Column('s3_key', sa.String(500), nullable=True),
        sa.Column('download_url', sa.String(1000), nullable=True),
        sa.Column('file_size_bytes', sa.BigInteger(), nullable=True),
        sa.Column('is_watermarked', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('status', sa.Enum('pending', 'processing', 'completed', 'failed', name='export_status_enum'), server_default='pending', nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['scan_job_id'], ['scan_jobs.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )

    # API Keys
    op.create_table('api_keys',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('key_hash', sa.String(64), nullable=False),
        sa.Column('key_prefix', sa.String(10), nullable=False),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('last_used_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('key_hash'),
    )

    # Refresh tokens
    op.create_table('refresh_tokens',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('token_hash', sa.String(64), nullable=False),
        sa.Column('is_revoked', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('revoked_at', sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('token_hash'),
    )

    # Marketplace listings
    op.create_table('marketplace_listings',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        sa.Column('scan_job_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('platform', sa.String(50), nullable=False),
        sa.Column('external_listing_id', sa.String(255), nullable=True),
        sa.Column('listing_url', sa.String(1000), nullable=True),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('tags', postgresql.JSONB(), nullable=True),
        sa.Column('status', sa.String(50), server_default='pending', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['scan_job_id'], ['scan_jobs.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id'),
    )

    # Audit log
    op.create_table('audit_log',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('action', sa.String(100), nullable=False),
        sa.Column('resource', sa.String(100), nullable=False),
        sa.Column('resource_id', sa.String(255), nullable=True),
        sa.Column('ip_address', postgresql.INET(), nullable=True),
        sa.Column('user_agent', sa.Text(), nullable=True),
        sa.Column('details', postgresql.JSONB(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_audit_log_user_id', 'audit_log', ['user_id'])
    op.create_index('ix_audit_log_created_at', 'audit_log', [sa.text('created_at DESC')])


def downgrade() -> None:
    op.drop_table('audit_log')
    op.drop_table('marketplace_listings')
    op.drop_table('refresh_tokens')
    op.drop_table('api_keys')
    op.drop_table('exports')
    op.drop_table('frame_batches')
    op.drop_table('scan_jobs')
    op.drop_table('subscriptions')
    op.drop_table('users')

    op.execute("DROP TYPE IF EXISTS export_status_enum")
    op.execute("DROP TYPE IF EXISTS export_quality_enum")
    op.execute("DROP TYPE IF EXISTS export_format_enum")
    op.execute("DROP TYPE IF EXISTS batch_status_enum")
    op.execute("DROP TYPE IF EXISTS scan_job_status_enum")
    op.execute("DROP TYPE IF EXISTS subscription_tier_enum")
