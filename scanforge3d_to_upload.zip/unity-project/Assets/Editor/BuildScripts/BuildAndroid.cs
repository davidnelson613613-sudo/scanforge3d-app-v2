using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace BuildScripts
{
    /// <summary>
    /// Automated Android build script for CI/CD pipelines.
    /// Called by GitHub Actions via Unity's -executeMethod flag.
    ///
    /// Usage:
    ///   Unity.exe -batchmode -quit -projectPath . \
    ///     -executeMethod BuildScripts.BuildAndroid.Build \
    ///     -buildTarget Android
    /// </summary>
    public static class BuildAndroid
    {
        private const string BuildOutputPath = "build/Android";
        private const string AppIdentifier = "com.scanforge.scanforge3d";

        /// <summary>
        /// Main build entry point called by CI/CD.
        /// Reads configuration from environment variables.
        /// </summary>
        public static void Build()
        {
            Debug.Log("[BuildAndroid] Starting automated Android build...");

            try
            {
                ConfigurePlayerSettings();
                ConfigureAndroidSettings();

                var buildOptions = GetBuildOptions();
                var report = BuildPipeline.BuildPlayer(buildOptions);

                HandleBuildReport(report);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[BuildAndroid] Build failed with exception: {ex}");
                EditorApplication.Exit(1);
            }
        }

        private static void ConfigurePlayerSettings()
        {
            // App identity
            PlayerSettings.applicationIdentifier = AppIdentifier;
            PlayerSettings.productName = "ScanForge3D";
            PlayerSettings.companyName = "ScanForge";

            // Version from environment or default
            string versionName = GetEnvOrDefault("VERSION_NAME", "1.0.0");
            string versionCodeStr = GetEnvOrDefault("VERSION_CODE", "1");

            PlayerSettings.bundleVersion = versionName;
            if (int.TryParse(versionCodeStr, out int versionCode))
                PlayerSettings.Android.bundleVersionCode = versionCode;

            // Graphics and performance
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android,
                new[] { UnityEngine.Rendering.GraphicsDeviceType.Vulkan,
                        UnityEngine.Rendering.GraphicsDeviceType.OpenGLES3 });

            // Android minimum SDK (ARCore requires API 24+)
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel34;

            // Permissions
            PlayerSettings.Android.forceInternetPermission = true;

            // IL2CPP for performance on Android
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.ARMv7;

            // Optimization
            PlayerSettings.stripEngineCode = true;
            PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.High);

            Debug.Log($"[BuildAndroid] Player settings configured: v{versionName} ({versionCode})");
        }

        private static void ConfigureAndroidSettings()
        {
            string buildType = GetEnvOrDefault("BUILD_TYPE", "release");
            bool isRelease = buildType.ToLower() == "release";

            if (isRelease)
            {
                // Configure keystore signing from environment variables
                string keystorePath = GetEnvOrDefault("ANDROID_KEYSTORE_PATH", "scanforge.keystore");
                string keystorePass = GetEnvOrDefault("ANDROID_KEYSTORE_PASS", "");
                string keyAlias = GetEnvOrDefault("ANDROID_KEY_ALIAS", "scanforge");
                string keyAliasPass = GetEnvOrDefault("ANDROID_KEY_ALIAS_PASS", "");

                if (!string.IsNullOrEmpty(keystorePass))
                {
                    PlayerSettings.Android.useCustomKeystore = true;
                    PlayerSettings.Android.keystoreName = keystorePath;
                    PlayerSettings.Android.keystorePass = keystorePass;
                    PlayerSettings.Android.keyaliasName = keyAlias;
                    PlayerSettings.Android.keyaliasPass = keyAliasPass;
                    Debug.Log("[BuildAndroid] Keystore signing configured.");
                }
                else
                {
                    Debug.LogWarning("[BuildAndroid] No keystore configured — using debug signing.");
                }
            }
        }

        private static BuildPlayerOptions GetBuildOptions()
        {
            string buildType = GetEnvOrDefault("BUILD_TYPE", "release");
            bool isRelease = buildType.ToLower() == "release";
            bool exportAsAAB = GetEnvOrDefault("EXPORT_AAB", "true").ToLower() == "true";

            // Collect all scenes from build settings
            var scenes = EditorBuildSettings.scenes;
            if (scenes.Length == 0)
            {
                throw new Exception("No scenes configured in Build Settings!");
            }

            string[] scenePaths = Array.ConvertAll(scenes, s => s.path);

            // Determine output path and extension
            string extension = exportAsAAB && isRelease ? "aab" : "apk";
            string outputPath = Path.Combine(BuildOutputPath, $"ScanForge3D.{extension}");
            Directory.CreateDirectory(BuildOutputPath);

            var options = new BuildPlayerOptions
            {
                scenes = scenePaths,
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.None,
            };

            if (!isRelease)
            {
                options.options |= BuildOptions.Development;
                options.options |= BuildOptions.AllowDebugging;
            }

            if (exportAsAAB && isRelease)
            {
                EditorUserBuildSettings.buildAppBundle = true;
            }
            else
            {
                EditorUserBuildSettings.buildAppBundle = false;
            }

            Debug.Log($"[BuildAndroid] Build options: {buildType}, AAB={exportAsAAB}, Output={outputPath}");
            return options;
        }

        private static void HandleBuildReport(BuildReport report)
        {
            BuildSummary summary = report.summary;

            Debug.Log($"[BuildAndroid] Build result: {summary.result}");
            Debug.Log($"[BuildAndroid] Build time: {summary.totalTime.TotalSeconds:F1}s");
            Debug.Log($"[BuildAndroid] Output size: {summary.totalSize / 1024 / 1024:F1} MB");
            Debug.Log($"[BuildAndroid] Output path: {summary.outputPath}");

            if (summary.totalErrors > 0)
                Debug.LogError($"[BuildAndroid] Build had {summary.totalErrors} error(s).");

            if (summary.totalWarnings > 0)
                Debug.LogWarning($"[BuildAndroid] Build had {summary.totalWarnings} warning(s).");

            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log("[BuildAndroid] BUILD SUCCEEDED");
                EditorApplication.Exit(0);
            }
            else
            {
                Debug.LogError($"[BuildAndroid] BUILD FAILED: {summary.result}");
                EditorApplication.Exit(1);
            }
        }

        private static string GetEnvOrDefault(string key, string defaultValue)
        {
            string value = Environment.GetEnvironmentVariable(key);
            return string.IsNullOrEmpty(value) ? defaultValue : value;
        }
    }
}
