using UnityEngine;

namespace ScanForge.Utils
{
    /// <summary>
    /// AppConfig is a ScriptableObject singleton providing global configuration
    /// for API endpoints, feature flags, and environment settings.
    /// </summary>
    [CreateAssetMenu(fileName = "AppConfig", menuName = "ScanForge/AppConfig")]
    public class AppConfig : ScriptableObject
    {
        private static AppConfig _instance;
        public static AppConfig Instance
        {
            get
            {
                if (_instance == null)
                    _instance = Resources.Load<AppConfig>("AppConfig");
                return _instance;
            }
        }

        [Header("API Configuration")]
        [Tooltip("Base URL for the ScanForge backend API")]
        public string ApiBaseUrl = "https://8000-i7k3iqmzkjl30jyp0tlm9-849a7fb8.us2.manus.computer";

        [Tooltip("WebSocket URL for real-time job status updates")]
        public string WebSocketUrl = "wss://8000-i7k3iqmzkjl30jyp0tlm9-849a7fb8.us2.manus.computer/ws";

        [Tooltip("CDN base URL for mesh and texture assets")]
        public string CdnBaseUrl = "https://8000-i7k3iqmzkjl30jyp0tlm9-849a7fb8.us2.manus.computer/cdn";

        [Header("Feature Flags")]
        public bool EnableOnDeviceAI = false;
        public bool EnableMultiObjectSeparation = true;
        public bool EnableBackgroundRemoval = true;
        public bool EnableScanComparison = true;
        public bool EnableMarketplaceExport = true;

        [Header("Performance")]
        [Tooltip("Maximum texture resolution to load (pixels per side)")]
        public int MaxTextureResolution = 2048;

        [Tooltip("Enable lazy texture loading for large meshes")]
        public bool LazyLoadTextures = true;

        [Tooltip("Mesh streaming chunk size in KB")]
        public int MeshStreamingChunkKB = 512;

        [Header("Scan Limits by Tier")]
        public int FreeScansPerMonth = 3;
        public int ProScansPerMonth = -1; // -1 = unlimited
        public int EnterpriseScansPerMonth = -1;

        [Header("Build Info")]
        public string AppVersion = "1.0.0";
        public int BuildNumber = 1;
        public string Environment = "development"; // development | staging | production
    }
}
