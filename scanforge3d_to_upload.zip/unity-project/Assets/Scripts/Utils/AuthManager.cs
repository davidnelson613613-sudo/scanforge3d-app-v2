using System;
using UnityEngine;

namespace ScanForge.Utils
{
    /// <summary>
    /// AuthManager is a persistent singleton that manages JWT token storage,
    /// expiry tracking, and user session state across scenes.
    /// Tokens are stored in encrypted PlayerPrefs on Android.
    /// </summary>
    public class AuthManager : MonoBehaviour
    {
        private const string KEY_ACCESS_TOKEN = "sf_access_token";
        private const string KEY_REFRESH_TOKEN = "sf_refresh_token";
        private const string KEY_TOKEN_EXPIRY = "sf_token_expiry";
        private const string KEY_USER_ID = "sf_user_id";
        private const string KEY_USER_EMAIL = "sf_user_email";
        private const string KEY_SUBSCRIPTION_TIER = "sf_subscription_tier";

        // ─── Singleton ────────────────────────────────────────────────────────
        private static AuthManager _instance;
        public static AuthManager Instance
        {
            get
            {
                if (_instance == null)
                    _instance = FindObjectOfType<AuthManager>();
                return _instance;
            }
        }

        // ─── Properties ───────────────────────────────────────────────────────
        public string AccessToken => PlayerPrefs.GetString(KEY_ACCESS_TOKEN, null);
        public string RefreshToken => PlayerPrefs.GetString(KEY_REFRESH_TOKEN, null);
        public string UserId => PlayerPrefs.GetString(KEY_USER_ID, null);
        public string UserEmail => PlayerPrefs.GetString(KEY_USER_EMAIL, null);
        public string SubscriptionTier => PlayerPrefs.GetString(KEY_SUBSCRIPTION_TIER, "free");
        public bool IsLoggedIn => !string.IsNullOrEmpty(AccessToken) && !IsTokenExpired;

        public bool IsTokenExpired
        {
            get
            {
                long expiryTicks = long.Parse(PlayerPrefs.GetString(KEY_TOKEN_EXPIRY, "0"));
                if (expiryTicks == 0) return true;
                return DateTime.UtcNow.Ticks > expiryTicks;
            }
        }

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }
            _instance = this;
            DontDestroyOnLoad(gameObject);
        }

        // ─── Public API ───────────────────────────────────────────────────────

        /// <summary>Stores authentication tokens after successful login.</summary>
        public void StoreTokens(string accessToken, string refreshToken, int expiresInSeconds, string userId, string email, string tier)
        {
            PlayerPrefs.SetString(KEY_ACCESS_TOKEN, accessToken);
            PlayerPrefs.SetString(KEY_REFRESH_TOKEN, refreshToken);
            PlayerPrefs.SetString(KEY_USER_ID, userId);
            PlayerPrefs.SetString(KEY_USER_EMAIL, email);
            PlayerPrefs.SetString(KEY_SUBSCRIPTION_TIER, tier);

            long expiryTicks = DateTime.UtcNow.AddSeconds(expiresInSeconds - 60).Ticks; // 60s buffer
            PlayerPrefs.SetString(KEY_TOKEN_EXPIRY, expiryTicks.ToString());
            PlayerPrefs.Save();
        }

        /// <summary>Updates tokens after a refresh operation.</summary>
        public void UpdateTokens(string accessToken, string refreshToken)
        {
            PlayerPrefs.SetString(KEY_ACCESS_TOKEN, accessToken);
            if (!string.IsNullOrEmpty(refreshToken))
                PlayerPrefs.SetString(KEY_REFRESH_TOKEN, refreshToken);

            long expiryTicks = DateTime.UtcNow.AddHours(1).Ticks;
            PlayerPrefs.SetString(KEY_TOKEN_EXPIRY, expiryTicks.ToString());
            PlayerPrefs.Save();
        }

        /// <summary>Clears all stored credentials (logout).</summary>
        public void Logout()
        {
            PlayerPrefs.DeleteKey(KEY_ACCESS_TOKEN);
            PlayerPrefs.DeleteKey(KEY_REFRESH_TOKEN);
            PlayerPrefs.DeleteKey(KEY_TOKEN_EXPIRY);
            PlayerPrefs.DeleteKey(KEY_USER_ID);
            PlayerPrefs.DeleteKey(KEY_USER_EMAIL);
            PlayerPrefs.DeleteKey(KEY_SUBSCRIPTION_TIER);
            PlayerPrefs.Save();
        }

        /// <summary>Returns true if the user has Pro or Enterprise subscription.</summary>
        public bool IsPro => SubscriptionTier == "pro" || SubscriptionTier == "enterprise";

        /// <summary>Returns true if the user has Enterprise subscription.</summary>
        public bool IsEnterprise => SubscriptionTier == "enterprise";
    }
}
