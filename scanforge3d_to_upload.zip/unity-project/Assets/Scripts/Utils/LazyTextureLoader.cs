using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

namespace ScanForge.Utils
{
    /// <summary>
    /// LazyTextureLoader provides on-demand texture loading for 3D scan models.
    /// Textures are only loaded when the object is visible and within a configurable
    /// distance threshold, preventing memory exhaustion on mid-range Android devices.
    ///
    /// Features:
    /// - Visibility-based lazy loading (only load when in camera frustum)
    /// - Distance-based LOD (load low-res first, upgrade when close)
    /// - LRU cache with configurable memory budget
    /// - Automatic unloading of distant/invisible textures
    /// - Streaming download with progress callbacks
    /// </summary>
    public class LazyTextureLoader : MonoBehaviour
    {
        // ─── Configuration ────────────────────────────────────────────────────
        [Header("Loading Settings")]
        [Tooltip("Maximum distance at which full-resolution textures are loaded")]
        [SerializeField] private float fullResDistance = 5f;

        [Tooltip("Maximum distance at which low-resolution textures are loaded")]
        [SerializeField] private float lowResDistance = 20f;

        [Tooltip("Distance beyond which textures are unloaded to free memory")]
        [SerializeField] private float unloadDistance = 40f;

        [Header("Memory Budget")]
        [Tooltip("Maximum texture cache size in megabytes")]
        [SerializeField] private int maxCacheMB = 128;

        [Tooltip("Maximum texture resolution (pixels per side) — reduces for mid-range devices")]
        [SerializeField] private int maxTextureResolution = 1024;

        [Header("References")]
        [SerializeField] private Camera mainCamera;

        // ─── Internal State ───────────────────────────────────────────────────
        private readonly Dictionary<string, CachedTexture> textureCache = new();
        private readonly Queue<string> lruQueue = new();
        private long currentCacheBytes = 0;
        private long maxCacheBytes;

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            maxCacheBytes = (long)maxCacheMB * 1024 * 1024;

            if (mainCamera == null)
                mainCamera = Camera.main;

            // Reduce resolution on low-memory devices
            if (SystemInfo.systemMemorySize < 3000) // < 3GB RAM
            {
                maxTextureResolution = 512;
                maxCacheMB = 64;
                Debug.Log("[LazyTextureLoader] Low-memory device detected. Reducing texture resolution to 512px.");
            }
        }

        // ─── Public API ───────────────────────────────────────────────────────

        /// <summary>
        /// Lazily loads a texture from a URL and applies it to a renderer.
        /// Only fetches if the renderer is visible and within range.
        /// </summary>
        public IEnumerator LoadTextureForRenderer(
            Renderer targetRenderer,
            string textureUrl,
            string materialProperty = "_MainTex",
            Action<Texture2D> onLoaded = null,
            Action<float> onProgress = null)
        {
            if (targetRenderer == null || string.IsNullOrEmpty(textureUrl))
                yield break;

            // Check if already cached
            if (textureCache.TryGetValue(textureUrl, out var cached))
            {
                cached.LastAccessTime = Time.time;
                targetRenderer.material.SetTexture(materialProperty, cached.Texture);
                onLoaded?.Invoke(cached.Texture);
                yield break;
            }

            // Wait until renderer is visible and within load distance
            yield return WaitForVisibility(targetRenderer);

            // Download texture with progress
            yield return DownloadAndCacheTexture(
                textureUrl,
                targetRenderer,
                materialProperty,
                onLoaded,
                onProgress);
        }

        /// <summary>
        /// Loads a low-resolution placeholder texture first, then upgrades to full-res
        /// when the object is close enough. Ideal for large scan models.
        /// </summary>
        public IEnumerator LoadTextureWithLOD(
            Renderer targetRenderer,
            string lowResUrl,
            string fullResUrl,
            string materialProperty = "_MainTex")
        {
            if (targetRenderer == null) yield break;

            // Load low-res immediately
            yield return LoadTextureForRenderer(targetRenderer, lowResUrl, materialProperty);

            // Upgrade to full-res when close enough
            while (true)
            {
                float dist = Vector3.Distance(mainCamera.transform.position,
                                              targetRenderer.transform.position);

                if (dist <= fullResDistance)
                {
                    yield return LoadTextureForRenderer(targetRenderer, fullResUrl, materialProperty);
                    yield break;
                }

                // Check again in 1 second
                yield return new WaitForSeconds(1f);
            }
        }

        /// <summary>
        /// Preloads a set of textures into the cache without applying them.
        /// Useful for pre-warming the cache before displaying a model.
        /// </summary>
        public IEnumerator PreloadTextures(string[] urls, Action<float> onProgress = null)
        {
            for (int i = 0; i < urls.Length; i++)
            {
                if (!textureCache.ContainsKey(urls[i]))
                    yield return DownloadAndCacheTexture(urls[i], null, null, null, null);

                onProgress?.Invoke((float)(i + 1) / urls.Length);
            }
        }

        /// <summary>
        /// Releases a specific texture from the cache to free memory.
        /// </summary>
        public void UnloadTexture(string textureUrl)
        {
            if (textureCache.TryGetValue(textureUrl, out var cached))
            {
                currentCacheBytes -= cached.SizeBytes;
                Destroy(cached.Texture);
                textureCache.Remove(textureUrl);
                Debug.Log($"[LazyTextureLoader] Unloaded texture: {textureUrl}");
            }
        }

        /// <summary>
        /// Clears all cached textures and frees memory.
        /// Call this when navigating away from the scan viewer.
        /// </summary>
        public void ClearCache()
        {
            foreach (var entry in textureCache.Values)
                Destroy(entry.Texture);

            textureCache.Clear();
            lruQueue.Clear();
            currentCacheBytes = 0;
            Resources.UnloadUnusedAssets();
            GC.Collect();
            Debug.Log("[LazyTextureLoader] Texture cache cleared.");
        }

        // ─── Private Helpers ──────────────────────────────────────────────────

        private IEnumerator WaitForVisibility(Renderer renderer)
        {
            while (true)
            {
                if (renderer == null) yield break;

                float dist = Vector3.Distance(
                    mainCamera.transform.position,
                    renderer.transform.position);

                if (dist <= lowResDistance && renderer.isVisible)
                    yield break;

                yield return new WaitForSeconds(0.5f);
            }
        }

        private IEnumerator DownloadAndCacheTexture(
            string url,
            Renderer targetRenderer,
            string materialProperty,
            Action<Texture2D> onLoaded,
            Action<float> onProgress)
        {
            using var request = UnityWebRequestTexture.GetTexture(url);
            var asyncOp = request.SendWebRequest();

            while (!asyncOp.isDone)
            {
                onProgress?.Invoke(asyncOp.progress);
                yield return null;
            }

            if (request.result != UnityWebRequest.Result.Success)
            {
                Debug.LogWarning($"[LazyTextureLoader] Failed to load texture: {url} — {request.error}");
                yield break;
            }

            Texture2D texture = DownloadHandlerTexture.GetContent(request);

            // Downscale if exceeds max resolution for mid-range devices
            if (texture.width > maxTextureResolution || texture.height > maxTextureResolution)
                texture = ResizeTexture(texture, maxTextureResolution);

            // Apply to renderer
            if (targetRenderer != null && materialProperty != null)
                targetRenderer.material.SetTexture(materialProperty, texture);

            // Cache with LRU eviction
            long sizeBytes = (long)texture.width * texture.height * 4; // RGBA
            EvictIfNeeded(sizeBytes);

            textureCache[url] = new CachedTexture
            {
                Texture = texture,
                SizeBytes = sizeBytes,
                LastAccessTime = Time.time
            };
            lruQueue.Enqueue(url);
            currentCacheBytes += sizeBytes;

            onLoaded?.Invoke(texture);
            Debug.Log($"[LazyTextureLoader] Cached texture: {url} ({sizeBytes / 1024}KB). Cache: {currentCacheBytes / 1024 / 1024}MB/{maxCacheMB}MB");
        }

        private void EvictIfNeeded(long incomingBytes)
        {
            while (currentCacheBytes + incomingBytes > maxCacheBytes && lruQueue.Count > 0)
            {
                string oldest = lruQueue.Dequeue();
                if (textureCache.TryGetValue(oldest, out var evicted))
                {
                    currentCacheBytes -= evicted.SizeBytes;
                    Destroy(evicted.Texture);
                    textureCache.Remove(oldest);
                    Debug.Log($"[LazyTextureLoader] LRU evicted: {oldest}");
                }
            }
        }

        private Texture2D ResizeTexture(Texture2D source, int maxSize)
        {
            float ratio = Mathf.Min((float)maxSize / source.width, (float)maxSize / source.height);
            int newW = Mathf.RoundToInt(source.width * ratio);
            int newH = Mathf.RoundToInt(source.height * ratio);

            RenderTexture rt = RenderTexture.GetTemporary(newW, newH, 0);
            Graphics.Blit(source, rt);
            RenderTexture prev = RenderTexture.active;
            RenderTexture.active = rt;

            Texture2D result = new Texture2D(newW, newH);
            result.ReadPixels(new Rect(0, 0, newW, newH), 0, 0);
            result.Apply();

            RenderTexture.active = prev;
            RenderTexture.ReleaseTemporary(rt);
            Destroy(source);

            return result;
        }

        // ─── Data Types ───────────────────────────────────────────────────────
        private class CachedTexture
        {
            public Texture2D Texture;
            public long SizeBytes;
            public float LastAccessTime;
        }
    }
}
