using System;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;
using ScanForge.Networking;
using ScanForge.UI;

namespace ScanForge.Publishing
{
    /// <summary>
    /// PublishingManager handles the complete in-app publishing pipeline:
    /// - Export 3D model in multiple formats (OBJ, FBX, GLB, USDZ)
    /// - Generate APK download link for sideloading
    /// - Initiate Google Play internal test track upload
    /// - Marketplace export (Sketchfab, CGTrader, etc.)
    /// - Watermark-free export for Pro/Enterprise users
    /// </summary>
    public class PublishingManager : MonoBehaviour
    {
        [Header("Dependencies")]
        [SerializeField] private ApiClient apiClient;
        [SerializeField] private PublishingUI publishingUI;

        [Header("Build Configuration")]
        [SerializeField] private string appPackageName = "com.scanforge.scanforge3d";
        [SerializeField] private string appVersionName = "1.0.0";
        [SerializeField] private int appVersionCode = 1;

        // ─── Events ───────────────────────────────────────────────────────────
        public event Action<ExportResult> OnExportComplete;
        public event Action<PublishResult> OnPublishComplete;
        public event Action<string> OnPublishFailed;
        public event Action<float> OnProgressUpdated;

        // ─── Public API ───────────────────────────────────────────────────────

        /// <summary>
        /// Exports a completed scan in the specified format.
        /// Free tier: includes watermark. Pro/Enterprise: watermark-free.
        /// </summary>
        public IEnumerator ExportModel(
            string jobId,
            ExportFormat format,
            ExportQuality quality,
            Action<ExportResult> onSuccess,
            Action<string> onError)
        {
            publishingUI?.ShowExportProgress("Preparing export...", 0f);
            OnProgressUpdated?.Invoke(0f);

            // Request export from backend
            ExportResponse exportResponse = null;
            string exportError = null;

            yield return apiClient?.RequestHighResExport(
                jobId,
                format.ToString().ToLower(),
                response => exportResponse = response,
                err => exportError = err);

            if (exportError != null)
            {
                onError?.Invoke(exportError);
                OnPublishFailed?.Invoke(exportError);
                yield break;
            }

            publishingUI?.ShowExportProgress("Downloading model...", 0.3f);
            OnProgressUpdated?.Invoke(0.3f);

            // Download the exported file
            byte[] fileData = null;
            string downloadError = null;

            yield return apiClient?.DownloadMesh(
                exportResponse.DownloadUrl,
                data => fileData = data,
                progress => OnProgressUpdated?.Invoke(0.3f + progress * 0.6f),
                err => downloadError = err);

            if (downloadError != null)
            {
                onError?.Invoke(downloadError);
                yield break;
            }

            // Save to device storage
            string savedPath = SaveFileToDevice(fileData, jobId, format);

            publishingUI?.ShowExportProgress("Export complete!", 1f);
            OnProgressUpdated?.Invoke(1f);

            var result = new ExportResult
            {
                JobId = jobId,
                Format = format,
                FilePath = savedPath,
                FileSizeBytes = fileData?.Length ?? 0,
                IsWatermarked = exportResponse.Watermarked,
                DownloadUrl = exportResponse.DownloadUrl
            };

            onSuccess?.Invoke(result);
            OnExportComplete?.Invoke(result);

            // Share via Android intent
            if (!string.IsNullOrEmpty(savedPath))
                ShareFileAndroid(savedPath, GetMimeType(format));
        }

        /// <summary>
        /// Initiates Google Play publishing workflow.
        /// Opens the Play Console upload flow via deep link or in-app browser.
        /// </summary>
        public void PublishToGooglePlay(string apkPath = null)
        {
            publishingUI?.ShowPublishingOptions();

            // Deep link to Play Console upload
            string playConsoleUrl = "https://play.google.com/console/developers";

            // If APK path is provided, trigger Android share intent for upload
            if (!string.IsNullOrEmpty(apkPath) && File.Exists(apkPath))
            {
                ShareFileAndroid(apkPath, "application/vnd.android.package-archive");
            }
            else
            {
                // Open Play Console in browser
                Application.OpenURL(playConsoleUrl);
            }

            publishingUI?.ShowPublishGuide(PublishPlatform.GooglePlay);
        }

        /// <summary>
        /// Generates an APK download package for the current app build.
        /// Requests a signed APK from the CI/CD backend.
        /// </summary>
        public IEnumerator RequestAPKBuild(
            BuildConfiguration config,
            Action<APKBuildResult> onSuccess,
            Action<string> onError)
        {
            publishingUI?.ShowBuildProgress("Requesting APK build...", 0f);

            var buildRequest = new
            {
                package_name = appPackageName,
                version_name = config.VersionName ?? appVersionName,
                version_code = config.VersionCode > 0 ? config.VersionCode : appVersionCode,
                build_type = config.BuildType.ToString().ToLower(),
                signing_config = config.SigningConfig
            };

            APKBuildResult buildResult = null;
            string buildError = null;

            // Request build from CI/CD backend
            string json = JsonConvert.SerializeObject(buildRequest);
            byte[] bodyBytes = System.Text.Encoding.UTF8.GetBytes(json);

            string apiBase = AppConfig.Instance?.ApiBaseUrl ?? "https://api.scanforge3d.com";
            using var request = new UnityWebRequest($"{apiBase}/api/v1/builds/apk", "POST");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", $"Bearer {AuthManager.Instance?.AccessToken}");
            request.timeout = 300; // Build may take up to 5 minutes

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                buildResult = JsonConvert.DeserializeObject<APKBuildResult>(request.downloadHandler.text);
                publishingUI?.ShowBuildProgress("Build complete!", 1f);
                onSuccess?.Invoke(buildResult);
            }
            else
            {
                buildError = request.error;
                onError?.Invoke(buildError);
                OnPublishFailed?.Invoke(buildError);
            }
        }

        /// <summary>
        /// Publishes a 3D scan to an external marketplace (Sketchfab, CGTrader, etc.).
        /// </summary>
        public IEnumerator PublishToMarketplace(
            string jobId,
            MarketplaceTarget target,
            object metadata,
            Action<PublishResult> onSuccess,
            Action<string> onError)
        {
            publishingUI?.ShowPublishProgress($"Publishing to {target}...", 0f);

            PublishResponse publishResponse = null;
            string publishError = null;

            yield return apiClient?.PublishToMarketplace(
                jobId,
                new { target = target.ToString().ToLower(), metadata },
                response => publishResponse = response,
                err => publishError = err);

            if (publishError != null)
            {
                onError?.Invoke(publishError);
                OnPublishFailed?.Invoke(publishError);
                yield break;
            }

            var result = new PublishResult
            {
                ListingId = publishResponse.ListingId,
                MarketplaceUrl = publishResponse.MarketplaceUrl,
                Platform = target,
                Status = publishResponse.Status
            };

            publishingUI?.ShowPublishSuccess(result.MarketplaceUrl);
            onSuccess?.Invoke(result);
            OnPublishComplete?.Invoke(result);
        }

        /// <summary>
        /// Generates a comparison report between two scan sessions (before/after).
        /// </summary>
        public IEnumerator GenerateScanComparison(
            string jobIdBefore,
            string jobIdAfter,
            Action<ComparisonReport> onSuccess,
            Action<string> onError)
        {
            var body = new { job_id_before = jobIdBefore, job_id_after = jobIdAfter };
            string json = JsonConvert.SerializeObject(body);
            byte[] bodyBytes = System.Text.Encoding.UTF8.GetBytes(json);

            string apiBase = AppConfig.Instance?.ApiBaseUrl ?? "https://api.scanforge3d.com";
            using var request = new UnityWebRequest($"{apiBase}/api/v1/scans/compare", "POST");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", $"Bearer {AuthManager.Instance?.AccessToken}");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                var report = JsonConvert.DeserializeObject<ComparisonReport>(request.downloadHandler.text);
                onSuccess?.Invoke(report);
            }
            else
            {
                onError?.Invoke(request.error);
            }
        }

        // ─── Private Methods ──────────────────────────────────────────────────

        private string SaveFileToDevice(byte[] data, string jobId, ExportFormat format)
        {
            try
            {
                string extension = format switch
                {
                    ExportFormat.OBJ => "obj",
                    ExportFormat.FBX => "fbx",
                    ExportFormat.GLB => "glb",
                    ExportFormat.USDZ => "usdz",
                    ExportFormat.STL => "stl",
                    _ => "bin"
                };

                string directory = Path.Combine(Application.persistentDataPath, "Exports");
                Directory.CreateDirectory(directory);

                string filename = $"scan_{jobId}_{DateTime.Now:yyyyMMdd_HHmmss}.{extension}";
                string fullPath = Path.Combine(directory, filename);

                File.WriteAllBytes(fullPath, data);
                Debug.Log($"[PublishingManager] File saved to: {fullPath}");
                return fullPath;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[PublishingManager] Failed to save file: {ex.Message}");
                return null;
            }
        }

        private void ShareFileAndroid(string filePath, string mimeType)
        {
#if UNITY_ANDROID
            try
            {
                AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
                AndroidJavaObject intentObject = new AndroidJavaObject("android.content.Intent");

                intentObject.Call<AndroidJavaObject>("setAction",
                    intentClass.GetStatic<string>("ACTION_SEND"));
                intentObject.Call<AndroidJavaObject>("setType", mimeType);

                AndroidJavaClass fileProviderClass = new AndroidJavaClass(
                    "androidx.core.content.FileProvider");
                AndroidJavaClass contextClass = new AndroidJavaClass(
                    "com.unity3d.player.UnityPlayer");
                AndroidJavaObject currentActivity = contextClass.GetStatic<AndroidJavaObject>(
                    "currentActivity");

                AndroidJavaObject fileObject = new AndroidJavaObject("java.io.File", filePath);
                AndroidJavaObject uriObject = fileProviderClass.CallStatic<AndroidJavaObject>(
                    "getUriForFile",
                    currentActivity,
                    $"{appPackageName}.fileprovider",
                    fileObject);

                intentObject.Call<AndroidJavaObject>("putExtra",
                    intentClass.GetStatic<string>("EXTRA_STREAM"), uriObject);
                intentObject.Call<AndroidJavaObject>("addFlags",
                    intentClass.GetStatic<int>("FLAG_GRANT_READ_URI_PERMISSION"));

                AndroidJavaObject chooser = intentClass.CallStatic<AndroidJavaObject>(
                    "createChooser", intentObject, "Share 3D Model");
                currentActivity.Call("startActivity", chooser);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[PublishingManager] Android share failed: {ex.Message}");
            }
#else
            Debug.Log($"[PublishingManager] Share not supported on this platform. File at: {filePath}");
#endif
        }

        private string GetMimeType(ExportFormat format)
        {
            return format switch
            {
                ExportFormat.GLB => "model/gltf-binary",
                ExportFormat.USDZ => "model/vnd.usdz+zip",
                ExportFormat.FBX => "application/octet-stream",
                ExportFormat.OBJ => "text/plain",
                ExportFormat.STL => "model/stl",
                _ => "application/octet-stream"
            };
        }
    }

    // ─── Data Models ──────────────────────────────────────────────────────────

    [Serializable]
    public class ExportResult
    {
        public string JobId;
        public ExportFormat Format;
        public string FilePath;
        public long FileSizeBytes;
        public bool IsWatermarked;
        public string DownloadUrl;
    }

    [Serializable]
    public class PublishResult
    {
        public string ListingId;
        public string MarketplaceUrl;
        public MarketplaceTarget Platform;
        public string Status;
    }

    [Serializable]
    public class APKBuildResult
    {
        [JsonProperty("build_id")] public string BuildId;
        [JsonProperty("download_url")] public string DownloadUrl;
        [JsonProperty("version_name")] public string VersionName;
        [JsonProperty("version_code")] public int VersionCode;
        [JsonProperty("file_size_bytes")] public long FileSizeBytes;
        [JsonProperty("signed")] public bool Signed;
        [JsonProperty("expires_at")] public string ExpiresAt;
    }

    [Serializable]
    public class BuildConfiguration
    {
        public string VersionName;
        public int VersionCode;
        public BuildType BuildType;
        public SigningConfig SigningConfig;
    }

    [Serializable]
    public class SigningConfig
    {
        [JsonProperty("keystore_alias")] public string KeystoreAlias;
        [JsonProperty("use_debug_key")] public bool UseDebugKey;
    }

    [Serializable]
    public class ComparisonReport
    {
        [JsonProperty("job_id_before")] public string JobIdBefore;
        [JsonProperty("job_id_after")] public string JobIdAfter;
        [JsonProperty("volume_change_cm3")] public float VolumeChangeCm3;
        [JsonProperty("surface_area_change_cm2")] public float SurfaceAreaChangeCm2;
        [JsonProperty("confidence_delta")] public float ConfidenceDelta;
        [JsonProperty("comparison_image_url")] public string ComparisonImageUrl;
        [JsonProperty("summary")] public string Summary;
    }

    public enum ExportFormat { OBJ, FBX, GLB, USDZ, STL }
    public enum ExportQuality { Low, Medium, High, Ultra }
    public enum BuildType { Debug, Release }
    public enum MarketplaceTarget { Sketchfab, CGTrader, TurboSquid, Fab, Custom }
}
