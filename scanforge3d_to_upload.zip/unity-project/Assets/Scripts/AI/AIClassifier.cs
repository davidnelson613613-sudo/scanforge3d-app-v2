using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;
using ScanForge.Utils;

namespace ScanForge.AI
{
    /// <summary>
    /// AIClassifier handles on-device and server-side AI inference for:
    /// - Object auto-classification (category, subcategory, tags)
    /// - Material type detection (plastic, metal, wood, ceramic, fabric, etc.)
    /// - Volume and weight estimation from mesh geometry
    /// - Marketplace-ready metadata generation
    /// </summary>
    public class AIClassifier : MonoBehaviour
    {
        [Header("Configuration")]
        [SerializeField] private string classificationEndpoint = "/api/v1/ai/classify";
        [SerializeField] private bool useOnDeviceModel = false;
        [SerializeField] private TextAsset onDeviceModelAsset; // TFLite model

        [Header("Material Density Table (kg/m³)")]
        [SerializeField] private MaterialDensityEntry[] materialDensities = new MaterialDensityEntry[]
        {
            new MaterialDensityEntry { MaterialName = "plastic",   DensityKgM3 = 1200f },
            new MaterialDensityEntry { MaterialName = "metal",     DensityKgM3 = 7800f },
            new MaterialDensityEntry { MaterialName = "wood",      DensityKgM3 = 700f  },
            new MaterialDensityEntry { MaterialName = "ceramic",   DensityKgM3 = 2400f },
            new MaterialDensityEntry { MaterialName = "fabric",    DensityKgM3 = 300f  },
            new MaterialDensityEntry { MaterialName = "glass",     DensityKgM3 = 2500f },
            new MaterialDensityEntry { MaterialName = "rubber",    DensityKgM3 = 1500f },
            new MaterialDensityEntry { MaterialName = "stone",     DensityKgM3 = 2700f },
            new MaterialDensityEntry { MaterialName = "paper",     DensityKgM3 = 1200f },
            new MaterialDensityEntry { MaterialName = "foam",      DensityKgM3 = 50f   },
        };

        private Dictionary<string, float> densityLookup;

        // ─── Events ───────────────────────────────────────────────────────────
        public event Action<ClassificationResult> OnClassificationComplete;
        public event Action<string> OnClassificationFailed;

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            BuildDensityLookup();
        }

        // ─── Public API ───────────────────────────────────────────────────────

        /// <summary>
        /// Classifies an object from a thumbnail image and mesh metadata.
        /// Sends request to backend AI service or uses on-device model.
        /// </summary>
        public IEnumerator ClassifyObject(
            string jobId,
            Texture2D thumbnail,
            MeshMetadata meshMeta,
            Action<ClassificationResult> onSuccess,
            Action<string> onError)
        {
            if (useOnDeviceModel && onDeviceModelAsset != null)
            {
                // On-device inference path (TFLite)
                yield return RunOnDeviceInference(thumbnail, meshMeta, onSuccess, onError);
            }
            else
            {
                // Server-side inference path
                yield return RunServerInference(jobId, thumbnail, meshMeta, onSuccess, onError);
            }
        }

        /// <summary>
        /// Estimates object volume from mesh geometry using the divergence theorem.
        /// Returns volume in cubic centimeters.
        /// </summary>
        public float EstimateVolumeCm3(Mesh mesh)
        {
            if (mesh == null || mesh.triangles.Length == 0) return 0f;

            Vector3[] vertices = mesh.vertices;
            int[] triangles = mesh.triangles;
            float volume = 0f;

            for (int i = 0; i < triangles.Length; i += 3)
            {
                Vector3 v0 = vertices[triangles[i]];
                Vector3 v1 = vertices[triangles[i + 1]];
                Vector3 v2 = vertices[triangles[i + 2]];
                volume += SignedVolumeOfTriangle(v0, v1, v2);
            }

            // Convert from Unity units (meters³) to cm³
            float volumeM3 = Mathf.Abs(volume);
            return volumeM3 * 1_000_000f; // 1 m³ = 1,000,000 cm³
        }

        /// <summary>
        /// Estimates object weight in grams based on volume and detected material density.
        /// </summary>
        public float EstimateWeightGrams(float volumeCm3, string materialType)
        {
            float densityKgM3 = GetMaterialDensity(materialType);
            float densityGCm3 = densityKgM3 / 1000f; // kg/m³ → g/cm³
            return volumeCm3 * densityGCm3;
        }

        /// <summary>
        /// Generates marketplace-ready metadata for export platforms.
        /// </summary>
        public MarketplaceMetadata GenerateMarketplaceMetadata(ClassificationResult classification, MeshMetadata mesh)
        {
            return new MarketplaceMetadata
            {
                Title = FormatTitle(classification.ObjectClass, classification.Subcategory),
                Description = GenerateDescription(classification, mesh),
                Tags = GenerateTags(classification),
                Category = MapToMarketplaceCategory(classification.ObjectClass),
                PolyCount = mesh.TriangleCount,
                HasTextures = mesh.HasTextures,
                FileFormats = new[] { "OBJ", "FBX", "GLB", "USDZ" },
                License = "Royalty-Free",
                CreatedAt = DateTime.UtcNow.ToString("yyyy-MM-dd")
            };
        }

        // ─── Private Methods ──────────────────────────────────────────────────

        private IEnumerator RunServerInference(
            string jobId,
            Texture2D thumbnail,
            MeshMetadata meshMeta,
            Action<ClassificationResult> onSuccess,
            Action<string> onError)
        {
            byte[] imageBytes = thumbnail.EncodeToJPG(85);
            string base64Image = Convert.ToBase64String(imageBytes);

            var requestBody = new ClassificationRequest
            {
                JobId = jobId,
                ThumbnailBase64 = base64Image,
                MeshMetadata = meshMeta
            };

            string json = JsonConvert.SerializeObject(requestBody);
            byte[] bodyBytes = System.Text.Encoding.UTF8.GetBytes(json);

            string apiBase = AppConfig.Instance?.ApiBaseUrl ?? "http://localhost:8000";
            using var request = new UnityWebRequest($"{apiBase}{classificationEndpoint}", "POST");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", $"Bearer {AuthManager.Instance?.AccessToken}");

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    var result = JsonConvert.DeserializeObject<ClassificationResult>(
                        request.downloadHandler.text);
                    onSuccess?.Invoke(result);
                    OnClassificationComplete?.Invoke(result);
                }
                catch (Exception ex)
                {
                    string err = $"Failed to parse classification response: {ex.Message}";
                    onError?.Invoke(err);
                    OnClassificationFailed?.Invoke(err);
                }
            }
            else
            {
                string err = $"Classification request failed: {request.error}";
                onError?.Invoke(err);
                OnClassificationFailed?.Invoke(err);
            }
        }

        private IEnumerator RunOnDeviceInference(
            Texture2D thumbnail,
            MeshMetadata meshMeta,
            Action<ClassificationResult> onSuccess,
            Action<string> onError)
        {
            // Placeholder for TFLite on-device inference
            // In production: use Unity Sentis or TFLite plugin
            yield return new WaitForEndOfFrame();

            var fallbackResult = new ClassificationResult
            {
                ObjectClass = "unknown",
                Subcategory = "general",
                Confidence = 0.5f,
                MaterialType = "plastic",
                Tags = new[] { "object", "3d-scan" }
            };

            onSuccess?.Invoke(fallbackResult);
            Debug.LogWarning("[AIClassifier] On-device model not fully implemented. Using fallback.");
        }

        private float SignedVolumeOfTriangle(Vector3 p1, Vector3 p2, Vector3 p3)
        {
            return Vector3.Dot(p1, Vector3.Cross(p2, p3)) / 6f;
        }

        private float GetMaterialDensity(string materialType)
        {
            if (densityLookup == null) BuildDensityLookup();
            string key = materialType?.ToLower() ?? "plastic";
            return densityLookup.TryGetValue(key, out float density) ? density : 1200f;
        }

        private void BuildDensityLookup()
        {
            densityLookup = new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in materialDensities)
                densityLookup[entry.MaterialName] = entry.DensityKgM3;
        }

        private string FormatTitle(string objectClass, string subcategory)
        {
            if (string.IsNullOrEmpty(subcategory) || subcategory == "general")
                return $"3D Scan - {ToTitleCase(objectClass)}";
            return $"3D Scan - {ToTitleCase(subcategory)} ({ToTitleCase(objectClass)})";
        }

        private string GenerateDescription(ClassificationResult classification, MeshMetadata mesh)
        {
            return $"High-quality 3D scan of a {classification.ObjectClass}. " +
                   $"Material: {classification.MaterialType}. " +
                   $"Polygon count: {mesh.TriangleCount:N0}. " +
                   $"Captured with ScanForge3D. " +
                   $"Confidence score: {classification.Confidence * 100:F0}%.";
        }

        private string[] GenerateTags(ClassificationResult classification)
        {
            var tags = new List<string>(classification.Tags ?? Array.Empty<string>());
            tags.Add("3d-scan");
            tags.Add("photogrammetry");
            tags.Add(classification.ObjectClass);
            tags.Add(classification.MaterialType);
            tags.Add("scanforge");
            return tags.ToArray();
        }

        private string MapToMarketplaceCategory(string objectClass)
        {
            return objectClass?.ToLower() switch
            {
                "furniture" => "Home & Furniture",
                "electronics" => "Electronics",
                "toy" => "Toys & Games",
                "food" => "Food & Beverage",
                "clothing" => "Fashion",
                "tool" => "Tools & Hardware",
                "vehicle" => "Vehicles",
                "plant" => "Nature",
                _ => "General Objects"
            };
        }

        private string ToTitleCase(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;
            return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(input.ToLower());
        }
    }

    // ─── Data Models ──────────────────────────────────────────────────────────

    [Serializable]
    public class ClassificationRequest
    {
        [JsonProperty("job_id")] public string JobId;
        [JsonProperty("thumbnail_base64")] public string ThumbnailBase64;
        [JsonProperty("mesh_metadata")] public MeshMetadata MeshMetadata;
    }

    [Serializable]
    public class ClassificationResult
    {
        [JsonProperty("object_class")] public string ObjectClass;
        [JsonProperty("subcategory")] public string Subcategory;
        [JsonProperty("confidence")] public float Confidence;
        [JsonProperty("material_type")] public string MaterialType;
        [JsonProperty("tags")] public string[] Tags;
        [JsonProperty("estimated_volume_cm3")] public float EstimatedVolumeCm3;
        [JsonProperty("estimated_weight_grams")] public float EstimatedWeightGrams;
    }

    [Serializable]
    public class MeshMetadata
    {
        [JsonProperty("triangle_count")] public int TriangleCount;
        [JsonProperty("vertex_count")] public int VertexCount;
        [JsonProperty("has_textures")] public bool HasTextures;
        [JsonProperty("bounding_box")] public float[] BoundingBox; // [w, h, d] in meters
    }

    [Serializable]
    public class MarketplaceMetadata
    {
        public string Title;
        public string Description;
        public string[] Tags;
        public string Category;
        public int PolyCount;
        public bool HasTextures;
        public string[] FileFormats;
        public string License;
        public string CreatedAt;
    }

    [Serializable]
    public class MaterialDensityEntry
    {
        public string MaterialName;
        public float DensityKgM3;
    }
}
