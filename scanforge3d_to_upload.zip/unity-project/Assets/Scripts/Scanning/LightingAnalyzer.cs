using UnityEngine;
using UnityEngine.XR.ARFoundation;

namespace ScanForge.Scanning
{
    /// <summary>
    /// LightingAnalyzer monitors ambient light conditions using ARFoundation's
    /// light estimation API and provides real-time feedback to the scan pipeline.
    /// </summary>
    public class LightingAnalyzer : MonoBehaviour
    {
        [Header("Thresholds")]
        [SerializeField] private float minAcceptableLux = 100f;
        [SerializeField] private float goodLightingLux = 300f;
        [SerializeField] private float excellentLightingLux = 600f;

        // ARFoundation brightness is 0–1, roughly mapped to lux
        private const float BrightnessToLuxFactor = 1000f;

        private float currentBrightness = 0.5f;

        public float CurrentLux => currentBrightness * BrightnessToLuxFactor;
        public LightingQuality Quality
        {
            get
            {
                float lux = CurrentLux;
                if (lux >= excellentLightingLux) return LightingQuality.Excellent;
                if (lux >= goodLightingLux) return LightingQuality.Good;
                if (lux >= minAcceptableLux) return LightingQuality.Acceptable;
                return LightingQuality.Poor;
            }
        }

        public bool IsAcceptable => CurrentLux >= minAcceptableLux;

        /// <summary>Called by ScanManager when a new AR frame is received.</summary>
        public void UpdateBrightness(float normalizedBrightness)
        {
            currentBrightness = Mathf.Clamp01(normalizedBrightness);
        }

        /// <summary>Returns a user-facing description of current lighting.</summary>
        public string GetLightingAdvice()
        {
            return Quality switch
            {
                LightingQuality.Poor => "Too dark. Move to a brighter area or turn on lights.",
                LightingQuality.Acceptable => "Lighting is acceptable but could be better.",
                LightingQuality.Good => "Good lighting conditions.",
                LightingQuality.Excellent => "Excellent lighting. Perfect for scanning.",
                _ => "Unknown lighting conditions."
            };
        }
    }

    public enum LightingQuality { Poor, Acceptable, Good, Excellent }
}
