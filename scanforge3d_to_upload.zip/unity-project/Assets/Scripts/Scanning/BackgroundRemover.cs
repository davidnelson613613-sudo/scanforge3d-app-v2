using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;
using ScanForge.Utils;

namespace ScanForge.Scanning
{
    /// <summary>
    /// BackgroundRemover sends captured frames to the backend AI service
    /// for automatic background segmentation and removal.
    /// Supports both server-side (rembg) and on-device (U2Net TFLite) modes.
    /// </summary>
    public class BackgroundRemover : MonoBehaviour
    {
        [Header("Configuration")]
        [SerializeField] private bool useServerSideRemoval = true;
        [SerializeField] private string removalEndpoint = "/api/v1/ai/remove-background";

        /// <summary>
        /// Removes the background from a texture using the configured method.
        /// Returns a new Texture2D with alpha channel for the foreground object.
        /// </summary>
        public IEnumerator RemoveBackground(
            Texture2D inputTexture,
            Action<Texture2D> onSuccess,
            Action<string> onError)
        {
            if (useServerSideRemoval)
                yield return RemoveBackgroundServer(inputTexture, onSuccess, onError);
            else
                yield return RemoveBackgroundOnDevice(inputTexture, onSuccess, onError);
        }

        private IEnumerator RemoveBackgroundServer(
            Texture2D inputTexture,
            Action<Texture2D> onSuccess,
            Action<string> onError)
        {
            byte[] imageBytes = inputTexture.EncodeToJPG(90);
            string base64 = Convert.ToBase64String(imageBytes);
            var body = new { image_base64 = base64, return_format = "png" };
            string json = JsonConvert.SerializeObject(body);
            byte[] bodyBytes = System.Text.Encoding.UTF8.GetBytes(json);

            string apiBase = AppConfig.Instance?.ApiBaseUrl ?? "https://api.scanforge3d.com";
            using var request = new UnityWebRequest($"{apiBase}{removalEndpoint}", "POST");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", $"Bearer {AuthManager.Instance?.AccessToken}");
            request.timeout = 30;

            yield return request.SendWebRequest();

            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    var response = JsonConvert.DeserializeObject<BgRemovalResponse>(request.downloadHandler.text);
                    byte[] pngBytes = Convert.FromBase64String(response.ResultBase64);
                    Texture2D result = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                    result.LoadImage(pngBytes);
                    onSuccess?.Invoke(result);
                }
                catch (Exception ex)
                {
                    onError?.Invoke($"Failed to decode background removal result: {ex.Message}");
                }
            }
            else
            {
                onError?.Invoke($"Background removal failed: {request.error}");
            }
        }

        private IEnumerator RemoveBackgroundOnDevice(
            Texture2D inputTexture,
            Action<Texture2D> onSuccess,
            Action<string> onError)
        {
            // Placeholder for on-device U2Net TFLite inference
            yield return new WaitForEndOfFrame();
            Debug.LogWarning("[BackgroundRemover] On-device removal not implemented. Returning original.");
            onSuccess?.Invoke(inputTexture);
        }

        [Serializable]
        private class BgRemovalResponse
        {
            [JsonProperty("result_base64")] public string ResultBase64;
            [JsonProperty("processing_time_ms")] public int ProcessingTimeMs;
        }
    }
}
