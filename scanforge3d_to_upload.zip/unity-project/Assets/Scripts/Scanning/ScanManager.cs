using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using ScanForge.Networking;
using ScanForge.UI;
using ScanForge.AI;
using ScanForge.Utils;

namespace ScanForge.Scanning
{
    /// <summary>
    /// ScanManager orchestrates the entire 3D scanning session lifecycle.
    /// Handles image capture, batching, feature detection, lighting checks,
    /// and submission to the reconstruction backend.
    /// Optimized for mid-range Android devices with memory-safe image batching.
    /// </summary>
    public class ScanManager : MonoBehaviour
    {
        // ─── Inspector References ────────────────────────────────────────────
        [Header("AR Components")]
        [SerializeField] private ARCameraManager arCameraManager;
        [SerializeField] private ARPointCloudManager pointCloudManager;
        [SerializeField] private ARPlaneManager planeManager;
        [SerializeField] private AROcclusionManager occlusionManager;

        [Header("Scan Settings")]
        [SerializeField] private int maxFramesPerBatch = 20;
        [SerializeField] private int targetTotalFrames = 120;
        [SerializeField] private float captureIntervalSeconds = 0.5f;
        [SerializeField] private float minFeatureThreshold = 50f;
        [SerializeField] private float minLightingLux = 100f;
        [SerializeField] private int maxRetryAttempts = 3;

        [Header("Dependencies")]
        [SerializeField] private ScanHUD scanHUD;
        [SerializeField] private ApiClient apiClient;
        [SerializeField] private AIClassifier aiClassifier;
        [SerializeField] private LightingAnalyzer lightingAnalyzer;
        [SerializeField] private BackgroundRemover backgroundRemover;

        // ─── Private State ────────────────────────────────────────────────────
        private ScanSession currentSession;
        private List<byte[]> capturedFrameBuffer = new List<byte[]>();
        private List<byte[]> currentBatch = new List<byte[]>();
        private bool isScanning = false;
        private bool isPaused = false;
        private int totalFramesCaptured = 0;
        private int retryCount = 0;
        private Coroutine captureCoroutine;
        private Coroutine uploadCoroutine;

        // ─── Events ───────────────────────────────────────────────────────────
        public event Action<ScanSession> OnScanStarted;
        public event Action<float> OnProgressUpdated;
        public event Action<ScanResult> OnScanCompleted;
        public event Action<ScanError> OnScanFailed;
        public event Action<string> OnStatusMessage;

        // ─── Public Properties ────────────────────────────────────────────────
        public bool IsScanning => isScanning;
        public ScanSession CurrentSession => currentSession;
        public float Progress => targetTotalFrames > 0
            ? Mathf.Clamp01((float)totalFramesCaptured / targetTotalFrames)
            : 0f;

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            ValidateDependencies();
        }

        private void OnEnable()
        {
            if (arCameraManager != null)
                arCameraManager.frameReceived += OnARFrameReceived;
        }

        private void OnDisable()
        {
            if (arCameraManager != null)
                arCameraManager.frameReceived -= OnARFrameReceived;
            StopAllCoroutines();
        }

        // ─── Public API ───────────────────────────────────────────────────────

        /// <summary>
        /// Begins a new scan session. Validates lighting and feature density before starting.
        /// </summary>
        public void StartScan()
        {
            if (isScanning)
            {
                Debug.LogWarning("[ScanManager] Scan already in progress.");
                return;
            }

            // Pre-scan validation
            if (!ValidateLighting())
            {
                scanHUD?.ShowLightingGuide();
                OnScanFailed?.Invoke(new ScanError(ScanErrorType.PoorLighting,
                    "Insufficient lighting detected. Please move to a brighter area."));
                return;
            }

            currentSession = new ScanSession
            {
                SessionId = Guid.NewGuid().ToString(),
                StartTime = DateTime.UtcNow,
                Status = ScanStatus.Capturing
            };

            capturedFrameBuffer.Clear();
            currentBatch.Clear();
            totalFramesCaptured = 0;
            retryCount = 0;
            isScanning = true;
            isPaused = false;

            scanHUD?.ShowScanningUI();
            OnScanStarted?.Invoke(currentSession);
            OnStatusMessage?.Invoke("Scan started. Move slowly around the object.");

            captureCoroutine = StartCoroutine(CaptureFramesCoroutine());
        }

        /// <summary>
        /// Pauses the current scan session without losing captured data.
        /// </summary>
        public void PauseScan()
        {
            if (!isScanning || isPaused) return;
            isPaused = true;
            OnStatusMessage?.Invoke("Scan paused.");
        }

        /// <summary>
        /// Resumes a paused scan session.
        /// </summary>
        public void ResumeScan()
        {
            if (!isScanning || !isPaused) return;
            isPaused = false;
            OnStatusMessage?.Invoke("Scan resumed.");
        }

        /// <summary>
        /// Cancels the current scan session and clears all buffers.
        /// </summary>
        public void CancelScan()
        {
            if (!isScanning) return;

            if (captureCoroutine != null) StopCoroutine(captureCoroutine);
            if (uploadCoroutine != null) StopCoroutine(uploadCoroutine);

            isScanning = false;
            capturedFrameBuffer.Clear();
            currentBatch.Clear();
            currentSession = null;

            scanHUD?.HideScanningUI();
            OnStatusMessage?.Invoke("Scan cancelled.");
        }

        /// <summary>
        /// Finalizes capture and submits all batches for reconstruction.
        /// </summary>
        public void FinalizeScan()
        {
            if (!isScanning) return;

            if (captureCoroutine != null) StopCoroutine(captureCoroutine);
            isScanning = false;

            if (totalFramesCaptured < 30)
            {
                OnScanFailed?.Invoke(new ScanError(ScanErrorType.InsufficientFrames,
                    "Not enough frames captured. Please scan more of the object."));
                return;
            }

            // Flush remaining frames in buffer
            if (capturedFrameBuffer.Count > 0)
            {
                currentBatch.AddRange(capturedFrameBuffer);
                capturedFrameBuffer.Clear();
            }

            uploadCoroutine = StartCoroutine(SubmitForReconstructionCoroutine());
        }

        // ─── Private Methods ──────────────────────────────────────────────────

        private IEnumerator CaptureFramesCoroutine()
        {
            while (isScanning && totalFramesCaptured < targetTotalFrames)
            {
                if (!isPaused)
                {
                    yield return new WaitForSeconds(captureIntervalSeconds);

                    // Check lighting on every 10th frame
                    if (totalFramesCaptured % 10 == 0 && !ValidateLighting())
                    {
                        scanHUD?.ShowLightingWarning();
                        OnStatusMessage?.Invoke("Warning: Poor lighting detected.");
                        continue;
                    }

                    // Check feature density
                    float featureCount = GetCurrentFeatureCount();
                    if (featureCount < minFeatureThreshold)
                    {
                        scanHUD?.ShowTextureGuide();
                        OnStatusMessage?.Invoke("Low texture detected. Add texture to object surface.");
                        continue;
                    }

                    // Capture frame
                    yield return CaptureCurrentFrame();

                    // Update progress
                    float progress = Progress;
                    scanHUD?.UpdateProgress(progress);
                    OnProgressUpdated?.Invoke(progress);

                    // Batch upload when buffer is full — prevents memory crash
                    if (capturedFrameBuffer.Count >= maxFramesPerBatch)
                    {
                        yield return FlushBatchToUploadQueue();
                    }
                }
                else
                {
                    yield return new WaitForSeconds(0.1f);
                }
            }

            // Auto-finalize when target reached
            if (totalFramesCaptured >= targetTotalFrames)
            {
                FinalizeScan();
            }
        }

        private IEnumerator CaptureCurrentFrame()
        {
            // Request camera image from ARFoundation
            if (!arCameraManager.TryAcquireLatestCpuImage(out XRCpuImage image))
                yield break;

            using (image)
            {
                var conversionParams = new XRCpuImage.ConversionParams
                {
                    inputRect = new RectInt(0, 0, image.width, image.height),
                    outputDimensions = new Vector2Int(image.width / 2, image.height / 2), // downsample for memory
                    outputFormat = TextureFormat.RGB24,
                    transformation = XRCpuImage.Transformation.MirrorY
                };

                int size = image.GetConvertedDataSize(conversionParams);
                var buffer = new Unity.Collections.NativeArray<byte>(size, Unity.Collections.Allocator.Temp);

                try
                {
                    image.Convert(conversionParams, buffer);
                    byte[] frameData = buffer.ToArray();
                    capturedFrameBuffer.Add(frameData);
                    totalFramesCaptured++;
                }
                finally
                {
                    buffer.Dispose();
                }
            }

            yield return null;
        }

        private IEnumerator FlushBatchToUploadQueue()
        {
            // Move frames from buffer to current batch
            currentBatch.AddRange(capturedFrameBuffer);
            capturedFrameBuffer.Clear();

            // Upload batch if we have a session ID from the server
            if (!string.IsNullOrEmpty(currentSession?.ServerJobId))
            {
                yield return apiClient?.UploadFrameBatch(
                    currentSession.ServerJobId,
                    currentBatch.ToArray(),
                    OnBatchUploadSuccess,
                    OnBatchUploadFailed);

                currentBatch.Clear();
            }

            // Force GC to free memory on mid-range devices
            GC.Collect();
            yield return null;
        }

        private IEnumerator SubmitForReconstructionCoroutine()
        {
            currentSession.Status = ScanStatus.Uploading;
            scanHUD?.ShowUploadingUI();
            OnStatusMessage?.Invoke("Uploading scan data...");

            // Create job on server first
            yield return apiClient?.CreateScanJob(
                currentSession,
                OnJobCreated,
                OnJobCreationFailed);

            // Upload any remaining batches
            if (currentBatch.Count > 0)
            {
                yield return apiClient?.UploadFrameBatch(
                    currentSession.ServerJobId,
                    currentBatch.ToArray(),
                    OnBatchUploadSuccess,
                    OnBatchUploadFailed);
                currentBatch.Clear();
            }

            // Trigger reconstruction
            yield return apiClient?.TriggerReconstruction(
                currentSession.ServerJobId,
                OnReconstructionTriggered,
                OnReconstructionFailed);

            // Poll for completion
            yield return PollReconstructionStatus();
        }

        private IEnumerator PollReconstructionStatus()
        {
            currentSession.Status = ScanStatus.Processing;
            scanHUD?.ShowProcessingUI();
            OnStatusMessage?.Invoke("Processing 3D reconstruction...");

            float pollInterval = 3f;
            float maxWaitTime = 300f; // 5 minutes max
            float elapsed = 0f;

            while (elapsed < maxWaitTime)
            {
                yield return new WaitForSeconds(pollInterval);
                elapsed += pollInterval;

                yield return apiClient?.GetJobStatus(
                    currentSession.ServerJobId,
                    OnJobStatusReceived,
                    OnJobStatusFailed);

                if (currentSession.Status == ScanStatus.Completed ||
                    currentSession.Status == ScanStatus.Failed)
                    break;
            }

            if (currentSession.Status != ScanStatus.Completed)
            {
                HandleReconstructionFailure("Reconstruction timed out.");
            }
        }

        private bool ValidateLighting()
        {
            return lightingAnalyzer == null || lightingAnalyzer.CurrentLux >= minLightingLux;
        }

        private float GetCurrentFeatureCount()
        {
            if (pointCloudManager == null) return float.MaxValue;
            var trackables = pointCloudManager.trackables;
            int count = 0;
            foreach (var cloud in trackables)
            {
                if (cloud.positions.HasValue)
                    count += cloud.positions.Value.Length;
            }
            return count;
        }

        private void HandleReconstructionFailure(string reason)
        {
            retryCount++;
            if (retryCount <= maxRetryAttempts)
            {
                OnStatusMessage?.Invoke($"Reconstruction failed. Retrying ({retryCount}/{maxRetryAttempts})...");
                uploadCoroutine = StartCoroutine(SubmitForReconstructionCoroutine());
            }
            else
            {
                currentSession.Status = ScanStatus.Failed;
                scanHUD?.ShowErrorUI(reason);
                OnScanFailed?.Invoke(new ScanError(ScanErrorType.ReconstructionFailed, reason));
            }
        }

        private void ValidateDependencies()
        {
            if (arCameraManager == null) Debug.LogError("[ScanManager] ARCameraManager is not assigned.");
            if (scanHUD == null) Debug.LogError("[ScanManager] ScanHUD is not assigned.");
            if (apiClient == null) Debug.LogError("[ScanManager] ApiClient is not assigned.");
        }

        // ─── Callbacks ────────────────────────────────────────────────────────

        private void OnARFrameReceived(ARCameraFrameEventArgs args)
        {
            // Lighting estimation from AR frame
            if (args.lightEstimation.averageBrightness.HasValue)
                lightingAnalyzer?.UpdateBrightness(args.lightEstimation.averageBrightness.Value);
        }

        private void OnJobCreated(string serverJobId)
        {
            currentSession.ServerJobId = serverJobId;
            Debug.Log($"[ScanManager] Job created: {serverJobId}");
        }

        private void OnJobCreationFailed(string error)
        {
            HandleReconstructionFailure($"Failed to create job: {error}");
        }

        private void OnBatchUploadSuccess(int batchIndex)
        {
            Debug.Log($"[ScanManager] Batch {batchIndex} uploaded successfully.");
        }

        private void OnBatchUploadFailed(string error)
        {
            Debug.LogWarning($"[ScanManager] Batch upload failed: {error}");
        }

        private void OnReconstructionTriggered(string jobId)
        {
            Debug.Log($"[ScanManager] Reconstruction triggered for job: {jobId}");
        }

        private void OnReconstructionFailed(string error)
        {
            HandleReconstructionFailure(error);
        }

        private void OnJobStatusReceived(JobStatusResponse status)
        {
            scanHUD?.UpdateConfidenceScore(status.ConfidenceScore);

            switch (status.Status)
            {
                case "completed":
                    currentSession.Status = ScanStatus.Completed;
                    currentSession.ConfidenceScore = status.ConfidenceScore;
                    currentSession.MeshUrl = status.MeshUrl;
                    scanHUD?.ShowCompletionUI(status.ConfidenceScore);
                    OnScanCompleted?.Invoke(new ScanResult
                    {
                        Session = currentSession,
                        MeshUrl = status.MeshUrl,
                        ConfidenceScore = status.ConfidenceScore,
                        ObjectClass = status.ObjectClass,
                        MaterialType = status.MaterialType,
                        EstimatedVolumeCm3 = status.EstimatedVolumeCm3,
                        EstimatedWeightGrams = status.EstimatedWeightGrams
                    });
                    break;

                case "failed":
                    HandleReconstructionFailure(status.ErrorMessage ?? "Unknown reconstruction error.");
                    break;

                case "processing":
                    scanHUD?.UpdateProcessingProgress(status.ProcessingProgress);
                    break;
            }
        }

        private void OnJobStatusFailed(string error)
        {
            Debug.LogWarning($"[ScanManager] Status poll failed: {error}");
        }
    }

    // ─── Data Models ──────────────────────────────────────────────────────────

    [Serializable]
    public class ScanSession
    {
        public string SessionId;
        public string ServerJobId;
        public DateTime StartTime;
        public DateTime? EndTime;
        public ScanStatus Status;
        public float ConfidenceScore;
        public string MeshUrl;
    }

    [Serializable]
    public class ScanResult
    {
        public ScanSession Session;
        public string MeshUrl;
        public float ConfidenceScore;
        public string ObjectClass;
        public string MaterialType;
        public float EstimatedVolumeCm3;
        public float EstimatedWeightGrams;
    }

    [Serializable]
    public class ScanError
    {
        public ScanErrorType ErrorType;
        public string Message;

        public ScanError(ScanErrorType type, string message)
        {
            ErrorType = type;
            Message = message;
        }
    }

    [Serializable]
    public class JobStatusResponse
    {
        public string Status;
        public float ConfidenceScore;
        public float ProcessingProgress;
        public string MeshUrl;
        public string ObjectClass;
        public string MaterialType;
        public float EstimatedVolumeCm3;
        public float EstimatedWeightGrams;
        public string ErrorMessage;
    }

    public enum ScanStatus { Idle, Capturing, Uploading, Processing, Completed, Failed }
    public enum ScanErrorType { PoorLighting, InsufficientFeatures, InsufficientFrames, ReconstructionFailed, NetworkError }
}
