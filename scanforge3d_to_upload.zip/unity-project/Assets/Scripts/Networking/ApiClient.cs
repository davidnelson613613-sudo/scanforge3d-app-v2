using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;
using ScanForge.Scanning;
using ScanForge.Utils;

namespace ScanForge.Networking
{
    /// <summary>
    /// ApiClient manages all HTTP communication between the Unity app and the ScanForge backend.
    /// Features: JWT authentication, signed upload URLs, retry logic, request queuing,
    /// and streaming support for large mesh files.
    /// </summary>
    public class ApiClient : MonoBehaviour
    {
        [Header("Configuration")]
        [SerializeField] private string apiBaseUrl = "https://api.scanforge3d.com";
        [SerializeField] private int maxRetries = 3;
        [SerializeField] private float retryDelaySeconds = 2f;
        [SerializeField] private float requestTimeoutSeconds = 30f;
        [SerializeField] private int maxConcurrentUploads = 2;

        [Header("Auth")]
        [SerializeField] private AuthManager authManager;

        private Queue<Func<IEnumerator>> requestQueue = new Queue<Func<IEnumerator>>();
        private int activeUploads = 0;

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            if (authManager == null)
                authManager = FindObjectOfType<AuthManager>();
        }

        // ─── Authentication ───────────────────────────────────────────────────

        /// <summary>Authenticates user and stores JWT tokens.</summary>
        public IEnumerator Login(
            string email,
            string password,
            Action<AuthResponse> onSuccess,
            Action<string> onError)
        {
            var body = new { email, password };
            yield return PostRequest<AuthResponse>("/api/v1/auth/login", body, onSuccess, onError, requiresAuth: false);
        }

        /// <summary>Registers a new user account.</summary>
        public IEnumerator Register(
            string email,
            string password,
            string displayName,
            Action<AuthResponse> onSuccess,
            Action<string> onError)
        {
            var body = new { email, password, display_name = displayName };
            yield return PostRequest<AuthResponse>("/api/v1/auth/register", body, onSuccess, onError, requiresAuth: false);
        }

        /// <summary>Refreshes the access token using the refresh token.</summary>
        public IEnumerator RefreshToken(Action<bool> onComplete)
        {
            string refreshToken = authManager?.RefreshToken;
            if (string.IsNullOrEmpty(refreshToken))
            {
                onComplete?.Invoke(false);
                yield break;
            }

            var body = new { refresh_token = refreshToken };
            yield return PostRequest<AuthResponse>(
                "/api/v1/auth/refresh",
                body,
                response =>
                {
                    authManager?.UpdateTokens(response.AccessToken, response.RefreshToken);
                    onComplete?.Invoke(true);
                },
                error =>
                {
                    Debug.LogError($"[ApiClient] Token refresh failed: {error}");
                    onComplete?.Invoke(false);
                },
                requiresAuth: false);
        }

        // ─── Scan Jobs ────────────────────────────────────────────────────────

        /// <summary>Creates a new scan job on the server and returns the job ID.</summary>
        public IEnumerator CreateScanJob(
            ScanSession session,
            Action<string> onSuccess,
            Action<string> onError)
        {
            var body = new
            {
                client_session_id = session.SessionId,
                started_at = session.StartTime.ToString("o")
            };

            yield return PostRequest<CreateJobResponse>(
                "/api/v1/scans/jobs",
                body,
                response => onSuccess?.Invoke(response.JobId),
                onError);
        }

        /// <summary>Requests a signed upload URL for a frame batch.</summary>
        public IEnumerator GetSignedUploadUrl(
            string jobId,
            int batchIndex,
            Action<SignedUrlResponse> onSuccess,
            Action<string> onError)
        {
            var body = new { job_id = jobId, batch_index = batchIndex };
            yield return PostRequest<SignedUrlResponse>(
                "/api/v1/scans/upload-url",
                body,
                onSuccess,
                onError);
        }

        /// <summary>
        /// Uploads a frame batch using a signed URL.
        /// Implements memory-safe batching to prevent OOM crashes on mid-range devices.
        /// </summary>
        public IEnumerator UploadFrameBatch(
            string jobId,
            byte[][] frames,
            Action<int> onSuccess,
            Action<string> onError)
        {
            // Wait if too many concurrent uploads
            while (activeUploads >= maxConcurrentUploads)
                yield return new WaitForSeconds(0.5f);

            activeUploads++;

            // Get signed URL first
            SignedUrlResponse signedUrl = null;
            bool urlFetched = false;
            string urlError = null;

            int batchIndex = UnityEngine.Random.Range(0, 99999);
            yield return GetSignedUploadUrl(
                jobId,
                batchIndex,
                url => { signedUrl = url; urlFetched = true; },
                err => { urlError = err; urlFetched = true; });

            if (urlError != null)
            {
                activeUploads--;
                onError?.Invoke(urlError);
                yield break;
            }

            // Pack frames into multipart form data
            var formData = new List<IMultipartFormSection>();
            for (int i = 0; i < frames.Length; i++)
            {
                formData.Add(new MultipartFormDataSection($"frame_{i:D4}", frames[i], $"frame_{i:D4}.jpg", "image/jpeg"));
            }

            // Upload to signed URL with retry
            bool uploaded = false;
            for (int attempt = 0; attempt < maxRetries && !uploaded; attempt++)
            {
                if (attempt > 0)
                    yield return new WaitForSeconds(retryDelaySeconds * attempt);

                using var request = UnityWebRequest.Post(signedUrl.UploadUrl, formData);
                request.timeout = (int)requestTimeoutSeconds;

                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    uploaded = true;
                    onSuccess?.Invoke(batchIndex);
                }
                else if (attempt == maxRetries - 1)
                {
                    onError?.Invoke($"Upload failed after {maxRetries} attempts: {request.error}");
                }
            }

            activeUploads--;

            // Explicit null-out to help GC on mid-range devices
            formData.Clear();
        }

        /// <summary>Triggers the reconstruction pipeline for a completed upload.</summary>
        public IEnumerator TriggerReconstruction(
            string jobId,
            Action<string> onSuccess,
            Action<string> onError)
        {
            var body = new { job_id = jobId };
            yield return PostRequest<GenericResponse>(
                $"/api/v1/scans/jobs/{jobId}/reconstruct",
                body,
                response => onSuccess?.Invoke(jobId),
                onError);
        }

        /// <summary>Polls the job status endpoint for reconstruction progress.</summary>
        public IEnumerator GetJobStatus(
            string jobId,
            Action<JobStatusResponse> onSuccess,
            Action<string> onError)
        {
            yield return GetRequest<JobStatusResponse>(
                $"/api/v1/scans/jobs/{jobId}/status",
                onSuccess,
                onError);
        }

        /// <summary>Retrieves the list of completed scans for the current user.</summary>
        public IEnumerator GetUserScans(
            int page,
            int pageSize,
            Action<ScanListResponse> onSuccess,
            Action<string> onError)
        {
            yield return GetRequest<ScanListResponse>(
                $"/api/v1/scans?page={page}&page_size={pageSize}",
                onSuccess,
                onError);
        }

        /// <summary>Downloads mesh data with streaming support for large files.</summary>
        public IEnumerator DownloadMesh(
            string meshUrl,
            Action<byte[]> onSuccess,
            Action<float> onProgress,
            Action<string> onError)
        {
            using var request = UnityWebRequest.Get(meshUrl);
            request.timeout = 120; // Large files may take longer

            var asyncOp = request.SendWebRequest();

            while (!asyncOp.isDone)
            {
                onProgress?.Invoke(asyncOp.progress);
                yield return null;
            }

            if (request.result == UnityWebRequest.Result.Success)
                onSuccess?.Invoke(request.downloadHandler.data);
            else
                onError?.Invoke(request.error);
        }

        // ─── Export & Publishing ──────────────────────────────────────────────

        /// <summary>Requests a high-resolution export (Pro/Enterprise feature).</summary>
        public IEnumerator RequestHighResExport(
            string jobId,
            string format,
            Action<ExportResponse> onSuccess,
            Action<string> onError)
        {
            var body = new { job_id = jobId, format, resolution = "high" };
            yield return PostRequest<ExportResponse>(
                "/api/v1/scans/export",
                body,
                onSuccess,
                onError);
        }

        /// <summary>Submits marketplace metadata for listing.</summary>
        public IEnumerator PublishToMarketplace(
            string jobId,
            object metadata,
            Action<PublishResponse> onSuccess,
            Action<string> onError)
        {
            var body = new { job_id = jobId, metadata };
            yield return PostRequest<PublishResponse>(
                "/api/v1/marketplace/publish",
                body,
                onSuccess,
                onError);
        }

        // ─── Subscription ─────────────────────────────────────────────────────

        /// <summary>Retrieves the current user's subscription tier and scan quota.</summary>
        public IEnumerator GetSubscriptionStatus(
            Action<SubscriptionStatus> onSuccess,
            Action<string> onError)
        {
            yield return GetRequest<SubscriptionStatus>(
                "/api/v1/subscriptions/status",
                onSuccess,
                onError);
        }

        // ─── Generic HTTP Helpers ─────────────────────────────────────────────

        private IEnumerator GetRequest<T>(
            string endpoint,
            Action<T> onSuccess,
            Action<string> onError,
            bool requiresAuth = true)
        {
            string url = $"{apiBaseUrl}{endpoint}";

            for (int attempt = 0; attempt < maxRetries; attempt++)
            {
                if (attempt > 0) yield return new WaitForSeconds(retryDelaySeconds * attempt);

                using var request = UnityWebRequest.Get(url);
                request.timeout = (int)requestTimeoutSeconds;

                if (requiresAuth)
                {
                    // Auto-refresh token if expired
                    if (authManager != null && authManager.IsTokenExpired)
                    {
                        bool refreshed = false;
                        yield return RefreshToken(success => refreshed = success);
                        if (!refreshed)
                        {
                            onError?.Invoke("Authentication expired. Please log in again.");
                            yield break;
                        }
                    }
                    request.SetRequestHeader("Authorization", $"Bearer {authManager?.AccessToken}");
                }

                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    try
                    {
                        var result = JsonConvert.DeserializeObject<T>(request.downloadHandler.text);
                        onSuccess?.Invoke(result);
                        yield break;
                    }
                    catch (Exception ex)
                    {
                        onError?.Invoke($"Parse error: {ex.Message}");
                        yield break;
                    }
                }

                if (request.responseCode == 401 && requiresAuth)
                {
                    // Token expired — try refresh once
                    bool refreshed = false;
                    yield return RefreshToken(success => refreshed = success);
                    if (!refreshed)
                    {
                        onError?.Invoke("Session expired. Please log in again.");
                        yield break;
                    }
                    continue; // Retry with new token
                }

                if (attempt == maxRetries - 1)
                    onError?.Invoke($"Request failed ({request.responseCode}): {request.error}");
            }
        }

        private IEnumerator PostRequest<T>(
            string endpoint,
            object body,
            Action<T> onSuccess,
            Action<string> onError,
            bool requiresAuth = true)
        {
            string url = $"{apiBaseUrl}{endpoint}";
            string json = JsonConvert.SerializeObject(body);
            byte[] bodyBytes = Encoding.UTF8.GetBytes(json);

            for (int attempt = 0; attempt < maxRetries; attempt++)
            {
                if (attempt > 0) yield return new WaitForSeconds(retryDelaySeconds * attempt);

                using var request = new UnityWebRequest(url, "POST");
                request.uploadHandler = new UploadHandlerRaw(bodyBytes);
                request.downloadHandler = new DownloadHandlerBuffer();
                request.SetRequestHeader("Content-Type", "application/json");
                request.timeout = (int)requestTimeoutSeconds;

                if (requiresAuth && authManager != null)
                    request.SetRequestHeader("Authorization", $"Bearer {authManager.AccessToken}");

                yield return request.SendWebRequest();

                if (request.result == UnityWebRequest.Result.Success)
                {
                    try
                    {
                        var result = JsonConvert.DeserializeObject<T>(request.downloadHandler.text);
                        onSuccess?.Invoke(result);
                        yield break;
                    }
                    catch (Exception ex)
                    {
                        onError?.Invoke($"Parse error: {ex.Message}");
                        yield break;
                    }
                }

                if (attempt == maxRetries - 1)
                    onError?.Invoke($"Request failed ({request.responseCode}): {request.error}");
            }
        }
    }

    // ─── Response Models ──────────────────────────────────────────────────────

    [Serializable] public class AuthResponse
    {
        [JsonProperty("access_token")] public string AccessToken;
        [JsonProperty("refresh_token")] public string RefreshToken;
        [JsonProperty("token_type")] public string TokenType;
        [JsonProperty("expires_in")] public int ExpiresIn;
        [JsonProperty("user")] public UserProfile User;
    }

    [Serializable] public class UserProfile
    {
        [JsonProperty("id")] public string Id;
        [JsonProperty("email")] public string Email;
        [JsonProperty("display_name")] public string DisplayName;
        [JsonProperty("subscription_tier")] public string SubscriptionTier;
        [JsonProperty("scans_remaining")] public int ScansRemaining;
    }

    [Serializable] public class CreateJobResponse
    {
        [JsonProperty("job_id")] public string JobId;
        [JsonProperty("status")] public string Status;
    }

    [Serializable] public class SignedUrlResponse
    {
        [JsonProperty("upload_url")] public string UploadUrl;
        [JsonProperty("expires_at")] public string ExpiresAt;
        [JsonProperty("batch_id")] public string BatchId;
    }

    [Serializable] public class GenericResponse
    {
        [JsonProperty("success")] public bool Success;
        [JsonProperty("message")] public string Message;
    }

    [Serializable] public class ScanListResponse
    {
        [JsonProperty("scans")] public ScanSummary[] Scans;
        [JsonProperty("total")] public int Total;
        [JsonProperty("page")] public int Page;
        [JsonProperty("page_size")] public int PageSize;
    }

    [Serializable] public class ScanSummary
    {
        [JsonProperty("job_id")] public string JobId;
        [JsonProperty("status")] public string Status;
        [JsonProperty("confidence_score")] public float ConfidenceScore;
        [JsonProperty("object_class")] public string ObjectClass;
        [JsonProperty("thumbnail_url")] public string ThumbnailUrl;
        [JsonProperty("created_at")] public string CreatedAt;
    }

    [Serializable] public class ExportResponse
    {
        [JsonProperty("export_id")] public string ExportId;
        [JsonProperty("download_url")] public string DownloadUrl;
        [JsonProperty("format")] public string Format;
        [JsonProperty("file_size_bytes")] public long FileSizeBytes;
        [JsonProperty("watermarked")] public bool Watermarked;
    }

    [Serializable] public class PublishResponse
    {
        [JsonProperty("listing_id")] public string ListingId;
        [JsonProperty("marketplace_url")] public string MarketplaceUrl;
        [JsonProperty("status")] public string Status;
    }

    [Serializable] public class SubscriptionStatus
    {
        [JsonProperty("tier")] public string Tier;
        [JsonProperty("scans_used")] public int ScansUsed;
        [JsonProperty("scans_limit")] public int ScansLimit;
        [JsonProperty("scans_remaining")] public int ScansRemaining;
        [JsonProperty("is_priority")] public bool IsPriority;
        [JsonProperty("renewal_date")] public string RenewalDate;
    }
}
