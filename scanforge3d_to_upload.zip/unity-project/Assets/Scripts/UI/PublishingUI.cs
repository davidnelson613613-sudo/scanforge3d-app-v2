using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using ScanForge.Publishing;

namespace ScanForge.UI
{
    /// <summary>
    /// PublishingUI manages the in-app publishing panel.
    /// Provides UI for: APK export, Google Play upload, marketplace publishing,
    /// export format selection, and build progress display.
    /// </summary>
    public class PublishingUI : MonoBehaviour
    {
        [Header("Main Panel")]
        [SerializeField] private GameObject publishingPanel;
        [SerializeField] private Button closeButton;

        [Header("Export Options")]
        [SerializeField] private GameObject exportOptionsPanel;
        [SerializeField] private Button exportOBJButton;
        [SerializeField] private Button exportFBXButton;
        [SerializeField] private Button exportGLBButton;
        [SerializeField] private Button exportUSDZButton;
        [SerializeField] private Button exportHighResButton;
        [SerializeField] private TextMeshProUGUI proOnlyLabel;

        [Header("Publish Options")]
        [SerializeField] private GameObject publishOptionsPanel;
        [SerializeField] private Button publishGooglePlayButton;
        [SerializeField] private Button publishSketchfabButton;
        [SerializeField] private Button publishCGTraderButton;
        [SerializeField] private Button generateAPKButton;
        [SerializeField] private Button shareAPKButton;

        [Header("Progress")]
        [SerializeField] private GameObject progressPanel;
        [SerializeField] private Image progressBar;
        [SerializeField] private TextMeshProUGUI progressLabel;
        [SerializeField] private TextMeshProUGUI progressPercentText;

        [Header("Build Panel")]
        [SerializeField] private GameObject buildPanel;
        [SerializeField] private TMP_InputField versionNameInput;
        [SerializeField] private TMP_InputField versionCodeInput;
        [SerializeField] private Toggle releaseToggle;
        [SerializeField] private Button startBuildButton;
        [SerializeField] private TextMeshProUGUI buildStatusText;

        [Header("Success Panel")]
        [SerializeField] private GameObject successPanel;
        [SerializeField] private TextMeshProUGUI successMessageText;
        [SerializeField] private Button openLinkButton;
        [SerializeField] private Button doneButton;
        [SerializeField] private TextMeshProUGUI publishedUrlText;

        [Header("Guide Panel")]
        [SerializeField] private GameObject guidePanel;
        [SerializeField] private TextMeshProUGUI guideTitle;
        [SerializeField] private TextMeshProUGUI guideContent;
        [SerializeField] private Button guideDoneButton;

        // ─── Events ───────────────────────────────────────────────────────────
        public event Action<ExportFormat> OnExportRequested;
        public event Action OnGooglePlayPublishRequested;
        public event Action OnAPKBuildRequested;
        public event Action<BuildConfiguration> OnBuildConfigSubmitted;

        private string currentPublishedUrl;

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            SetupButtonListeners();
        }

        // ─── Public API ───────────────────────────────────────────────────────

        public void ShowPublishingOptions()
        {
            publishingPanel?.SetActive(true);
            SetAllSubPanelsInactive();
            publishOptionsPanel?.SetActive(true);
        }

        public void ShowExportOptions()
        {
            publishingPanel?.SetActive(true);
            SetAllSubPanelsInactive();
            exportOptionsPanel?.SetActive(true);

            // Show Pro-only label for high-res export if user is on free tier
            bool isPro = ScanForge.Utils.AuthManager.Instance?.IsPro ?? false;
            proOnlyLabel?.gameObject.SetActive(!isPro);
            exportHighResButton?.gameObject.SetActive(true);
            if (exportHighResButton != null)
                exportHighResButton.interactable = isPro;
        }

        public void ShowBuildPanel()
        {
            publishingPanel?.SetActive(true);
            SetAllSubPanelsInactive();
            buildPanel?.SetActive(true);

            if (versionNameInput != null)
                versionNameInput.text = "1.0.0";
            if (versionCodeInput != null)
                versionCodeInput.text = "1";
        }

        public void ShowExportProgress(string message, float progress)
        {
            SetAllSubPanelsInactive();
            progressPanel?.SetActive(true);

            if (progressLabel != null) progressLabel.text = message;
            if (progressBar != null) progressBar.fillAmount = Mathf.Clamp01(progress);
            if (progressPercentText != null)
                progressPercentText.text = $"{Mathf.RoundToInt(progress * 100)}%";
        }

        public void ShowPublishProgress(string message, float progress)
        {
            ShowExportProgress(message, progress);
        }

        public void ShowBuildProgress(string message, float progress)
        {
            if (buildStatusText != null) buildStatusText.text = message;
            ShowExportProgress(message, progress);
        }

        public void ShowPublishSuccess(string url)
        {
            SetAllSubPanelsInactive();
            successPanel?.SetActive(true);
            currentPublishedUrl = url;

            if (successMessageText != null)
                successMessageText.text = "Published successfully!";
            if (publishedUrlText != null)
                publishedUrlText.text = url;
        }

        public void ShowPublishGuide(PublishPlatform platform)
        {
            SetAllSubPanelsInactive();
            guidePanel?.SetActive(true);

            switch (platform)
            {
                case PublishPlatform.GooglePlay:
                    if (guideTitle != null) guideTitle.text = "Publishing to Google Play";
                    if (guideContent != null) guideContent.text =
                        "Step 1: Sign in to Google Play Console\n\n" +
                        "Step 2: Create a new app or select existing\n\n" +
                        "Step 3: Go to Release > Internal Testing\n\n" +
                        "Step 4: Upload your APK or AAB file\n\n" +
                        "Step 5: Complete the store listing\n\n" +
                        "Step 6: Submit for review\n\n" +
                        "Tip: Use the 'Generate APK' button below to build a signed APK ready for upload.";
                    break;

                case PublishPlatform.APK:
                    if (guideTitle != null) guideTitle.text = "Installing APK Directly";
                    if (guideContent != null) guideContent.text =
                        "Step 1: Enable 'Unknown Sources' in Android Settings\n\n" +
                        "Step 2: Download the APK to your device\n\n" +
                        "Step 3: Open the APK file to install\n\n" +
                        "Step 4: Grant requested permissions\n\n" +
                        "Note: Direct APK installation is for testing only. Use Google Play for distribution.";
                    break;
            }
        }

        public void Hide()
        {
            publishingPanel?.SetActive(false);
        }

        // ─── Private Methods ──────────────────────────────────────────────────

        private void SetupButtonListeners()
        {
            closeButton?.onClick.AddListener(Hide);

            exportOBJButton?.onClick.AddListener(() => OnExportRequested?.Invoke(ExportFormat.OBJ));
            exportFBXButton?.onClick.AddListener(() => OnExportRequested?.Invoke(ExportFormat.FBX));
            exportGLBButton?.onClick.AddListener(() => OnExportRequested?.Invoke(ExportFormat.GLB));
            exportUSDZButton?.onClick.AddListener(() => OnExportRequested?.Invoke(ExportFormat.USDZ));
            exportHighResButton?.onClick.AddListener(() => OnExportRequested?.Invoke(ExportFormat.GLB));

            publishGooglePlayButton?.onClick.AddListener(() =>
            {
                ShowPublishGuide(PublishPlatform.GooglePlay);
                OnGooglePlayPublishRequested?.Invoke();
            });

            generateAPKButton?.onClick.AddListener(() =>
            {
                ShowBuildPanel();
                OnAPKBuildRequested?.Invoke();
            });

            startBuildButton?.onClick.AddListener(SubmitBuildConfig);

            openLinkButton?.onClick.AddListener(() =>
            {
                if (!string.IsNullOrEmpty(currentPublishedUrl))
                    Application.OpenURL(currentPublishedUrl);
            });

            doneButton?.onClick.AddListener(Hide);
            guideDoneButton?.onClick.AddListener(() =>
            {
                SetAllSubPanelsInactive();
                publishOptionsPanel?.SetActive(true);
            });
        }

        private void SubmitBuildConfig()
        {
            var config = new BuildConfiguration
            {
                VersionName = versionNameInput?.text ?? "1.0.0",
                VersionCode = int.TryParse(versionCodeInput?.text, out int vc) ? vc : 1,
                BuildType = releaseToggle != null && releaseToggle.isOn ? BuildType.Release : BuildType.Debug,
                SigningConfig = new SigningConfig { UseDebugKey = true }
            };

            OnBuildConfigSubmitted?.Invoke(config);
        }

        private void SetAllSubPanelsInactive()
        {
            exportOptionsPanel?.SetActive(false);
            publishOptionsPanel?.SetActive(false);
            progressPanel?.SetActive(false);
            buildPanel?.SetActive(false);
            successPanel?.SetActive(false);
            guidePanel?.SetActive(false);
        }
    }

    public enum PublishPlatform { GooglePlay, APK, Sketchfab, CGTrader }
}
