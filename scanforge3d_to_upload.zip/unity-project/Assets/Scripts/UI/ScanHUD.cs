using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace ScanForge.UI
{
    /// <summary>
    /// ScanHUD manages the dark minimal scanning interface.
    /// Includes: progress ring, confidence score display, real-time guidance overlay,
    /// lighting correction guide, texture suggestion overlay, and completion screen.
    /// </summary>
    public class ScanHUD : MonoBehaviour
    {
        // ─── Progress Ring ────────────────────────────────────────────────────
        [Header("Progress Ring")]
        [SerializeField] private Image progressRingFill;
        [SerializeField] private TextMeshProUGUI progressPercentText;
        [SerializeField] private GameObject progressRingContainer;

        // ─── Confidence Score ─────────────────────────────────────────────────
        [Header("Confidence Score")]
        [SerializeField] private TextMeshProUGUI confidenceScoreText;
        [SerializeField] private Image confidenceScoreBar;
        [SerializeField] private GameObject confidenceContainer;

        // ─── Guidance Overlay ─────────────────────────────────────────────────
        [Header("Guidance Overlay")]
        [SerializeField] private GameObject guidanceOverlay;
        [SerializeField] private TextMeshProUGUI guidanceText;
        [SerializeField] private Image guidanceIcon;
        [SerializeField] private Sprite lightingIcon;
        [SerializeField] private Sprite textureIcon;
        [SerializeField] private Sprite moveSlowerIcon;
        [SerializeField] private Sprite completeIcon;

        // ─── Scan Corner Brackets ─────────────────────────────────────────────
        [Header("Scan Frame")]
        [SerializeField] private GameObject scanFrameContainer;
        [SerializeField] private RectTransform[] cornerBrackets;
        [SerializeField] private float bracketPulseSpeed = 1.5f;
        [SerializeField] private float bracketPulseScale = 1.05f;

        // ─── Status Panels ────────────────────────────────────────────────────
        [Header("Status Panels")]
        [SerializeField] private GameObject idlePanel;
        [SerializeField] private GameObject scanningPanel;
        [SerializeField] private GameObject uploadingPanel;
        [SerializeField] private GameObject processingPanel;
        [SerializeField] private GameObject completionPanel;
        [SerializeField] private GameObject errorPanel;

        // ─── Completion Panel ─────────────────────────────────────────────────
        [Header("Completion")]
        [SerializeField] private TextMeshProUGUI completionScoreText;
        [SerializeField] private TextMeshProUGUI completionGradeText;
        [SerializeField] private Image completionScoreRing;
        [SerializeField] private Button viewModelButton;
        [SerializeField] private Button exportButton;
        [SerializeField] private Button publishButton;

        // ─── Error Panel ──────────────────────────────────────────────────────
        [Header("Error")]
        [SerializeField] private TextMeshProUGUI errorMessageText;
        [SerializeField] private Button retryButton;
        [SerializeField] private Button cancelButton;

        // ─── Processing Panel ─────────────────────────────────────────────────
        [Header("Processing")]
        [SerializeField] private Image processingProgressBar;
        [SerializeField] private TextMeshProUGUI processingStatusText;
        [SerializeField] private GameObject processingSpinner;

        // ─── Lighting Guide ───────────────────────────────────────────────────
        [Header("Lighting Guide")]
        [SerializeField] private GameObject lightingGuidePanel;
        [SerializeField] private Image lightingMeterFill;
        [SerializeField] private TextMeshProUGUI lightingAdviceText;

        // ─── Top Status Bar ───────────────────────────────────────────────────
        [Header("Top Bar")]
        [SerializeField] private TextMeshProUGUI frameCountText;
        [SerializeField] private TextMeshProUGUI sessionTimeText;
        [SerializeField] private Image featureDensityIndicator;
        [SerializeField] private TextMeshProUGUI statusMessageText;

        // ─── Color Palette (Dark Minimal) ─────────────────────────────────────
        private static readonly Color ColorAccent = new Color(0.0f, 0.85f, 0.72f, 1f);       // #00D9B8
        private static readonly Color ColorWarning = new Color(1.0f, 0.75f, 0.0f, 1f);       // #FFBF00
        private static readonly Color ColorError = new Color(0.95f, 0.27f, 0.27f, 1f);       // #F24444
        private static readonly Color ColorSuccess = new Color(0.18f, 0.87f, 0.45f, 1f);     // #2EDE73
        private static readonly Color ColorBackground = new Color(0.06f, 0.06f, 0.08f, 0.9f);// #0F0F14

        // ─── Private State ────────────────────────────────────────────────────
        private Coroutine bracketPulseCoroutine;
        private Coroutine spinnerCoroutine;
        private DateTime sessionStartTime;
        private int frameCount = 0;

        // ─── Unity Lifecycle ──────────────────────────────────────────────────
        private void Awake()
        {
            ShowIdleUI();
        }

        private void Update()
        {
            if (scanningPanel != null && scanningPanel.activeSelf)
            {
                UpdateSessionTimer();
            }
        }

        // ─── Public API ───────────────────────────────────────────────────────

        /// <summary>Shows the idle/ready state UI.</summary>
        public void ShowIdleUI()
        {
            SetAllPanelsInactive();
            idlePanel?.SetActive(true);
        }

        /// <summary>Activates the scanning HUD with progress ring and guidance overlay.</summary>
        public void ShowScanningUI()
        {
            SetAllPanelsInactive();
            scanningPanel?.SetActive(true);
            scanFrameContainer?.SetActive(true);
            progressRingContainer?.SetActive(true);
            guidanceOverlay?.SetActive(true);
            sessionStartTime = DateTime.Now;
            frameCount = 0;

            UpdateProgress(0f);
            SetGuidanceText("Move slowly around the object", moveSlowerIcon);

            if (bracketPulseCoroutine != null) StopCoroutine(bracketPulseCoroutine);
            bracketPulseCoroutine = StartCoroutine(PulseCornerBrackets());
        }

        /// <summary>Updates the circular progress ring (0–1 range).</summary>
        public void UpdateProgress(float progress)
        {
            if (progressRingFill != null)
                progressRingFill.fillAmount = Mathf.Clamp01(progress);

            if (progressPercentText != null)
                progressPercentText.text = $"{Mathf.RoundToInt(progress * 100)}%";

            // Color transition: accent → success as progress increases
            if (progressRingFill != null)
                progressRingFill.color = Color.Lerp(ColorAccent, ColorSuccess, progress);

            frameCount++;
            if (frameCountText != null)
                frameCountText.text = $"Frames: {frameCount}";
        }

        /// <summary>Updates the real-time confidence score display (0–100).</summary>
        public void UpdateConfidenceScore(float score)
        {
            float normalized = Mathf.Clamp01(score / 100f);

            if (confidenceScoreText != null)
                confidenceScoreText.text = $"{Mathf.RoundToInt(score)}";

            if (confidenceScoreBar != null)
            {
                confidenceScoreBar.fillAmount = normalized;
                confidenceScoreBar.color = GetScoreColor(score);
            }

            confidenceContainer?.SetActive(true);
        }

        /// <summary>Shows the lighting correction guide overlay.</summary>
        public void ShowLightingGuide()
        {
            lightingGuidePanel?.SetActive(true);
            lightingAdviceText?.SetText(
                "Lighting too dark.\n\n" +
                "• Move to a well-lit area\n" +
                "• Avoid direct sunlight glare\n" +
                "• Use diffused ambient light");
        }

        /// <summary>Shows a brief lighting warning without blocking the scan.</summary>
        public void ShowLightingWarning()
        {
            SetGuidanceText("Improve lighting for better results", lightingIcon, ColorWarning);
            StartCoroutine(HideGuidanceAfterDelay(3f));
        }

        /// <summary>Shows texture suggestion overlay when feature density is low.</summary>
        public void ShowTextureGuide()
        {
            SetGuidanceText("Low texture detected — add stickers or texture to object", textureIcon, ColorWarning);
            StartCoroutine(HideGuidanceAfterDelay(4f));
        }

        /// <summary>Shows the uploading state panel.</summary>
        public void ShowUploadingUI()
        {
            SetAllPanelsInactive();
            uploadingPanel?.SetActive(true);
            processingStatusText?.SetText("Uploading scan data to server...");
        }

        /// <summary>Shows the processing/reconstruction state panel with spinner.</summary>
        public void ShowProcessingUI()
        {
            SetAllPanelsInactive();
            processingPanel?.SetActive(true);
            processingStatusText?.SetText("Reconstructing 3D model...");

            if (spinnerCoroutine != null) StopCoroutine(spinnerCoroutine);
            spinnerCoroutine = StartCoroutine(RotateSpinner());
        }

        /// <summary>Updates the processing progress bar (0–1 range).</summary>
        public void UpdateProcessingProgress(float progress)
        {
            if (processingProgressBar != null)
                processingProgressBar.fillAmount = Mathf.Clamp01(progress);

            if (processingStatusText != null)
                processingStatusText.text = $"Reconstructing... {Mathf.RoundToInt(progress * 100)}%";
        }

        /// <summary>Shows the scan completion panel with confidence score and grade.</summary>
        public void ShowCompletionUI(float confidenceScore)
        {
            SetAllPanelsInactive();
            completionPanel?.SetActive(true);

            if (completionScoreText != null)
                completionScoreText.text = $"{Mathf.RoundToInt(confidenceScore)}";

            if (completionScoreRing != null)
            {
                completionScoreRing.fillAmount = confidenceScore / 100f;
                completionScoreRing.color = GetScoreColor(confidenceScore);
            }

            if (completionGradeText != null)
                completionGradeText.text = GetScoreGrade(confidenceScore);

            SetGuidanceText("Scan complete!", completeIcon, ColorSuccess);
        }

        /// <summary>Shows the error panel with a descriptive message.</summary>
        public void ShowErrorUI(string errorMessage)
        {
            SetAllPanelsInactive();
            errorPanel?.SetActive(true);

            if (errorMessageText != null)
                errorMessageText.text = errorMessage;
        }

        /// <summary>Hides all scanning UI elements.</summary>
        public void HideScanningUI()
        {
            SetAllPanelsInactive();
            scanFrameContainer?.SetActive(false);
            guidanceOverlay?.SetActive(false);
            progressRingContainer?.SetActive(false);
            lightingGuidePanel?.SetActive(false);

            if (bracketPulseCoroutine != null) StopCoroutine(bracketPulseCoroutine);
            if (spinnerCoroutine != null) StopCoroutine(spinnerCoroutine);
        }

        /// <summary>Displays a transient status message in the top bar.</summary>
        public void ShowStatusMessage(string message)
        {
            if (statusMessageText != null)
                statusMessageText.text = message;
        }

        // ─── Private Methods ──────────────────────────────────────────────────

        private void SetAllPanelsInactive()
        {
            idlePanel?.SetActive(false);
            scanningPanel?.SetActive(false);
            uploadingPanel?.SetActive(false);
            processingPanel?.SetActive(false);
            completionPanel?.SetActive(false);
            errorPanel?.SetActive(false);
        }

        private void SetGuidanceText(string text, Sprite icon = null, Color? color = null)
        {
            if (guidanceText != null) guidanceText.text = text;
            if (guidanceIcon != null && icon != null) guidanceIcon.sprite = icon;
            if (guidanceIcon != null && color.HasValue) guidanceIcon.color = color.Value;
            guidanceOverlay?.SetActive(true);
        }

        private void UpdateSessionTimer()
        {
            if (sessionTimeText != null)
            {
                TimeSpan elapsed = DateTime.Now - sessionStartTime;
                sessionTimeText.text = $"{elapsed.Minutes:D2}:{elapsed.Seconds:D2}";
            }
        }

        private Color GetScoreColor(float score)
        {
            if (score >= 80f) return ColorSuccess;
            if (score >= 50f) return ColorWarning;
            return ColorError;
        }

        private string GetScoreGrade(float score)
        {
            if (score >= 90f) return "Excellent";
            if (score >= 75f) return "Good";
            if (score >= 50f) return "Fair";
            return "Poor";
        }

        private IEnumerator PulseCornerBrackets()
        {
            if (cornerBrackets == null || cornerBrackets.Length == 0) yield break;

            float t = 0f;
            while (true)
            {
                t += Time.deltaTime * bracketPulseSpeed;
                float scale = 1f + (Mathf.Sin(t) * 0.5f + 0.5f) * (bracketPulseScale - 1f);
                foreach (var bracket in cornerBrackets)
                {
                    if (bracket != null)
                        bracket.localScale = Vector3.one * scale;
                }
                yield return null;
            }
        }

        private IEnumerator RotateSpinner()
        {
            if (processingSpinner == null) yield break;

            while (true)
            {
                processingSpinner.transform.Rotate(0f, 0f, -180f * Time.deltaTime);
                yield return null;
            }
        }

        private IEnumerator HideGuidanceAfterDelay(float delay)
        {
            yield return new WaitForSeconds(delay);
            // Only hide if we haven't replaced with a different message
            if (guidanceOverlay != null && guidanceOverlay.activeSelf)
            {
                SetGuidanceText("Move slowly around the object", moveSlowerIcon, ColorAccent);
            }
        }
    }
}
